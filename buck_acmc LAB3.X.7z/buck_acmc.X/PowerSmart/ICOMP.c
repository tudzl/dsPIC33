/* *********************************************************************************
 * PowerSmart Digital Control Library Designer, Version 1.9.15.709
 * *********************************************************************************
 * 2p2z controller function declarations and compensation filter coefficients
 * derived for following operating conditions:
 * *********************************************************************************
 *
 *  Controller Type:    2P2Z - Basic Current Mode Compensator
 *  Sampling Frequency: 250000 Hz
 *  Fixed Point Format: Q15
 *  Scaling Mode:       4 - Fast Floating Point Coefficient Scaling
 *  Input Gain:         1
 *
 * *********************************************************************************
 * CGS Version:         3.0.11
 * CGS Date:            01/06/2022
 * *********************************************************************************
 * User:                admin
 * Date/Time:           11/15/2024 16:29:07
 * ********************************************************************************/

#include "ICOMP.h"

/* *********************************************************************************
 * Data Arrays:
 * ============
 *
 * This source file declares the default parameters of the z-domain compensation
 * filter. The NPNZ16b_s data structure contains two pointers to A- and B-
 * coefficient arrays and two pointers to control and error history arrays.
 *
 * For optimized data processing during DSP computations, these arrays must be
 * located in specific memory locations (X-space for coefficient arrays and
 * Y-space for control and error history arrays).
 *
 * The following declarations are used to define the array data contents, their
 * length and memory location. These declarations are made publicly accessible
 * through extern declarations in header file ICOMP.h
 * ********************************************************************************/

volatile struct ICOMP_CONTROL_LOOP_COEFFICIENTS_s __attribute__((space(xmemory), near)) ICOMP_coefficients; // A/B-Coefficients
volatile uint16_t ICOMP_ACoefficients_size = (sizeof(ICOMP_coefficients.ACoefficients)/sizeof(ICOMP_coefficients.ACoefficients[0])); // A-coefficient array size
volatile uint16_t ICOMP_BCoefficients_size = (sizeof(ICOMP_coefficients.BCoefficients)/sizeof(ICOMP_coefficients.BCoefficients[0])); // B-coefficient array size

volatile struct ICOMP_CONTROL_LOOP_HISTORIES_s __attribute__((space(ymemory), far)) ICOMP_histories; // Control/Error Histories
volatile uint16_t ICOMP_ControlHistory_size = (sizeof(ICOMP_histories.ControlHistory)/sizeof(ICOMP_histories.ControlHistory[0])); // Control history array size
volatile uint16_t ICOMP_ErrorHistory_size = (sizeof(ICOMP_histories.ErrorHistory)/sizeof(ICOMP_histories.ErrorHistory[0])); // Error history array size

/* *********************************************************************************
 * Pole&Zero Placement:
 * *********************************************************************************
 *
 *    fP0:    380 Hz
 *    fP1:    125000 Hz
 *    fZ1:    5000 Hz
 *
 * *********************************************************************************
 * Filter Coefficients and Parameters:
 * ********************************************************************************/

volatile int32_t ICOMP_ACoefficients [2] =
{
    0x63950000, // Coefficient A1 will be multiplied with controller output u(n-1)
    0x71AF0002  // Coefficient A2 will be multiplied with controller output u(n-2)
};

volatile int32_t ICOMP_BCoefficients [3] =
{
    0x651A0004, // Coefficient B0 will be multiplied with error input e(n-0)
    0x5FA10007, // Coefficient B1 will be multiplied with error input e(n-1)
    0xA6DB0004  // Coefficient B2 will be multiplied with error input e(n-2)
};

// Coefficient normalization factors
volatile int16_t ICOMP_pre_shift = 3;             // Bit-shift value used to perform input value normalization
volatile int16_t ICOMP_post_shift_A = 0;          // Bit-shift value A used to perform control output value backward normalization
volatile int16_t ICOMP_post_shift_B = 0;          // Bit-shift value B used to perform control output value backward normalization
volatile fractional ICOMP_post_scaler = 0x0000;   // Q15 fractional factor used to perform control output value backward normalization


// User-defined NPNZ16b_s controller data object
volatile struct NPNZ16b_s ICOMP;                  // user-controller data object

/* ********************************************************************************/

/* *********************************************************************************
 * Controller Initialization:
 * ==========================
  *
 * Public controller initialization function loading known default settings
 * into the NPNZ16b data structure.
 *
 * ********************************************************************************/

volatile uint16_t ICOMP_Initialize(volatile struct NPNZ16b_s* controller)
{
    volatile uint16_t i=0;

    // Initialize controller data structure at runtime with pre-defined default values
    controller->status.value = NPNZ_STATUS_CLEAR; // clear all status flag bits (will turn off execution))

    controller->Filter.ptrACoefficients = &ICOMP_coefficients.ACoefficients[0]; // initialize pointer to A-coefficients array
    controller->Filter.ptrBCoefficients = &ICOMP_coefficients.BCoefficients[0]; // initialize pointer to B-coefficients array
    controller->Filter.ptrControlHistory = &ICOMP_histories.ControlHistory[0]; // initialize pointer to control history array
    controller->Filter.ptrErrorHistory = &ICOMP_histories.ErrorHistory[0]; // initialize pointer to error history array
    controller->Filter.normPostShiftA = ICOMP_post_shift_A; // initialize A-coefficients/single bit-shift scaler
    controller->Filter.normPostShiftB = ICOMP_post_shift_B; // initialize B-coefficients/dual/post scale factor bit-shift scaler
    controller->Filter.normPostScaler = ICOMP_post_scaler; // initialize control output value normalization scaling factor
    controller->Filter.normPreShift = ICOMP_pre_shift; // initialize A-coefficients/single bit-shift scaler
    
    controller->Filter.ACoefficientsArraySize = ICOMP_ACoefficients_size; // initialize A-coefficients array size
    controller->Filter.BCoefficientsArraySize = ICOMP_BCoefficients_size; // initialize B-coefficients array size
    controller->Filter.ControlHistoryArraySize = ICOMP_ControlHistory_size; // initialize control history array size
    controller->Filter.ErrorHistoryArraySize = ICOMP_ErrorHistory_size; // initialize error history array size

    // Load default set of A-coefficients from user RAM into controller A-array located in X-Space
    for(i=0; i<controller->Filter.ACoefficientsArraySize; i++)
    {
        ICOMP_coefficients.ACoefficients[i] = ICOMP_ACoefficients[i]; // Load coefficient A(n) value into ICOMP coefficient(i) data space
    }

    // Load default set of B-coefficients from user RAM into controller B-array located in X-Space
    for(i=0; i<controller->Filter.BCoefficientsArraySize; i++)
    {
        ICOMP_coefficients.BCoefficients[i] = ICOMP_BCoefficients[i]; // Load coefficient B(n) value into ICOMP coefficient(i) data space
    }

    // Clear error and control histories of the 2P2Z controller
    ICOMP_Reset(&ICOMP);
    
    return(1);
}


//**********************************************************************************
// Download latest version of this tool here:
//      https://www.microchip.com/powersmart
//**********************************************************************************


/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.4
        Device            :  dsPIC33CK256MP505
    The generated drivers are tested against the following:
        Compiler          :  XC16 v2.10
        MPLAB 	          :  MPLAB X v6.05
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"
#include "stdio.h"
#include "sources/PowerSmart/VCOMP.h"
#include "sources/PowerSmart/ICOMP.h"
#include "sources/X2CScope/X2Cscope.h"

//------------------------------------------------------------------------------
// Constants and Macro Definitions
#define TMR1_500MS_CNT      5000
#define TMR1_200MS_DELAY    2000
#define TMR1_10MS_CNT       100

#define AN12_VIN_SCALE   (float)( 1.0/8.0 * 4095.0/3.3 ) // Input voltage: 155 digits/V
#define AN13_VBUCK_SCALE (float)( 1.0/2.02 * 4095.0/3.3 ) // Buck output voltage: 620 ticks/V
#define VIN_TH_ON  (int16_t)( 6.5   * AN12_VIN_SCALE )   // Switch-on threshold: 6.5 V
#define VIN_TH_OFF (int16_t)( 5.5   * AN12_VIN_SCALE )   // Switch-off (undervoltage) threshold: 5.5 V
#define VBUCK_RAMP (int16_t)( 20e-3 * AN13_VBUCK_SCALE ) // soft start ramp: 20 mV/ms

//------------------------------------------------------------------------------
// Define Global Variables:
int16_t vin_adc = 0;    // Scaling: 155.1 steps/V
int16_t vbuck_adc = 0;  // Scaling: 620.5 steps/V
int16_t isns_adc = 0;   // Scaling: 1241 steps/A
int16_t vbuck_ref = 0;  // Scaling: 620.5 steps/V
int16_t i_ref = 0;      // Current reference
int16_t led_tmr = 0;
int16_t vout_ref = 2048;
uint16_t power_on_off = 1;
int16_t fsm_state = 0;
int16_t start_tmr = 0;
uint16_t isr_tmr = 0;

uint16_t cnt_10ms = 0;

//------------------------------------------------------------------------------
void TMR1_CallBack(void) 
{
    // blink LED @ 1Hz
    if(++led_tmr >= TMR1_500MS_CNT)
    {
        led_tmr = 0;
        DBGLED_Toggle();
    }
    
//    if (++cnt_10ms >= TMR1_10MS_CNT)
//    {
//        cnt_10ms = 0;
//        
//        if (PG1DC < 1400)
//        {
//            PG1DC+=5;
//        }
//    }
    
    // power on/off manage
    switch(fsm_state) 
    {
        case 0: // State 0: wait for Vin>threshold and power on, delay some time
        {
            if((vin_adc < VIN_TH_ON) || (power_on_off == 0))
            {
                start_tmr = 0;
                vbuck_ref = 0;
            }
            else if(++start_tmr > TMR1_200MS_DELAY)
            {
                vbuck_ref = vbuck_adc;
                PWM_OverrideHighDisable(PWM_GENERATOR_1);
                PWM_OverrideLowDisable(PWM_GENERATOR_1);
                VCOMP.status.bits.enabled = true;
                fsm_state = 1;
            }
            break;
        }
        case 1: // State 1: ramp up buck reference value (soft start)
        {
            if(vbuck_ref < (vout_ref - VBUCK_RAMP))
            {
                vbuck_ref += VBUCK_RAMP;
            } 
            else if (vbuck_ref > (vout_ref - VBUCK_RAMP))
            {
                vbuck_ref -= VBUCK_RAMP;
            }
            else
            {
                vbuck_ref = vout_ref;
            }
            
            if((vin_adc<VIN_TH_OFF) || (power_on_off == 0))
            {
                fsm_state = 0;
                PWM_OverrideHighEnable(PWM_GENERATOR_1);
                PWM_OverrideLowEnable(PWM_GENERATOR_1);
                VCOMP.status.bits.enabled = false;
                VCOMP_Reset(&VCOMP);
                ICOMP_Reset(&ICOMP);
           }
            break;
        }
    }
}

//------------------------------------------------------------------------------
void __attribute__ ( ( __interrupt__ , auto_psv, context ) ) _ADCAN13Interrupt ( void )
{
    isns_adc = ADCBUF0;
    vin_adc = ADCBUF12;
    vbuck_adc = ADCBUF13;
    
    if (VCOMP.status.bits.enabled == true)
    {
        VCOMP_Update(&VCOMP);
    }
    
    isr_tmr++;
    if (isr_tmr > 4096)
    {
        isr_tmr = 0;
    }
    X2Cscope_Update();
    
    //clear the channel_AN13 interrupt flag
    IFS6bits.ADCAN13IF = 0;
}

//------------------------------------------------------------------------------
void CONTROL_Initialize(void)
{
    // initialize compensator 
    VCOMP_Initialize(&VCOMP);
    VCOMP.Ports.Source.ptrAddress = (unsigned*)&vbuck_adc;
    VCOMP.Ports.Target.ptrAddress = (unsigned*)&i_ref;
    VCOMP.Ports.ptrControlReference = (unsigned*)&vbuck_ref;
    VCOMP.Limits.MinOutput = -50;//-200;
    VCOMP.Limits.MaxOutput = 3103;  // 2.5A

    VCOMP.ExtensionHooks.ptrExtHookExitFunction = (uint16_t)&ICOMP_Update;
    VCOMP.ExtensionHooks.ExtHookExitFunctionParam = (uint16_t)&ICOMP;

    ICOMP_Initialize(&ICOMP);
    ICOMP.Ports.Source.ptrAddress = (unsigned*)&isns_adc;
    ICOMP.Ports.Target.ptrAddress = (unsigned*)&PG1DC;
    ICOMP.Ports.ptrControlReference = (unsigned*)&i_ref;
    ICOMP.Limits.MinOutput = 0;
    ICOMP.Limits.MaxOutput = (int)(0.8*PG1PER); // 80% DC

}

/*
                         Main application
 */
int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    CORCON = 0xE0;
    CONTROL_Initialize();
    X2Cscope_Init();
    PWM_TriggerCompareValueSet(PWM_GENERATOR_1, PG1PER);
    PWM_GeneratorEnable(PWM_GENERATOR_1);
//    PWM_OverrideHighDisable(PWM_GENERATOR_1);
//    PWM_OverrideLowDisable(PWM_GENERATOR_1);
    TMR1_Start();
    
    INTERRUPT_GlobalEnable();
    
    while (1)
    {
//        if (UART1_Read() == 'c')
//        {
//            printf("Hello Power - Breakthrough Buck Average Current Mode Control!\n");
//            printf("vin_adc = %d\n", vin_adc);
//            printf("vbuck_adc = %d\n", vbuck_adc);
//            printf("isns_adc = %d\n", isns_adc);
//            printf("PG1DC = %d\n", PG1DC);
//        }
        X2Cscope_Communicate();
    }
    return 1; 
}
/**
 End of File
*/


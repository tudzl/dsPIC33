/*
    (c) 2022 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

#include "PBV_Frame_Map.h"

extern uint16_t GetBuckOutputVoltage(void);
extern uint16_t GetBuckInputVoltage(void);
extern uint16_t GetBuckInductorCurrent(void);
extern uint16_t GetBuckFalultStatus(void);

/*********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def     FIRMWARE_PROTOCOL_ID
 * @brief   Protocol ID on which firmware ID is sent
 **********************************************************************************/
#define FIRMWARE_PROTOCOL_ID            0x1000          ///< Firmware ID

/*********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def     PBV_GUI_TO_SYSTEM_ID
 * @brief   ID on which data is received
 **********************************************************************************/
#define PBV_GUI_TO_SYSTEM_ID            0x202           ///< ID on which data is received.

/*********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def     PBV_GUI_TO_SYSTEM_ID
 * @brief   ID on which data is received
 **********************************************************************************/
#define PBV_GUI_TO_SYSTEM_CMD_POWER_ON_OFF_ID   0x0000           ///< ID on which data is received.

/*********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def     PBV_GUI_TO_SYSTEM_ID
 * @brief   ID on which data is received
 **********************************************************************************/
#define PBV_GUI_TO_SYSTEM_CMD_SET_VOLTAGE_ID    0x0001           ///< ID on which data is received.

/*********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def     PBV_SYSTEM_TO_GUI_ID
 * @brief   ID on which data is sent
 **********************************************************************************/
#define PBV_SYSTEM_TO_GUI_ID            0x205           ///< ID on which data is sent. 

/*********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def     PBV_SYSTEM_TO_GUI_ID
 * @brief   ID on which log data is sent
 **********************************************************************************/
#define PBV_SYSTEM_TO_GUI_ASCII_ID      0x206           ///< ID on which log data is sent. 

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @struct  App_PBV_Demo_TX
 * @brief   Application TX object
 **********************************************************************************/
static PBV_Datatype_TX_t PBV_TX;          ///< Application TX object

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @struct  App_PBV_Demo_RX
 * @brief   Application RX object
 **********************************************************************************/
static PBV_Datatype_RX_t PBV_RX;          ///< Application RX object

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @struct  App_PBV_Demo_ASCII
 * @brief   Application TX object for ascii
 **********************************************************************************/
static PBV_Datatype_TX_t PBV_ASCII;       ///< Application TX object for ascii

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def  App_PBV_Demo_TX_ptr
 * @brief   pointer to the object. this is if you want to extend the interface, and 
 * have a get function to get the pointer and transmit data from other files.
 **********************************************************************************/
static PBV_Datatype_TX_t * PBV_TX_Ptr = &PBV_TX;        ///< Application TX object pointer

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def  App_PBV_Demo_RX_Ptr
 * @brief   pointer to the RX object. for uniform look and feel
 **********************************************************************************/
static PBV_Datatype_RX_t * PBV_RX_Ptr = &PBV_RX;        ///< Application RX object pointer

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @def  App_PBV_Demo_ASCII_Ptr
 * @brief   pointer to the Ascii object. This can be used to send log data from other 
 * files by getting this pointer
 **********************************************************************************/
static PBV_Datatype_TX_t * PBV_ASCII_Ptr = &PBV_ASCII;  ///< Application TX object ascii pointer


/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @var     buffer_sixteen_bit 
 * @brief   buffer for 16 byte data for TX
 **********************************************************************************/
uint16_t buffer_sixteen_bit[32];

/***********************************************************************************
 * @ingroup PBV_DEMO_FRAME_MAP
 * @var     counter 
 * @brief   a variable to increase cycle count for the TX message
 **********************************************************************************/
uint16_t counter = 0;

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @var     buffer_eight_bit 
 * @brief   buffer for 8 bit data for TX
 **********************************************************************************/
uint8_t buffer_eight_bit[64];

/***********************************************************************************
 * @ingroup PBV_FRAME_MAP
 * @var     buffer_eight_bit_rx 
 * @brief   buffer for 8 bit data for RX
 **********************************************************************************/
uint16_t buffer_eight_bit_rx[32];

/***********************************************************************************
 * 
 **********************************************************************************/
uint16_t gui_vout_ref = 2048;     // buck 3.3V output
uint16_t gui_power_on_off = 1;

/***********************************************************************************
 * Private Function Call Prototypes
 **********************************************************************************/
void Generate_data(void);
void Develop_callback(uint32_t protocol_id, uint16_t length, uint8_t * data);

/***********************************************************************************
 * Private Functions Definitions
 **********************************************************************************/

/***********************************************************************************
 * 
 **********************************************************************************/
void PBV_BuckVoutRefFromGui(uint16_t value)
{
    gui_vout_ref = (int16_t)(__builtin_mulss(value, 15888)>>8);   // 1/10 * 4096/3.3/2 Q8 0~5V
}

/***********************************************************************************
 * 
 **********************************************************************************/
int16_t PBV_BuckVoutRefValue(void)
{
    return gui_vout_ref;
}

/***********************************************************************************
 * 
 **********************************************************************************/
int16_t PBV_BuckPowerOnOffStatus(void)
{
    return gui_power_on_off;
}

/***********************************************************************************
 * 
 **********************************************************************************/
void PVB_BuckPowerOnOffFromGui(uint16_t value)
{
    gui_power_on_off = value;
}

/***********************************************************************************
 * @ingroup app_pbv_public_function
 * @fn     app_PBV_init
 * @param  void
 * @return nothing
 * @brief this function initializes the app_pbv rx and tx objects and 
 * calls the app_pbv_init which links the CAN/RX objects
 **********************************************************************************/
void PBV_init(void)
{
    PBV_TX_Ptr->PBV_Protcol_ID        = PBV_SYSTEM_TO_GUI_ID;
    PBV_TX_Ptr->PBV_Signal_Ascii      = PBV_SIGNAL_MODE;
    PBV_TX_Ptr->PBV_Message_State     = PBV_MESSAGE_INIT;
    PBV_TX_Ptr->Length                = 64;

    PBV_RX_Ptr->PBV_Message_State     = PBV_MESSAGE_READY_TO_RECEIVE;
    PBV_RX_Ptr->Callback_Function     = &Develop_callback;

    PBV_ASCII_Ptr->PBV_Protcol_ID     = FIRMWARE_PROTOCOL_ID;
    PBV_ASCII_Ptr->PBV_Signal_Ascii   = PBV_ASCII_MODE;
    PBV_ASCII_Ptr->PBV_Message_State  = PBV_MESSAGE_INIT;
    PBV_ASCII_Ptr->Length             = 64;
    PBV_ASCII_Ptr->Data_Buffer = (uint8_t *)"1.0.0.0                                                         ";

    PBV_Init(PBV_TX_Ptr, PBV_ASCII_Ptr, PBV_RX_Ptr);
}

/***********************************************************************************
 * @ingroup app_pbv_private_function
 * @fn      app_Generate_data
 * @param   void
 * @return  nothing
 * @brief   this generates a frame for transmission
 **********************************************************************************/
void Generate_data(void)
{
    buffer_sixteen_bit[0] = GetBuckInputVoltage();
    buffer_sixteen_bit[1] = GetBuckOutputVoltage() ;
    buffer_sixteen_bit[2] = GetBuckInductorCurrent();
    buffer_sixteen_bit[3] = GetBuckFalultStatus();
    PBV_Change_from_Sixteen_to_Eight(buffer_sixteen_bit, buffer_eight_bit, 4);
    PBV_TX_Ptr->Data_Buffer = buffer_eight_bit;
}
/***********************************************************************************
 * @ingroup app_pbv_private_function
 * @fn      app_Develop_callback
 * @param   void
 * @return  nothing
 * @brief   this is a simplified sample callback. this checks for the first bytes to switch 
 *  between different actions.
 **********************************************************************************/
void Develop_callback(uint32_t protocol_id, uint16_t length, uint8_t * data)
{
    PBV_Change_from_Eight_to_Sixteen(data, buffer_eight_bit_rx, length);
    
    switch (protocol_id) {
        case PBV_GUI_TO_SYSTEM_CMD_POWER_ON_OFF_ID:
        {
            if (PBV_BuckPowerOnOffStatus() == 1)
            {
                PVB_BuckPowerOnOffFromGui(0);
            }
            else
            {
                PVB_BuckPowerOnOffFromGui(1);
            }
            break;
        }
        case PBV_GUI_TO_SYSTEM_CMD_SET_VOLTAGE_ID:
        {
            PBV_BuckVoutRefFromGui(buffer_eight_bit_rx[0]);
            break;
        }
        default:
            break; 
    }
}

/*********************************************************************************
 * @ingroup APP_PBV 
 * @fn      app_PBV_Task_10ms()
 * @param   none
 * @brief   task to be executed every 1ms
 * @return  void
 * @details 
 *
 * mcc implements a queuing buffer
 **********************************************************************************/
void PBV_Task_10ms(void)
{
    // Reading received message
    if (PBV_RX_Ptr->PBV_Message_State == PBV_MESSAGE_RECEIVED)
    {        
        Read_Received_From_PBV(PBV_RX_Ptr);
        PBV_RX_Ptr->Callback_Function(PBV_RX_Ptr->PBV_Protcol_ID, PBV_RX_Ptr->Length, PBV_RX_Ptr->Data_Buffer);
        Receive_From_PBV(PBV_RX_Ptr); 
    }

    // Sending message
    if (++counter == 10)
    {
        Send_To_PBV(PBV_ASCII_Ptr);
        counter = 0;
    }
    else
    {
        Generate_data();
        Send_To_PBV(PBV_TX_Ptr);
    }
}

/*********************************************************************************
 * @ingroup  
 * @fn     app_PBV_Task_100us()
 * @param   
 * @brief   Task to be executed every 100 us
 * @return  void
 * @details 
 *  task that is to be executed every 100 us (UART) for executing UART State machine.
 * calling task has to ensure that the system is not overloaded 
 **********************************************************************************/
void PBV_Task_100us(void)
{
    PBV_Task();
}

/*******************************************************************************
 * end of file
 *******************************************************************************/
/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */
//Fit to drive OLED!!
//ENV MCHP DELL PC MPLAB 6.20, official MCC, works
/*
LED0 : RC3
1:  4
2:5
3:6
4:7
LED 5,6,7 :  RC8,9,10
 * RGB LED: p68,70,72
 * SPI_SCK:P83 RC0,  SDO: P87 RC11 OK!  SDI RD1;  CS:  RB7
POTI? ADC AN6  RA7 ADC1_Channel6, trigger:  SCPP1 trigger Event works! Set SCCP1 Plib: Special Event Trig ouput!
 * 
 * OLED  DC: Mikrobus TX RB10
 * Timer_SCCP  100us
 * Timer SCCP2 1s --> Task_1s
 * Timer1  100ms  TMR_INT_CNT
 */

//V1.9B added graw title function for SSD1327 GUI
//V1.9 added Btn S1,S2,S3 GUI rendering on SSD1309 OLED																			 
//V1.8 added ssd1309 OLED driver, working ! check pin connection!!!
//V1.7B improved pixel shift function to prevent OLED from burning!
//V1.7 re-MCC, added IIC2, LEDs, Key INT and CPU 200Mhz works!
//V1.6B added PWM OLED GUI display and 
//V1.6 SPI OLED driver optimized, solved low efficiency issue!
//V1.5 SPI OLED writecmd issue with DC signal early high causing data write corruption ,solved by insert SPI1_IsTxReady flag check, but lowwed SPI efficiency!
//V1.4 SPI OLED basic function works!, still some issues!
//V1.3 added PWM-->RGB LED dimming
//V1.2 ADC measure die temp and bandgap is OK~!
//V1.1 ADC UART works, SPI issues!
//V1.0 basic demo with MCC melody works

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "mcc_generated_files/adc/adc1.h"
#include "mcc_generated_files/pwm_hs/pwm.h"
#include "mcc_generated_files/spi_host/spi1.h"
#include "mcc_generated_files/timer/sccp2.h"
//bsp
#include "bsp/led_red.h"
#include "bsp/led_blue.h"
#include "bsp/led_green.h"
#include "bsp/led_color.h"
#include "bsp/led_rgb.h"
#include "bsp/s1.h"
#include "bsp/s2.h"
#include "bsp/s3.h"
//OLED
							  
#include "SSD1327/SSD1327.h"
#include "SSD1309/bmp.h"
						
#include "SSD1309/AK_dsPIC_1.h"
//#include "SSD1309/BG_girl_4bit.h"
#include "SSD1309/ssd1309.h"
															

#include <stdio.h>
#include <string.h>
#include "stdbool.h"
//#include "SSD1327/SSD1327.h"
		   
#define FCY 8000000UL
//#define FCY 200000000UL
	  
//#define FCY 100000000UL
#include <libpic30.h>
//int main() {
///* at 1MHz, these are equivalent */
//__delay_us(1000);
//__delay32(1000);
//}


/*
    Main application
 */
//global vars
#define SSD1327_OLED_EN 1
#define SSD1309_OLED_EN 0
#define debug_info_EN 1
#define printf_cnt_interval 10
#define OLED_display_interval 7
#define OLED_saver_interval 15 //20s

#define SPI_bus_1M 0
#define SPI_bus_125K 1
#define SPI_bus_4M 2
#define SPI_bus_2M 3
float Die_temp = 0;
float VCC_voltage = 3.3;
uint16_t ADC_res_temp = 0;
float ADC_res_float = 0;
uint16_t ADC_poti = 0;
float Poti_voltage = 0;

uint32_t ADC_INT_flag = 0;
//Btn INT
uint8_t Btn_S1_pressed = 0;
uint8_t Btn_S2_pressed = 0;
uint8_t Btn_S3_pressed = 0;

//PWM
uint32_t PWM1_Per_def = 1264;// 100Khz? default value
uint8_t  PWM1_Freq_mode = 0;


//system tick
uint32_t sys_tck = 0; //125ns per cnt
uint32_t sys_tck_lsb_scale = 8; // 8M
uint32_t sys_tmr_per = 1000000; //1s in us scale
uint32_t TMR_1s_cnt = 0;
uint32_t TMR_1s_cnt_tmp = 0;
uint32_t TMR_INT_CNT = 0;
uint8_t TMR_INT_Flag = 0;
//extern uint8_t CMD_TX_buf[];
char tmp_string[48];
uint8_t scroll_dir = 0;
uint8_t scroll_part = 0; //top half or bot half
uint8_t scroll_enable = 1;
uint16_t shift_cnt = 0;
uint8_t Pixel_shift_cnt = 0; //to save oled burning by shifting display pixels!
uint8_t Pixel_shift_dir = 0;
uint8_t shifting_active_flg = 0;
#define shift_cnt_threshold 8

//prototypes
static void PWM1_freq_ADC_set(uint16_t request);
static void setRGBIntensity(uint16_t potentiometerReading);
static void OLED_show_Btn_status(void);
float ADCConvert_Die_Temp(void);
uint16_t ADCConvert_Die_Temp_int(void);
float ADCConvert_AN14_internal(void);
long ADCConvert0p8V(void);

void TMR1_TimeoutCallback(void) {
    TMR_INT_CNT++;
    TMR_INT_Flag = 1;
}
extern void OLED_Reset(void);
void OLED_draw_startup_screen(void);
void OLED_draw_GUI_BG_frame(void);
void OLED_draw_GUI_title( uint8_t update_EN);
void OLED_draw_PWM_info(void);
void OLED_pixel_shift_L(void);
void OLED_pixel_shift_R(void);

void Task_1s(void);

int main(void) {
    SYSTEM_Initialize(); //8M default
    printf("< dsPIC33AK Curiosity DIM MPLAB 6.20 melody test demo>\r\n");
					   
															
							 
    printf("< SSD1327 OLED driver for dsPIC33A >\r\n");
    printf("-Version 1.9, 23.Oct.2024 by Zell-\r\n");
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("--FW code compiled with XC16 Version: %d\n", __XC16_VERSION__ );
    printf("--Platform has DSP engine: %d\n", __HAS_DSP__ );
    int32_t tick_diff = 0;
    uint32_t sys_tck_post = 0;
    uint32_t time_interval_us = 0;
    uint32_t SCCP_PER_def = SCCP2_Timer_PeriodGet();
    //SCCP1_Timer_PeriodGet();
    ADC_res_float = ADCConvert_AN14_internal();
    printf("#>:ADC Internal CH14 voltage is %3.3f V!\r\n", ADC_res_float);
    ADC_res_float = 15.0 * ADC_res_float / 14.0;
    printf("#>:Calculated VCC input voltage is %3.3f V! Update VCC para to current value!\r\n", ADC_res_float);
    VCC_voltage = ADC_res_float;
    Die_temp = ADCConvert_Die_Temp();
    printf("#>: Approx. dsPIC Die Temperature is %3.1f degree!\r\n", Die_temp);

    ADC_res_temp = ADCConvert_Die_Temp_int();
    printf("#>: Raw dsPIC Die Temperature is %u !\r\n", ADC_res_temp);
    ADC_res_temp = ADCConvert0p8V();
    ADC_res_float = ADC_res_temp * VCC_voltage / 4096.0;
    printf("#>:ADC bandgap voltage raw is %u !\r\n", ADC_res_temp);
    printf("#>:ADC bandgap voltage is %3.3f V!\r\n", ADC_res_float);

    printf("#>:SPI bus init...\r\n");
    uint8_t open_res = SPI1_Open(SPI_bus_2M); //1M
    uint8_t reg_val1 = SPI1CON1bits.CKE;
    uint8_t reg_val2 = SPI1CON1bits.CKP;
    uint8_t SPI_mode = SPI1CON1bits.MODE;
    if (open_res) {
        printf("#>:SPI bus init with CKE:%d; CKP:%d ; Mode:%d\r\n", reg_val1, reg_val2, SPI_mode);
        printf("#>:SPI SPI1CON1:%lu\r\n", SPI1CON1);

    }
    if (SSD1309_OLED_EN) {
        LED5_RC8_Toggle();
        printf("#>:SSD1309 OLED init...\r\n");
        SSD1309_OLED_Init();
        SSD1309_OLED_ColorTurn(0); //0???? 1????
        SSD1309_OLED_DisplayTurn(0); //0???? 1??180???
        __delay_ms(200);
        //SSD1309_OLED_DisPlay_On();
        //printf("#>:SSD1309 OLED show ASCII now...\r\n");
        //OLED_CS_High();
        //OLED_ShowString(0,48,"ASCII:",16,1); 
        SSD1309_OLED_Refresh();
        __delay_ms(100);
        printf("#>:SSD1309 OLED draw Picture 1 now...\r\n");
        OLED_ShowPicture(0, 0, 128, 64, BMP1, 1);
        SSD1309_OLED_Refresh();//push to GRAM
        __delay_ms(1000);
        
         LED5_RC8_Toggle();
        OLED_CS_Set();
        printf("#>:SSD1309 OLED draw Chinese char...\r\n");
        //OLED_ShowChinese(0, 0, 0, 16,1); //?
        //OLED_ShowChinese(18, 0, 1, 16,1); //?
        //OLED_ShowChinese(36, 0, 2, 16,1); //?
        OLED_ShowString(0, 0, "dsPIC A", 16, 1);
        OLED_ShowChinese(54, 0, 3, 16, 1); //?
        OLED_ShowChinese(72, 0, 4, 16, 1); //?
        OLED_ShowChinese(90, 0, 5, 16, 1); //?
        OLED_ShowChinese(108, 0, 6, 16, 1); //?
        SSD1309_OLED_Refresh();
        __delay_ms(500);
        
        SSD1309_OLED_Clear();
		SSD1309_OLED_ShowPicture(0, 0, 128, 56, gImage_AK_dsPIC_3n, 1);	
        SSD1309_OLED_Refresh();
        printf("#>:SSD1309 OLED draw Picture 2 now...\r\n");

        __delay_ms(1000);
        //SSD1309_OLED_Clear();
       
        //SSD1309_OLED_Refresh();
       
        //SSD1309_OLED_Refresh();
        //        while (1) {
        //             OLED_CS_Set();
        //            LED5_RC8_Toggle();
        //            OLED_ShowString(0,48,"ASCII:",16,1); 
        //            SSD1309_OLED_Refresh();
        //             OLED_CS_Set();
        //            __delay_ms(200);
        //        }

    }


    if (SSD1327_OLED_EN) {
        printf("#>:SSD1327 OLED init...\r\n");
        SSD1327_OLED_Reset();
        __delay_us(100);
        SPI_DC_RB10_SetHigh();
        printf("#>:SSD1327 OLED Reset finished!\r\n");
        SPI_DC_RB10_SetLow();
        SPI_CS_RB7_SetLow();
        SSD1327_OLED_Init(); //has issues, no sck output!
        //SPI1_ByteExchange(0xaa);//has issues
        printf("#>:SSD1327 OLED Reg init finished!\r\n");
        clearBuffer();
        //__delay_us(100);

        SSD1327_FillBuffer(); ////fill all pixels to 1, appears in grey color
        //SSD1327_Buffer_White();
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        writeFullBuffer(); //clear display
        sys_tck_post = SCCP2_Timer_CounterGet();
        tick_diff = sys_tck_post - sys_tck;
        //tick_diff = sys_tmr_per*TMR_1s_cnt+SCCP2_Timer_CounterGet()-sys_tck; 
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        TMR_1s_cnt = 0;
        printf(">>:writeFullBuffer Time cost: %lu us\r\n", time_interval_us);
        __delay_ms(100);
        //printf(">#OLED frame buffer cleared!\r\n");
        //SPI_CS_RB7_SetHigh();
        //__delay_ms(200);
        clearBuffer();
        SSD1327_FillBuffer_black(); //test works!
        writeFullBuffer();
        SPI_CS_RB7_SetHigh();
        clearBuffer();
        SPI_CS_RB7_SetLow();
        LED5_RC8_Toggle();
        //    drawPixel(2,2,4,true);
        //    __delay_us(2);
        //    drawPixel(65,1,5,true);
        //    __delay_us(2);

        clearBuffer();
        printf(">>:OLED Drawing bench test now:\r\n");
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        OLED_testfillrect(6);
        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        printf(">>:OLED_testfillrect cost: %lu ms, 1s_cnt: %lu, raw:%lu\r\n", time_interval_us / 1000, TMR_1s_cnt, time_interval_us);

        //testdrawcircle();
        LED5_RC8_Toggle();
        //__delay_ms(200);
        //OLED_testfillrect(3);
        setupScrolling(0, OLED_Width / 2 - 1, 0, OLED_Height / 2 - 1, SSD1327_SCROLL_6, 1); //test ok
        startScrolling();
        __delay_ms(300);
        stopScrolling();
        setupScrolling(0, OLED_Width / 2 - 1, 0, OLED_Height / 2 - 1, SSD1327_SCROLL_4, 0);
        startScrolling();

        __delay_ms(200);
        stopScrolling();
        //printf(">#OLED Draw startup screen now:\r\n");
        //SPI_CS_RB7_SetLow();
        clearBuffer();
        //SSD1327_FillBuffer_black();
        //writeFullBuffer();
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        __delay_us(100);

        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        printf(">>:delay 100us Time cost: %lu us\r\n", time_interval_us);
        // OLED_fastfillrect(2);
        //__delay_ms(200);
        //    testfilltriangle();
        //    //    __delay_ms(300);
        clearBuffer();
        ClrWdt();
        Nop();

        SSD1327_FillBuffer_black();
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        writeFullBuffer_fast();
        sys_tck_post = SCCP2_Timer_CounterGet();
        //tick_diff = sys_tck_post-sys_tck; 
        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        TMR_1s_cnt = 0;
        printf("#>:Fast writeFullBuffer Time cost: %lu us\r\n", time_interval_us);


        //    //ClrWdt();
        testdrawcircle();
        clearBuffer();

        //----------
        //memset(tmp_string,0,sizeof(tmp_string));
        //uint8_t TXT_brightness = 4;
        //uint8_t txt_size = 8;
        //sprintf(tmp_string, "Demo by Zell 2023"); //OLED  slide_pos 0-255
        //drawCharArray(8, 8, tmp_string, TXT_brightness, txt_size);
        //writeUpdates();

        clearBuffer();
        OLED_draw_startup_screen(); //issues!
        //__delay_ms(100);
    }
    ADC1_IndividualChannelInterruptEnable(ADC1_Channel6); //poti
    ADC1_IndividualChannelInterruptEnable(ADC1_Channel10); //poti
    TMR1_Start();
    TMR_INT_Flag = 0;

    //PG1DC= (uint16_t)(PG1PER*0.25);
    //PG1DC= PG1PER>>3;
    PWM_Enable();
    uint32_t DC_temp = 0; // *100 scale
    float DC_float_tmp = 0;
    Nop();
    ClrWdt();
    printf(">>#: main loop running now!\r\n");
    //OLED_draw_GUI_BG_frame();
    TMR_1s_cnt = 0;
    //uint32_t TMR_1s_cnt_tmp = 0;
    while (1) {
        if (TMR_INT_Flag) {

            if (100 == TMR_INT_CNT) {
                if (SSD1309_OLED_EN) {
                    SSD1309_OLED_Clear();
                } else if (SSD1327_OLED_EN) {
                    stopScrolling();
                    clearBuffer();
                    SSD1327_FillBuffer_black(); //test works!
                    writeFullBuffer_fast();
                    scroll_enable = 0;
                    drawRect_transitionBand(0, 0, 127, 7, 15, 1);
                    drawRect(0, 8, OLED_Width - 1, OLED_Height - 1, 0, 1); //clear rest part of the screen
                    OLED_draw_GUI_BG_frame();
                    __delay_us(50);
                    OLED_draw_GUI_title( 1);
                }
            }

            if ((0 == TMR_INT_CNT % OLED_display_interval)&&(100 < TMR_INT_CNT)) {
                stopScrolling();
                //clearBuffer();

                //                SSD1327_FillBuffer_black(); //test works!
                //                writeFullBuffer();
                TMR_1s_cnt_tmp = TMR_1s_cnt;
                sys_tck = SCCP2_Timer_CounterGet();
                clearBuffer();
                OLED_draw_GUI_title(0);
                //clearFrameBuffer(0,8,OLED_Width,OLED_Height-8); //30ms
                //---update displays
                OLED_draw_PWM_info();
                //---
                tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
                time_interval_us = sys_tmr_per * (TMR_1s_cnt - TMR_1s_cnt_tmp) + tick_diff / sys_tck_lsb_scale;
                printf(">>:OLED_draw Time: %lu ms\r\n", time_interval_us / 1000);
                //if(shifting_active_flg)
                //   startScrolling();


            }



            if (0 == TMR_INT_CNT % printf_cnt_interval) {
                stopScrolling();
                printf("---AK_test loop cnt:%lu ---\r\n", TMR_INT_CNT);
                // printf("buf: %#X,%#X \r\n", CMD_TX_buf[0],CMD_TX_buf[1] );
                Die_temp = ADCConvert_Die_Temp();
                printf("#>: Approx. Die Temperature is %3.1f degree\r\n", Die_temp);
                //printf("#>: Raw Poti voltage: %u, INT_flag cnt=%lu \r\n", ADC_poti, ADC_INT_flag); //issues



                Poti_voltage = VCC_voltage * ADC_poti / 4096;
                printf("#>: Poti voltage: %3.3f V,INT_flag cnt=%lu \r\n", Poti_voltage, ADC_INT_flag);
                DC_temp = 100 * PG1DC / PG1PER;
                DC_float_tmp = 100.0 * PG1DC / PG1PER;
                printf("#>: PWM1 DC= %lu %%,%2.1f%%", DC_temp, DC_float_tmp);
                DC_temp = 100 * PG2DC / PG2PER;
                printf("#>: PWM2 DC= %lu %%", DC_temp);
                DC_temp = 100 * PG4DC / PG4PER;
                printf("#>: PWM4 DC= %lu %%\r\n", DC_temp);




                //if (scroll_dir){
                //setupScrolling(uint8_t startRow, uint8_t endRow, uint8_t startCol, uint8_t endCol, uint8_t scrollSpeed, bool right)
                //stopScrolling();
                if ((scroll_enable) &&(SSD1327_OLED_EN)) {
                    scroll_part++;
                    scroll_dir = 1 - scroll_dir;

                    stopScrolling();
                    if ((3 == scroll_part) || (4 == scroll_part)) {
                        setupScrolling((OLED_Height / 2 - 7), OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_4, scroll_dir);
                        scroll_part = 0;
                    } else {
                        setupScrolling(0, (OLED_Height / 2 - 8), 0, OLED_Width / 2 - 1, SSD1327_SCROLL_6, scroll_dir); //test ok
                    }

                    //setupScrolling(0, (OLED_Width / 2 - 1),  OLED_Height / 2 - 7, OLED_Height-1, SSD1327_SCROLL_6, 1-scroll_dir); //test ok
                    startScrolling();
                }
                // }
                //  else {
                // setupScrolling(0, (OLED_Width / 2 - 1), 0, OLED_Height / 2 - 1, SSD1327_SCROLL_4, 0);
                // startScrolling();
                //  }



                ADC_INT_flag = 0;
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_1);
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_2);
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_4);
                //__delay_us(100);

                //PWM_DutyCycleSet(PWM_GENERATOR_4, ADC_poti);

            }
            LED5_RC8_Toggle(); //LED5
            if (PWM1_Freq_mode){
                printf("#>: PWM1 Freq will be changed based on ADC value:%d\r\n", ADC_poti);
                PWM1_freq_ADC_set(ADC_poti);
                printf("#>: PWM1 Period new value:%d \r\n", PG1PER);
            }
            else{
                setRGBIntensity(ADC_poti); //issue solved, update manually
            }
            TMR_INT_Flag = 0;

        }
        //_delay_ms(500);
    }
}

void Task_1s(void) {

    OLED_show_Btn_status();
    //if (4 < (TMR_1s_cnt - TMR_1s_cnt_tmp)) {
    if (0 == (TMR_1s_cnt % 3)) {
        TMR_1s_cnt_tmp = TMR_1s_cnt;

        if (Pixel_shift_dir)
            Pixel_shift_cnt++;
        else
            Pixel_shift_cnt--;

        //Pixel_shift_dir=1-Pixel_shift_dir;
        if (254 < Pixel_shift_cnt) {
            Pixel_shift_cnt = 0;
            Pixel_shift_dir = 1;
        } else if (Pixel_shift_cnt > shift_cnt_threshold) {
            Pixel_shift_cnt = shift_cnt_threshold;
            //shifting_active_flg = 1;
            Pixel_shift_dir = 0;
        }

    }
    if (SSD1327_OLED_EN) {
        if ((0 == TMR_1s_cnt % OLED_saver_interval)&&(141 < TMR_INT_CNT)) {
            LED6_RC9_Toggle();
            shift_cnt = 0;
            shifting_active_flg = 1;
            //stopScrolling();
            if (scroll_dir) {

                OLED_pixel_shift_R();
                OLED_pixel_shift_L();
            } else {
                OLED_pixel_shift_L();
                OLED_pixel_shift_R();
            }
            //clearBuffer();
            //SSD1327_FillBuffer_black(); //test works!
            //writeFullBuffer_fast();
            scroll_dir = 1 - scroll_dir;
            shifting_active_flg = 0;
            //scroll_dir = 1 - scroll_dir;
            //LED6_RC9_Toggle();
        }
    }



}

long ADCConvert0p8V(void) {
    // 0.8V is connected to Ch15
    //AD1SWTRGbits.CH2TRG = 1; // trigger channel 2
    //while(AD1STATbits.CH2RDY == 0); // wait for 64 results accumulated
    uint16_t res = 0;
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel15);
    while (ADC1_IsConversionComplete(ADC1_Channel15) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel15);
    return res;
    //    if ((res >> 3) == 0) {
    //        while (1);
    //    }
    //    return (res >> 3);
}

//long ADCConvertPot()
//{
//    // pot is connected to RA7/AN0
//    AD5SWTRGbits.CH0TRG = 1; // trigger channel 0
//    while(AD5STATbits.CH0RDY == 0); // wait for result
//    return AD5CH0DATA;
//}

float ADCConvert_Die_Temp(void) {
    float temp_die = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel13);
    while (ADC1_IsConversionComplete(ADC1_Channel13) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel13);
    temp_die = ((float) res / 4096.0) * VCC_voltage;
    temp_die = (temp_die * (-585.0))+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //1.5mv/degree??
    // celsius = (diode_voltage *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //further characterization required to optimize accuracy.
    //fahrenheit = 9.0 * celsius / 5.0 + 32;
    //return ADC1_ConversionResultGet(ADC1_Channel13);
    return temp_die;
    //return res;
}

uint16_t ADCConvert_Die_Temp_int(void) {
    //float temp_die = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel13);
    while (ADC1_IsConversionComplete(ADC1_Channel13) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel13);
    //temp_die = (res *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    // celsius = (diode_voltage *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //further characterization required to optimize accuracy.
    //fahrenheit = 9.0 * celsius / 5.0 + 32;
    //return ADC1_ConversionResultGet(ADC1_Channel13);
    //return temp_die;
    return res;
}

//compensate for VCC_voltage
float ADCConvert_AN14_internal(void) {
    float temp = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel14);
    while (ADC1_IsConversionComplete(ADC1_Channel14) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel14);
    temp = ((float) res / 4096.0) * VCC_voltage;

    return temp;
    //return res;
}

static void setRGBIntensity(uint16_t potentiometerReading) {
    ledRed.setIntensity(potentiometerReading);
    ledGreen.setIntensity(potentiometerReading);
    ledBlue.setIntensity(potentiometerReading);
}


static void OLED_show_Btn_status(void){
    uint8_t x_pos = 8;
    uint8_t y_pos = 8;
    uint8_t  txt_size = 8;
     if (SSD1309_OLED_EN) {
       
        x_pos = 0;
        y_pos = 36;
        //y_spacing = 2;
        
         memset(&tmp_string, 0, sizeof (tmp_string));
       // y_pos = y_pos + txt_size;
        //txt_size = 12;
        sprintf(tmp_string, "Btn1:%u Btn2:%u Btn3:%u ", Btn_S1_pressed,Btn_S2_pressed,Btn_S3_pressed); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        Btn_S1_pressed = 0;
        Btn_S2_pressed = 0;
        Btn_S3_pressed = 0;
        memset(&tmp_string, 0, sizeof (tmp_string));
        
     }
    
}


void OLED_draw_startup_screen(void) {
    //uint8_t width = 128;
    //uint8_t height = 64;
    uint8_t x_pos = 8;
    uint8_t y_pos = 8;

    uint8_t TXT_brightness = 3;
    uint8_t txt_size = 8; //8,16,32
    //clearFrameBuffer(0,0, width, height); //x,y
    //memset(&tmp_string, NULL, sizeof (tmp_string));
    memset(&tmp_string, 0, sizeof (tmp_string));
    sprintf(tmp_string, "SSD1327 OLED"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    memset(&tmp_string, 0, sizeof (tmp_string));
    TXT_brightness = 5;
    sprintf(tmp_string, "Demo Zell 2024"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos + txt_size, tmp_string, TXT_brightness, txt_size);
    TXT_brightness = 7;
    txt_size = 16;
    x_pos = 4;
    y_pos = y_pos + txt_size * 2;
    sprintf(tmp_string, "dsPIC33A 32bit"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    TXT_brightness = 6;
    y_pos = y_pos + txt_size;
    txt_size = 32;
    x_pos = 8;
    sprintf(tmp_string, "4Bit"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    TXT_brightness = 7;
    y_pos = y_pos + txt_size;
    x_pos = 4;
    txt_size = 16;
    sprintf(tmp_string, "16 Greyscale"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);

    //writeUpdates();
    writeFullBuffer_fast();
}

void OLED_draw_GUI_BG_frame(void) {

    uint8_t pixel_brightness = 2;
    drawRect(0, OLED_Width - 1, 0, OLED_Height - 1, pixel_brightness, true);
    pixel_brightness = 0;
    drawRect(2, OLED_Width - 3, 0, OLED_Height - 3, pixel_brightness, true);
    //writeUpdates();
}

void OLED_draw_GUI_title( uint8_t update_EN) {

    uint8_t x_pos = 4;
    uint8_t y_pos = 4;
    uint8_t TXT_brightness = 2;
    uint8_t txt_size = 8; //8,16,32
    //uint8_t y_spacing = 0;
    
    sprintf(tmp_string, "dsPIC33A 32bit"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    if(update_EN){
        writeUpdates(); //oled update GRAM
    }
}



void OLED_draw_PWM_info(void) {
    //    uint8_t width = 128;
    //    uint8_t height = 64;
    uint8_t x_pos = Pixel_shift_cnt;
    uint8_t y_pos = 15;
    uint8_t y_spacing = 0;

    uint8_t TXT_brightness = 3;
    uint8_t txt_size = 16; //8,16,32

    uint16_t freq = 0;
    uint16_t DC_temp = 0;

    if (SSD1327_OLED_EN) {

        //clearFrameBuffer(0,0, width, height); //x,y
        //memset(&tmp_string, NULL, sizeof (tmp_string));
        if (PWM1_Freq_mode){
            drawCircle(OLED_Width-10,y_pos+txt_size/2 , 3, TXT_brightness);
            drawCircle(OLED_Width-10,y_pos+txt_size+txt_size/2 , 3, 0);
        }
        else {
             drawCircle(OLED_Width-10,y_pos+txt_size/2 , 3, 0);
             drawCircle(OLED_Width-10,y_pos+txt_size+txt_size/2 , 3, TXT_brightness);
        }
        
        memset(&tmp_string, 0, sizeof (tmp_string));
        freq = 127968 / PG1PER;  //PER 1264
        DC_temp = 100 * PG1DC / PG1PER;
        sprintf(tmp_string, "PWM1:%u Khz", freq); //OLED  slide_pos 0-255
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        TXT_brightness = 4;
        y_pos += txt_size;

        sprintf(tmp_string, "DC:%u%%", DC_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        TXT_brightness = 3;
        //    txt_size =16;
        //   x_pos = 4;
        y_pos = y_pos + txt_size;
        freq = 127968 / PG2PER;
        DC_temp = 100 * PG2DC / PG2PER;

        sprintf(tmp_string, "PWM2:%u Khz", freq); //OLED  slide_pos 0-255
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos += txt_size;
        TXT_brightness = 4;
        sprintf(tmp_string, "DC:%u%%", DC_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);

        TXT_brightness = 2;
        y_pos = y_pos + txt_size;
        freq = 127968 / PG4PER;
        DC_temp = 100 * PG4DC / PG4PER;
        sprintf(tmp_string, "PWM4:%u Khz", freq); //OLED  slide_pos 0-255
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos += txt_size;
        TXT_brightness = 4;
        sprintf(tmp_string, "DC:%u%%", DC_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);

        TXT_brightness = 1;
        y_pos = OLED_Height - txt_size - 1;
        memset(&tmp_string, 0, sizeof (tmp_string));
        sprintf(tmp_string, "T_die:%3.1fC", Die_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));

        writeUpdates(); //oled update GRAM
        //writeFullBuffer();
    } else if (SSD1309_OLED_EN) {
        txt_size = 8;
        x_pos = 0;
        y_pos = 0;
        y_spacing = 4;
        //SSD1309_OLED_Clear();

        memset(&tmp_string, 0, sizeof (tmp_string));
        freq = 127968 / (PG1PER);
        DC_temp = 100 * PG1DC / PG1PER;
        sprintf(tmp_string, "PWM1:%u Khz", freq); //OLED  slide_pos 0-255
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);

        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos = y_pos + txt_size;
        txt_size = 12;
        sprintf(tmp_string, "DC1:%u%% ", DC_temp); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        
        txt_size = 8;
        freq = 127968 / PG2PER;
        DC_temp = 100 * PG2DC / PG2PER;
        y_pos = y_pos + txt_size+y_spacing;
        memset(&tmp_string, 0, sizeof (tmp_string));
        sprintf(tmp_string, "PWM2:%u Khz", freq); //OLED  slide_pos 0-255
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos = y_pos + txt_size;
        //txt_size = 12;
        sprintf(tmp_string, "DC2:%u%% ", DC_temp); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        

        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos = OLED_1309_Height - txt_size;
        txt_size = 16;
        sprintf(tmp_string, "T_die:%3.1fC", Die_temp); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        SSD1309_OLED_Refresh();

    }
}


static void PWM1_freq_ADC_set(uint16_t request)
{  
    //SCCP1_PWM_DutyCycleSet(request);
    //MAX PWM1_Per_def/5  500Khz
    //Min PWM1_Per_def*2  50Khz
    uint32_t PER_max = PWM1_Per_def*2;
    uint32_t PER_min = PWM1_Per_def/5;
    uint32_t Per_tmp = PER_min+(PER_max-PER_min)*(4096-request)/4096;
    uint32_t DC_tmp = 1000*PG2DC/PG2PER;
    DC_tmp = DC_tmp*Per_tmp/1000;
    //request = request*PG1PER/4096;
    PWM_PeriodSet(PWM_GENERATOR_1, Per_tmp);
    PWM_DutyCycleSet(PWM_GENERATOR_1, DC_tmp);
    //PWM_DutyCycleSet(PWM_GENERATOR_1, request);
    PWM_SoftwareUpdateRequest (PWM_GENERATOR_1);
} 


//protect OLED from permant showing fixed patterns

void OLED_pixel_moving(void) {
    uint8_t scroll_dir = 1;
    stopScrolling();
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    startScrolling();
    __delay_ms(100);
    stopScrolling();
    scroll_dir = 0;
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    //setupScrolling(0, (OLED_Width / 2 - 1),  OLED_Height / 2 - 7, OLED_Height-1, SSD1327_SCROLL_6, 1-scroll_dir); //test ok
    startScrolling();
    __delay_ms(100);
    stopScrolling();

}

void OLED_pixel_shift_L(void) {
    uint8_t scroll_dir = 0;
    stopScrolling();
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    startScrolling();
    __delay_ms(60);
    stopScrolling();


}

void OLED_pixel_shift_R(void) {
    uint8_t scroll_dir = 1;
    stopScrolling();
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    startScrolling();
    __delay_ms(60);
    stopScrolling();


}
//end of main
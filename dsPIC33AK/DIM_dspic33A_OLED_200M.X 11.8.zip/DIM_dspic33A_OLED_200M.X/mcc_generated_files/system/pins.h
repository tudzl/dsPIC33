/**
 * PINS Generated Driver Header File 
 * 
 * @file      pins.h
 *            
 * @defgroup  pinsdriver Pins Driver
 *            
 * @brief     The Pin Driver directs the operation and function of 
 *            the selected device pins using dsPIC MCUs.
 *
 * @skipline @version   PLIB Version 1.0.1-rc.1
 *
 * @skipline  Device : dsPIC33AK128MC106
*/

/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H
// Section: Includes
#include <xc.h>

// Section: Device Pin Macros

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RA6 GPIO Pin which has a custom name of S3_RA6 to High
 * @pre      The RA6 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define S3_RA6_SetHigh()          (_LATA6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RA6 GPIO Pin which has a custom name of S3_RA6 to Low
 * @pre      The RA6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define S3_RA6_SetLow()           (_LATA6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RA6 GPIO Pin which has a custom name of S3_RA6
 * @pre      The RA6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define S3_RA6_Toggle()           (_LATA6 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RA6 GPIO Pin which has a custom name of S3_RA6
 * @param    none
 * @return   none  
 */
#define S3_RA6_GetValue()         _RA6

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RA6 GPIO Pin which has a custom name of S3_RA6 as Input
 * @param    none
 * @return   none  
 */
#define S3_RA6_SetDigitalInput()  (_TRISA6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RA6 GPIO Pin which has a custom name of S3_RA6 as Output
 * @param    none
 * @return   none  
 */
#define S3_RA6_SetDigitalOutput() (_TRISA6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB4 GPIO Pin which has a custom name of S2_RB4 to High
 * @pre      The RB4 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define S2_RB4_SetHigh()          (_LATB4 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB4 GPIO Pin which has a custom name of S2_RB4 to Low
 * @pre      The RB4 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define S2_RB4_SetLow()           (_LATB4 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB4 GPIO Pin which has a custom name of S2_RB4
 * @pre      The RB4 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define S2_RB4_Toggle()           (_LATB4 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB4 GPIO Pin which has a custom name of S2_RB4
 * @param    none
 * @return   none  
 */
#define S2_RB4_GetValue()         _RB4

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB4 GPIO Pin which has a custom name of S2_RB4 as Input
 * @param    none
 * @return   none  
 */
#define S2_RB4_SetDigitalInput()  (_TRISB4 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB4 GPIO Pin which has a custom name of S2_RB4 as Output
 * @param    none
 * @return   none  
 */
#define S2_RB4_SetDigitalOutput() (_TRISB4 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB5 GPIO Pin which has a custom name of S1_RB5 to High
 * @pre      The RB5 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define S1_RB5_SetHigh()          (_LATB5 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB5 GPIO Pin which has a custom name of S1_RB5 to Low
 * @pre      The RB5 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define S1_RB5_SetLow()           (_LATB5 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB5 GPIO Pin which has a custom name of S1_RB5
 * @pre      The RB5 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define S1_RB5_Toggle()           (_LATB5 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB5 GPIO Pin which has a custom name of S1_RB5
 * @param    none
 * @return   none  
 */
#define S1_RB5_GetValue()         _RB5

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB5 GPIO Pin which has a custom name of S1_RB5 as Input
 * @param    none
 * @return   none  
 */
#define S1_RB5_SetDigitalInput()  (_TRISB5 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB5 GPIO Pin which has a custom name of S1_RB5 as Output
 * @param    none
 * @return   none  
 */
#define S1_RB5_SetDigitalOutput() (_TRISB5 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB6 GPIO Pin which has a custom name of SPI_RST_RB6 to High
 * @pre      The RB6 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define SPI_RST_RB6_SetHigh()          (_LATB6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB6 GPIO Pin which has a custom name of SPI_RST_RB6 to Low
 * @pre      The RB6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define SPI_RST_RB6_SetLow()           (_LATB6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB6 GPIO Pin which has a custom name of SPI_RST_RB6
 * @pre      The RB6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define SPI_RST_RB6_Toggle()           (_LATB6 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB6 GPIO Pin which has a custom name of SPI_RST_RB6
 * @param    none
 * @return   none  
 */
#define SPI_RST_RB6_GetValue()         _RB6

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB6 GPIO Pin which has a custom name of SPI_RST_RB6 as Input
 * @param    none
 * @return   none  
 */
#define SPI_RST_RB6_SetDigitalInput()  (_TRISB6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB6 GPIO Pin which has a custom name of SPI_RST_RB6 as Output
 * @param    none
 * @return   none  
 */
#define SPI_RST_RB6_SetDigitalOutput() (_TRISB6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB7 GPIO Pin which has a custom name of SPI_CS_RB7 to High
 * @pre      The RB7 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define SPI_CS_RB7_SetHigh()          (_LATB7 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB7 GPIO Pin which has a custom name of SPI_CS_RB7 to Low
 * @pre      The RB7 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define SPI_CS_RB7_SetLow()           (_LATB7 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB7 GPIO Pin which has a custom name of SPI_CS_RB7
 * @pre      The RB7 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define SPI_CS_RB7_Toggle()           (_LATB7 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB7 GPIO Pin which has a custom name of SPI_CS_RB7
 * @param    none
 * @return   none  
 */
#define SPI_CS_RB7_GetValue()         _RB7

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB7 GPIO Pin which has a custom name of SPI_CS_RB7 as Input
 * @param    none
 * @return   none  
 */
#define SPI_CS_RB7_SetDigitalInput()  (_TRISB7 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB7 GPIO Pin which has a custom name of SPI_CS_RB7 as Output
 * @param    none
 * @return   none  
 */
#define SPI_CS_RB7_SetDigitalOutput() (_TRISB7 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB10 GPIO Pin which has a custom name of SPI_DC_RB10 to High
 * @pre      The RB10 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define SPI_DC_RB10_SetHigh()          (_LATB10 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB10 GPIO Pin which has a custom name of SPI_DC_RB10 to Low
 * @pre      The RB10 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define SPI_DC_RB10_SetLow()           (_LATB10 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB10 GPIO Pin which has a custom name of SPI_DC_RB10
 * @pre      The RB10 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define SPI_DC_RB10_Toggle()           (_LATB10 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB10 GPIO Pin which has a custom name of SPI_DC_RB10
 * @param    none
 * @return   none  
 */
#define SPI_DC_RB10_GetValue()         _RB10

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB10 GPIO Pin which has a custom name of SPI_DC_RB10 as Input
 * @param    none
 * @return   none  
 */
#define SPI_DC_RB10_SetDigitalInput()  (_TRISB10 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB10 GPIO Pin which has a custom name of SPI_DC_RB10 as Output
 * @param    none
 * @return   none  
 */
#define SPI_DC_RB10_SetDigitalOutput() (_TRISB10 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC4 GPIO Pin which has a custom name of LED1_RC4 to High
 * @pre      The RC4 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define LED1_RC4_SetHigh()          (_LATC4 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC4 GPIO Pin which has a custom name of LED1_RC4 to Low
 * @pre      The RC4 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED1_RC4_SetLow()           (_LATC4 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC4 GPIO Pin which has a custom name of LED1_RC4
 * @pre      The RC4 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED1_RC4_Toggle()           (_LATC4 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC4 GPIO Pin which has a custom name of LED1_RC4
 * @param    none
 * @return   none  
 */
#define LED1_RC4_GetValue()         _RC4

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC4 GPIO Pin which has a custom name of LED1_RC4 as Input
 * @param    none
 * @return   none  
 */
#define LED1_RC4_SetDigitalInput()  (_TRISC4 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC4 GPIO Pin which has a custom name of LED1_RC4 as Output
 * @param    none
 * @return   none  
 */
#define LED1_RC4_SetDigitalOutput() (_TRISC4 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC6 GPIO Pin which has a custom name of LED3_RC6 to High
 * @pre      The RC6 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define LED3_RC6_SetHigh()          (_LATC6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC6 GPIO Pin which has a custom name of LED3_RC6 to Low
 * @pre      The RC6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED3_RC6_SetLow()           (_LATC6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC6 GPIO Pin which has a custom name of LED3_RC6
 * @pre      The RC6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED3_RC6_Toggle()           (_LATC6 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC6 GPIO Pin which has a custom name of LED3_RC6
 * @param    none
 * @return   none  
 */
#define LED3_RC6_GetValue()         _RC6

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC6 GPIO Pin which has a custom name of LED3_RC6 as Input
 * @param    none
 * @return   none  
 */
#define LED3_RC6_SetDigitalInput()  (_TRISC6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC6 GPIO Pin which has a custom name of LED3_RC6 as Output
 * @param    none
 * @return   none  
 */
#define LED3_RC6_SetDigitalOutput() (_TRISC6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC7 GPIO Pin which has a custom name of LED4_RC7 to High
 * @pre      The RC7 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define LED4_RC7_SetHigh()          (_LATC7 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC7 GPIO Pin which has a custom name of LED4_RC7 to Low
 * @pre      The RC7 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED4_RC7_SetLow()           (_LATC7 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC7 GPIO Pin which has a custom name of LED4_RC7
 * @pre      The RC7 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED4_RC7_Toggle()           (_LATC7 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC7 GPIO Pin which has a custom name of LED4_RC7
 * @param    none
 * @return   none  
 */
#define LED4_RC7_GetValue()         _RC7

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC7 GPIO Pin which has a custom name of LED4_RC7 as Input
 * @param    none
 * @return   none  
 */
#define LED4_RC7_SetDigitalInput()  (_TRISC7 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC7 GPIO Pin which has a custom name of LED4_RC7 as Output
 * @param    none
 * @return   none  
 */
#define LED4_RC7_SetDigitalOutput() (_TRISC7 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC8 GPIO Pin which has a custom name of LED5_RC8 to High
 * @pre      The RC8 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define LED5_RC8_SetHigh()          (_LATC8 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC8 GPIO Pin which has a custom name of LED5_RC8 to Low
 * @pre      The RC8 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED5_RC8_SetLow()           (_LATC8 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC8 GPIO Pin which has a custom name of LED5_RC8
 * @pre      The RC8 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED5_RC8_Toggle()           (_LATC8 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC8 GPIO Pin which has a custom name of LED5_RC8
 * @param    none
 * @return   none  
 */
#define LED5_RC8_GetValue()         _RC8

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC8 GPIO Pin which has a custom name of LED5_RC8 as Input
 * @param    none
 * @return   none  
 */
#define LED5_RC8_SetDigitalInput()  (_TRISC8 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC8 GPIO Pin which has a custom name of LED5_RC8 as Output
 * @param    none
 * @return   none  
 */
#define LED5_RC8_SetDigitalOutput() (_TRISC8 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC9 GPIO Pin which has a custom name of LED6_RC9 to High
 * @pre      The RC9 must be set as Output Pin             
 * @param    none
 * @return   none  
 */

#define SPI_DC_dummy_RC9_SetHigh()  (_LATC9 = 1)
#define LED6_RC9_SetHigh()          (_LATC9 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC9 GPIO Pin which has a custom name of LED6_RC9 to Low
 * @pre      The RC9 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED6_RC9_SetLow()           (_LATC9 = 0)
#define SPI_DC_dummy_RC9_SetLow()  (_LATC9 = 0)
/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC9 GPIO Pin which has a custom name of LED6_RC9
 * @pre      The RC9 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED6_RC9_Toggle()           (_LATC9 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC9 GPIO Pin which has a custom name of LED6_RC9
 * @param    none
 * @return   none  
 */
#define LED6_RC9_GetValue()         _RC9

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC9 GPIO Pin which has a custom name of LED6_RC9 as Input
 * @param    none
 * @return   none  
 */
#define LED6_RC9_SetDigitalInput()  (_TRISC9 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC9 GPIO Pin which has a custom name of LED6_RC9 as Output
 * @param    none
 * @return   none  
 */
#define LED6_RC9_SetDigitalOutput() (_TRISC9 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC10 GPIO Pin which has a custom name of LED7_RC10 to High
 * @pre      The RC10 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define LED7_RC10_SetHigh()          (_LATC10 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC10 GPIO Pin which has a custom name of LED7_RC10 to Low
 * @pre      The RC10 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED7_RC10_SetLow()           (_LATC10 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC10 GPIO Pin which has a custom name of LED7_RC10
 * @pre      The RC10 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define LED7_RC10_Toggle()           (_LATC10 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC10 GPIO Pin which has a custom name of LED7_RC10
 * @param    none
 * @return   none  
 */
#define LED7_RC10_GetValue()         _RC10

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC10 GPIO Pin which has a custom name of LED7_RC10 as Input
 * @param    none
 * @return   none  
 */
#define LED7_RC10_SetDigitalInput()  (_TRISC10 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC10 GPIO Pin which has a custom name of LED7_RC10 as Output
 * @param    none
 * @return   none  
 */
#define LED7_RC10_SetDigitalOutput() (_TRISC10 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Initializes the PINS module
 * @param    none
 * @return   none  
 */
void PINS_Initialize(void);

/**
 * @ingroup  pinsdriver
 * @brief    This function is callback for S1_RB5 Pin
 * @param    none
 * @return   none   
 */
void S1_RB5_CallBack(void);

/**
 * @ingroup  pinsdriver
 * @brief    This function is callback for S2_RB4 Pin
 * @param    none
 * @return   none   
 */
void S2_RB4_CallBack(void);

/**
 * @ingroup  pinsdriver
 * @brief    This function is callback for S3_RA6 Pin
 * @param    none
 * @return   none   
 */
void S3_RA6_CallBack(void);


/**
 * @ingroup    pinsdriver
 * @brief      This function assigns a function pointer with a callback address
 * @param[in]  InterruptHandler - Address of the callback function 
 * @return     none  
 */
void S1_RB5_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup    pinsdriver
 * @brief      This function assigns a function pointer with a callback address
 * @param[in]  InterruptHandler - Address of the callback function 
 * @return     none  
 */
void S2_RB4_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup    pinsdriver
 * @brief      This function assigns a function pointer with a callback address
 * @param[in]  InterruptHandler - Address of the callback function 
 * @return     none  
 */
void S3_RA6_SetInterruptHandler(void (* InterruptHandler)(void));


#endif

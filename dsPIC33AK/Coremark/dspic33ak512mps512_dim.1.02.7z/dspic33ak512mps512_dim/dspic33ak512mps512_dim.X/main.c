/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */

//TMR1 1ms Per for TASK control, also for coremark


//V1.02 ported coremark,need test, -Os result:score:596! 2.98/Mhz, DFP version 1.2.135
//V1.01 modified by Zell for Coremark benchmark test
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/touch/include/qtm_common_components_api.h"
#include "mcc_generated_files/touch/include/touch_api.h"

#include "bsp/led0.h"
#include "bsp/led1.h"
#include "bsp/led2.h"
#include "bsp/led3.h"
#include "bsp/led4.h"
#include "bsp/led5.h"
#include "bsp/led6.h"
#include "bsp/led7.h"

#include "bsp/led_rgb.h"
#include "bsp/led_red.h"
#include "bsp/led_blue.h"
#include "bsp/led_green.h"

#include "bsp/t1.h"
#include "bsp/t2.h"
#include "bsp/t3.h"

#include "bsp/s1.h"
#include "bsp/s2.h"
#include "bsp/s3.h"

#include "bsp/task.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "bsp/led_color.h"

#include "bsp/pot.h"

#include "mcc_generated_files/uart/uart1.h"
#include "bsp/uart_null.h"

#include "mcc_generated_files/touch/datastreamer/datastreamer.h"
#include "console.h"

#include <stdbool.h>
#include <stdio.h>

#include "mcc_generated_files/can/can1.h"

#include "stdbool.h"
#include <math.h>
#include <libq.h> //Q31 math

#include "coremark/coremark.h"

#define Version_Nrd '1'
#define Version_Nrf1 '0' //
#define Version_Nrf2 '2' //
#define DFP_version "1.2.135"
#define CPU_freq 200.0 // in Mhz

static volatile bool potentiometerPrintRequired = false;
static char printBuffer[100];

#define CAN_TX_MESSAGE_ID 0xA2

static struct CAN_MSG_OBJ canRxMessage;
static uint8_t canRxData[8];
static struct CAN_MSG_OBJ canTxMessage;
static uint8_t canTxData[8];

uint32_t TMR_1s_cnt = 0;
uint32_t TMR_1ms_cnt = 0;
static uint32_t sys_uptime_second = 0;
uint32_t sys_uptime_min = 0;
uint32_t sys_uptime_min_pre = 0;

static void UpdateLEDOnButtonPress(const struct BUTTON_SIMPLE *button, const struct LED_SIMPLE *led) {
    if (button->isPressed()) {
        led->on();
    } else {
        led->off();
    }
}

static void AliveToggle(void) {
    led3.toggle();
}

static void printMenu(void) {
    //console.clear();
    console.cursorHide();
    console.cursorRowSet(1);
    console.print("------------------------------------ \r\n");
    console.print("dsPIC33AK512MPS512 Out of Box Demo\r\n");
    console.print("------------------------------------ \r\n");
    console.print("Hold Switch S1 - LED7 turns on \r\n");
    console.print("Hold Switch S2 - LED6 turns on \r\n");
    console.print("Hold Switch S3 - LED5 turns on \r\n");
    console.print("Touch Pad T1 - LED2 turns on \r\n");
    console.print("Touch Pad T2 - LED1 turns on \r\n");
    console.print("Touch Pad T3 - LED0 turns on \r\n");
    console.print("LED3 blinks every second\r\n");
    console.print("Press 'r', 'g', 'b' will toggle states of the RGB LED\r\n");
    console.print("Turning the potentiometer will adjust the intensity of the RGB LED \r\n");
    console.print("UART send R G B to toggle RGB LED channels \r\n");

}

static void UpdateRGB(char command) {
    switch (command) {
        case 'r':
        case 'R':
            ledRed.toggle();
            break;
        case 'g':
        case 'G':
            ledGreen.toggle();
            break;
        case 'b':
        case 'B':
            ledBlue.toggle();
            break;
        default:
            break;
    }
}

static void UpdateRGBIntensity(uint16_t intensity) {
    ledRed.setIntensity(intensity);
    ledGreen.setIntensity(intensity);
    ledBlue.setIntensity(intensity);
}

static void printPotentiometer(void) {
    potentiometerPrintRequired = true;
}

static void initializeCanMessage(void) {
    canRxMessage.data = canRxData;
    canTxMessage.msgId = CAN_TX_MESSAGE_ID;
    canTxMessage.data = canTxData;
    canTxMessage.field.idType = CAN_FRAME_STD;
    canTxMessage.field.frameType = CAN_FRAME_DATA;
    canTxMessage.field.dlc = DLC_8;
    canTxMessage.field.formatType = CAN_FD_FORMAT;
    canTxMessage.field.brs = CAN_BRS_MODE;
}

/*
    Main application
 */

static void ScanCAN(void) {
    uint8_t index = 0;

    if (CAN1_ReceivedMessageCountGet() > 0) {
        CAN1_ReceiveMessageGet(CAN1_FIFO_1, &canRxMessage);
        while (index < 8) {
            UpdateRGB(canRxMessage.data[index]);
            index++;
        }
    }
}

static void BoardInitialize(void) {
    /* 
     * The pin connected to the shield provided for the capacitive buttons is not one of the ITC pins
     * and cannot be used. The pin cannot be floating and should be grounded
     */
    _TRISE4 = 0u;
    _LATE4 = 0u;

    /* LEDs */
    led0.initialize();
    led1.initialize();
    led2.initialize();
    led3.initialize();
    led4.initialize();
    led5.initialize();
    led6.initialize();
    led7.initialize();

    ledRGB.initialize();

    ledRed.setIntensity(0);
    ledRed.on();

    ledGreen.setIntensity(0);
    ledGreen.on();

    ledBlue.setIntensity(0);
    ledBlue.on();

    /* Touch buttons */
    t1.initialize();
    t2.initialize();
    t3.initialize();

    /* Switches */
    s1.initialize();
    s2.initialize();
    s3.initialize();

    pot.initialize();
}
char version_buf[4];
void Task_1s(void);

int main(void) {
    char input;

    TASK_Initialize();

    SYSTEM_Initialize();

    TMR1_TimeoutCallbackRegister(&TASK_InterruptHandler);

    BoardInitialize();

    version_buf[0] = Version_Nrd;
    version_buf[1] = '.';
    version_buf[2] = Version_Nrf1;
    version_buf[3] = Version_Nrf2;

    /* If all three buttons are pressed on reset, then switch to data visualizer
     * mode instead of console mode. */
    if (s1.isPressed() && s2.isPressed() && s3.isPressed()) {
        datastreamer_init(&UART1_Drv);
        console.initialize(&UART_NULL_Drv);
    } else {
        datastreamer_init(&UART_NULL_Drv);
        console.initialize(&UART1_Drv);
    }
    console.clear();
    console.cursorRowSet(20);
    printf("< dsPIC33AK512MP512 DIM board MPLAB 6.25 test demo!>\r\n");
    printf("-Version %s, 31.Dez.2025 by Zell-\r\n", version_buf);
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("--FW code compiled with XCDSC Version: %d\n", __XC16_VERSION__);
    printf("--Platform has DSP engine: %d\n", __HAS_DSP__);//https://onlinedocs.microchip.com/oxy/GUID-C4E60FF5-3DAB-44F1-BA61-4BD962D8F469-en-US-5/GUID-D36F9153-C4C7-4E89-B119-7E0891583DEF.html
    //printf("--Platform has EEPROM: %d\n", __HAS_EEDATA__);
    //printf("--Platform has CODEGUARD: %d\n", __HAS_CODEGUARD__); 
    printf("--Platform has DMA: %d\n", __HAS_DMA__);
            //__HAS_5VOLTS__
    //__HAS_EDS__
    printf("--Platform has DMA_V2: %d\n", __HAS_DMAV2__);
    printf("--Platform 32bit A Architecture: %d\n", __HAS_ISA32__);
    printf("--Chip DFP version: %s\n",DFP_version);
    
    console.cursorRowSet(0);
    printf("Press S3 now to start Coremark benchtest!/r/n");
    
    if ( s3.isPressed()) {
        
        TMR_1ms_cnt = 0;
            printf("\r\n@@@@Coremark bench test starts now! please wait...\r\n");
    int argc = 1;
    char *argv[] = {"coremark", "0x6000"};
    uint16_t CM_result;
    CM_result=coremark_main(argc, argv);
    // SCCP1_Timer_Start();
    printf("\r\n^^^^Coremark bench test(ported by Zell for dsPIC AK platform) ends with score:%u! %3.2f/Mhz\r\n",CM_result,CM_result/200.0);

    }
    

    initializeCanMessage();

    /* Scan touch every millisecond */
    TASK_Request(&touch_timer_handler, 1);

    /* Blink alive once a second */
    TASK_Request(&AliveToggle, 1000);

    /* Print the potentiometer value every 200ms */
    TASK_Request(&printPotentiometer, 500);

    TASK_Request(&Task_1s, 1000);


    TMR1_Start();

    touch_init();

    printMenu();

    while (1) {
        CAN1_Tasks();

        touch_process();

        uint16_t potentiometerReading = pot.read();

        UpdateRGBIntensity(potentiometerReading);

        UpdateLEDOnButtonPress(&t1, &led2);
        UpdateLEDOnButtonPress(&t2, &led1);
        UpdateLEDOnButtonPress(&t3, &led0);

        UpdateLEDOnButtonPress(&s1, &led7);
        UpdateLEDOnButtonPress(&s2, &led6);
        UpdateLEDOnButtonPress(&s3, &led5);

        if (potentiometerPrintRequired) {
            potentiometerPrintRequired = false;

            //sprintf(printBuffer, "Potentiometer: 0x%04X\r\n", pot.read());
            sprintf(printBuffer, "Potentiometer: %u\r\n", pot.read());

            console.cursorRowSet(14);
            console.print(printBuffer);

            canTxMessage.data[0] = potentiometerReading >> 8;
            canTxMessage.data[1] = potentiometerReading;
            CAN1_Transmit(CAN1_TXQ, &canTxMessage);
        }

        if (console.scan(&input)) {
            console.cursorRowSet(15);
            UpdateRGB(input);
        }

        ScanCAN();

                if(0==TMR_1ms_cnt%1000){
                    TMR_1s_cnt++;
                }
    }
}

void Task_1s(void) {
    sys_uptime_second = TMR_1s_cnt / 1000;
    sys_uptime_min = sys_uptime_second / 60;
    if (sys_uptime_min_pre < sys_uptime_min) {
        //printf(">>#:sys up time: %lu min!\r\n", sys_uptime_min);
        sprintf(printBuffer, ">>#:sys up time: %lu min!\r\n", sys_uptime_min);
        sys_uptime_min_pre = sys_uptime_min;

    } else if (60 > sys_uptime_second) {
        // printf("\r\n>>#:sys up time: %lu s!\r\n", sys_uptime_second);
        sprintf(printBuffer, ">>#:sys up time: %lu s!\r\n", sys_uptime_second);
    }

    // sprintf(printBuffer, "Potentiometer: %u\r\n", pot.read());

    console.cursorRowSet(16);
    console.print(printBuffer);
    //console.cursorRowSet(14);

}

/*
 * def status, OPT=0
 16:10:58.526 -> @@@@Core mark bench test starts now! please wait...
16:11:40.857 -> 2K performance run parameters for coremark.
16:11:40.860 -> CoreMark Size    : 666
16:11:40.863 -> Total ticks      : 42519
16:11:40.865 -> Total time (secs): 42.519001
16:11:40.867 -> Iterations/Sec   : 141.113388
16:11:40.870 -> Iterations       : 6000
16:11:40.871 -> Compiler version : GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025  

16:11:40.878 -> Compiler flags   : O0
16:11:40.881 -> Memory location  : Code in flash, data in on chip RAM
16:11:40.886 -> seedcrc          : 0xe9f5
16:11:40.888 -> [0]crclist       : 0xe714
16:11:40.890 -> [0]crcmatrix     : 0x1fd7
16:11:40.892 -> [0]crcstate      : 0x8e3a
16:11:40.895 -> [0]crcfinal      : 0xa14c
16:11:40.902 -> Correct operation validated. See README.md for run and reporting rules.
16:11:40.903 -> CoreMark 1.0 : 141.113388 / GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct 
 1 2025   (null) / Code in flash, data in on chip RAM
16:11:40.914 -> 
16:11:40.915 -> ^^^^Core mark bench test ends with score:141! 0.70/Mhz
*/

/* O1
 16:15:30.651 -> 2K performance run parameters for coremark.
16:15:30.653 -> CoreMark Size    : 666
16:15:30.655 -> Total ticks      : 14806
16:15:30.658 -> Total time (secs): 14.806000
16:15:30.660 -> Iterations/Sec   : 405.241119
16:15:30.663 -> Iterations       : 6000
16:15:30.665 -> Compiler version : GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025  
16:15:30.672 -> Compiler flags   : O1
16:15:30.673 -> Memory location  : Code in flash, data in on chip RAM
16:15:30.683 -> seedcrc          : 0xe9f5
16:15:30.683 -> [0]crclist       : 0xe714
16:15:30.683 -> [0]crcmatrix     : 0x1fd7
16:15:30.685 -> [0]crcstate      : 0x8e3a
16:15:30.688 -> [0]crcfinal      : 0xa14c
16:15:30.690 -> Correct operation validated. See README.md for run and reporting rules.
16:15:30.695 -> CoreMark 1.0 : 405.241119 / GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025   
16:15:30.704 ->  / Code in flash, data in on chip RAM
16:15:30.707 -> 
16:15:30.707 -> ^^^^Core mark bench test ends with score:405! 2.03/Mhz

 
 */

/* -O2
 16:17:12.038 -> 2K performance run parameters for coremark.
16:17:12.038 -> CoreMark Size    : 666
16:17:12.038 -> Total ticks      : 10509
16:17:12.038 -> Total time (secs): 10.509000
16:17:12.040 -> Iterations/Sec   : 570.939209
16:17:12.042 -> Iterations       : 6000
16:17:12.054 -> Compiler version : GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025  
16:17:12.054 -> Compiler flags   : O2
16:17:12.054 -> Memory location  : Code in flash, data in on chip RAM
16:17:12.057 -> seedcrc          : 0xe9f5
16:17:12.072 -> [0]crclist       : 0xe714
16:17:12.072 -> [0]crcmatrix     : 0x1fd7
16:17:12.072 -> [0]crcstate      : 0x8e3a
16:17:12.072 -> [0]crcfinal      : 0xa14c
16:17:12.072 -> Correct operation validated. See README.md for run and reporting rules.
16:17:12.075 -> CoreMark 1.0 : 570.939209 / GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025    / Code in flash, data in on chip RAM
16:17:12.092 -> 
16:17:12.092 -> ^^^^Core mark bench test ends with score:570! 2.85/Mhz

 */

/* -os
 16:19:42.951 -> 2K performance run parameters for coremark.
16:19:42.953 -> CoreMark Size    : 666
16:19:42.956 -> Total ticks      : 13899
16:19:42.959 -> Total time (secs): 13.899000
16:19:42.961 -> Iterations/Sec   : 431.685730
16:19:42.963 -> Iterations       : 6000
16:19:42.966 -> Compiler version : GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025  
16:19:42.972 -> Compiler flags   : O2
16:19:42.974 -> Memory location  : Code in flash, data in on chip RAM
16:19:42.979 -> seedcrc          : 0xe9f5
16:19:42.982 -> [0]crclist       : 0xe714
16:19:42.984 -> [0]crcmatrix     : 0x1fd7
16:19:42.986 -> [0]crcstate      : 0x8e3a
16:19:42.988 -> [0]crcfinal      : 0xa14c
16:19:42.990 -> Correct operation validated. See README.md for run and reporting rules.
16:19:42.997 -> CoreMark 1.0 : 431.685730 / GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025    / Code in flash, data in on chip RAM
16:19:43.007 -> 
16:19:43.008 -> ^^^^Core mark bench test ends with score:431! 2.15/Mhz

 */

/* -Os
 16:20:38.815 -> @@@@Core mark bench test starts now! please wait...
16:20:48.843 -> 2K performance run parameters for coremark.
16:20:48.845 -> CoreMark Size    : 666
16:20:48.846 -> Total ticks      : 10065
16:20:48.848 -> Total time (secs): 10.065000
16:20:48.851 -> Iterations/Sec   : 596.125183
16:20:48.853 -> Iterations       : 6000
16:20:48.855 -> Compiler version : GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025  
16:20:48.862 -> Compiler flags   : O3
16:20:48.864 -> Memory location  : Code in flash, data in on chip RAM
16:20:48.869 -> seedcrc          : 0xe9f5
16:20:48.871 -> [0]crclist       : 0xe714
16:20:48.874 -> [0]crcmatrix     : 0x1fd7
16:20:48.876 -> [0]crcstate      : 0x8e3a
16:20:48.878 -> [0]crcfinal      : 0xa14c
16:20:48.886 -> Correct operation validated. See README.md for run and reporting rules.
16:20:48.887 -> CoreMark 1.0 : 596.125183 / GCC8.3.1 (XC-DSC, Microchip v3.30) Build date: Oct  1 2025    / Code in flash, data in on chip RAM
16:20:48.897 -> 
16:20:48.897 -> ^^^^Core mark bench test ends with score:596! 2.98/Mhz

 
 */
//SSD1327  Futaba ELW1501AAR OLED driver V1.3
//SSD1327 128x128 4-bit greyscale OLED displays
//Modified by Zell for AVR128DA test
//2023.02.22 added GFX functions from adafruit libs
//2022.07.14 driver for use with microchip Studio
//2021.12.24 driver for use with microchip MPLAB
//128 x 128, 16 Gray Scale Dot Matrix
//OLED/PLED Segment/Common Driver with Controller
/*
 SSD1327
 ? For matrix display 
o Segment maximum source current: 300uA o Common maximum sink current: 40mA  o 256 step contrast brightness current control  
? Embedded 128 x 128 x 4 bit SRAM display buffer 
? ? Display Start Line=00h 
? Column Start Address=01h 
? Column End Address=3Eh 
? Row Start Address=01h 
? Row End Address=7Eh
16 gray scale 
 */
#ifndef SSD1327_H
#define SSD1327_H

//#include <Arduino.h>
#include "stdint.h"
#include "stdio.h"
//#include "SPI.h"
#include "stdbool.h"
//#include "stds.h"
//#include "../mcc_generated_files/include/pin_manager.h"

#define OLED_Height 128
#define OLED_Width 128

// Scroll rate constants. See datasheet page 40.
//Set time interval between each scroll step in terms  of frame frequency
#define SSD1327_SCROLL_2   0b111  //2 frames
#define SSD1327_SCROLL_3   0b100
#define SSD1327_SCROLL_4   0b101
#define SSD1327_SCROLL_5   0b110
#define SSD1327_SCROLL_6   0b000
#define SSD1327_SCROLL_32  0b001
#define SSD1327_SCROLL_64  0b010
#define SSD1327_SCROLL_256 0b011

static uint8_t CMD_TX_buf[6];


//from Adafruit Industries.
#define SSD1327_BLACK 0x0
#define SSD1327_WHITE 0xF

#define SSD1327_I2C_ADDRESS 0x3D

#define SSD1305_SETBRIGHTNESS 0x82

#define SSD1327_SETCOLUMN 0x15

#define SSD1327_SETROW 0x75

#define SSD1327_SETCONTRAST 0x81

#define SSD1305_SETLUT 0x91

#define SSD1327_SEGREMAP 0xA0
#define SSD1327_SETSTARTLINE 0xA1
#define SSD1327_SETDISPLAYOFFSET 0xA2
#define SSD1327_NORMALDISPLAY 0xA4
#define SSD1327_DISPLAYALLON 0xA5
#define SSD1327_DISPLAYALLOFF 0xA6
#define SSD1327_INVERTDISPLAY 0xA7
#define SSD1327_SETMULTIPLEX 0xA8
#define SSD1327_REGULATOR 0xAB
#define SSD1327_DISPLAYOFF 0xAE
#define SSD1327_DISPLAYON 0xAF

#define SSD1327_PHASELEN 0xB1
#define SSD1327_DCLK 0xB3
#define SSD1327_PRECHARGE2 0xB6
#define SSD1327_GRAYTABLE 0xB8
#define SSD1327_PRECHARGE 0xBC
#define SSD1327_SETVCOM 0xBE

#define SSD1327_FUNCSELB 0xD5

#define SSD1327_CMDLOCK 0xFD

/* basic usage:

uint8_t BG_brightness = 2; //1 to 15
uint8_t x_pos = 0;
uint8_t y_pos = 0;

printf("#>:SSD1327 OLED init...\r\n");
OLED_Reset();
OLED_Init();
clearBuffer();
SSD1327_FillBuffer();////fill all pixels to 1, appears in grey color
//SSD1327_Buffer_White();
writeFullBuffer(); //clear display
printf(">#OLED frame buffer cleared!\r\n");

 */
//class SSD1327 {
//	public:
//SSD1327(int cs, int dc, int rst);


static inline void OLED_CS_Low(void){
	//IO_PA2_CS_SetLow();
	//OLED_CS_set_level(false);
    SPI_CS_RB7_SetLow();
	//IO_PD2_CS_SetLow();
	Nop();
	
}
static inline void OLED_CS_High(void){
	//IO_PA2_CS_SetHigh();
	//OLED_CS_set_level(true);
    SPI_CS_RB7_SetHigh();
    
	//IO_PD2_CS_SetHigh();
	Nop();
	
}

static inline void OLED_DC_Low(void){
	//IO_PA3_DC_SetLow();
	//OLED_DC_set_level(false);
    SPI_DC_RB10_SetLow(); //need implement 9.7
    //SPI_DC_dummy_RC9_SetLow(); //test only
	//IO_PD3_DC_SetLow();
	//Nop();
	
}
static inline void OLED_DC_High(void){
	//IO_PA3_DC_SetHigh();
	//OLED_DC_set_level(true);
    //Nop();
     SPI_DC_RB10_SetHigh(); //need implement 9.7
     //SPI_DC_dummy_RC9_SetHigh();
	//IO_PD3_DC_SetHigh();
	
	
}
static inline void OLED_Reset_High(void){

     SPI_RST_RB6_SetHigh(); //need implement 9.7

	
	
}
static inline void OLED_Reset_Low(void){

     SPI_RST_RB6_SetLow(); //need implement 9.7

	
	
}




void writeCmd(uint8_t reg);
void writeData(uint8_t data);
void setWriteZone(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
void writeCmd_buf(void *bufferData, size_t bufferSize);
void  writeData_buf(void *bufferData, size_t bufferSize);
void  writeFullBuffer_fast();
void  writeFullBuffer();

uint16_t coordsToAddress(uint8_t x, uint8_t y);
void setPixelChanged(uint8_t x, uint8_t y, bool changed);
void drawPixel(uint8_t x, uint8_t y, uint8_t color, bool display); //color 0-15,
void drawRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color, bool display);
void drawRect_transitionBand(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color, bool display);
void drawHLine(int x, int y, int length, uint8_t color, bool display);
void drawVLine(int x, int y, int length, uint8_t color, bool display);
void drawLine(int x1, int y1, int x2, int y2, uint8_t color, bool display);
void drawByteAsRow(uint8_t x, uint8_t y, uint8_t byte, uint8_t color);
void drawChar(uint8_t x, uint8_t y, char thisChar, uint8_t color);
void drawChar16(uint8_t x, uint8_t y, char thisChar, uint8_t color);
void drawChar32(uint8_t x, uint8_t y, char thisChar, uint8_t color);
void drawCharArray(uint8_t x, uint8_t y, char text[], uint8_t color, int size);
//void drawCharArray(uint8_t x, uint8_t y, char text[], uint8_t color, int size=8);
//void drawString(uint8_t x, uint8_t y, String textString, uint8_t color, int size=8);
void drawString(uint8_t x, uint8_t y, char* textString, uint8_t color, int size);

void setupScrolling(uint8_t startRow, uint8_t endRow, uint8_t startCol, uint8_t endCol, uint8_t scrollSpeed, bool right);
void startScrolling();
void stopScrolling();
void scrollStep(uint8_t startRow, uint8_t endRow, uint8_t startCol, uint8_t endCol, bool right);
void fillStripes(uint8_t offset);
void clearBuffer();
void clearFrameBuffer(uint8_t x, uint8_t y, uint8_t width, uint8_t height);
void SSD1327_FillBuffer(void); //fill all pixel(buffer) with 1
void SSD1327_FillBuffer_black(void); //fill all pixel(buffer) with 0
void SSD1327_Buffer_White(void); //fill all pixel(buffer) with 15
void writeFullBuffer();
void writeUpdates();
void write_Local_Updates(uint8_t x_pos, uint8_t y_pos, uint8_t w, uint8_t h);
void setContrast(uint8_t contrast);
void initRegs();
void SSD1327_OLED_Init(void);
void SSD1327_OLED_Reset(void);

//from    Adafruit_GFX  lib
//void drawBitmap(int16_t x, int16_t y, const uint8_t bitmap[], int16_t w,
//int16_t h, uint16_t color);
//void drawBitmap(int16_t x, int16_t y, const uint8_t bitmap[], int16_t w,
//int16_t h, uint16_t color, uint16_t bg);
void drawBitmap(int16_t x, int16_t y, const uint8_t *bitmap, int16_t w, int16_t h,
        uint16_t color);
//void drawXBitmap(int16_t x, int16_t y, const uint8_t bitmap[], int16_t w, int16_t h, uint16_t color);
void drawGrayscaleBitmap_PROGMEM(int16_t x, int16_t y, const uint8_t bitmap[], int16_t w, int16_t h);
void drawGrayscaleBitmap(int16_t x, int16_t y, uint8_t *bitmap, int16_t w, int16_t h);
//void drawGrayscaleBitmap(int16_t x, int16_t y, uint8_t *bitmap, uint8_t *mask,
//int16_t w, int16_t h);
void drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);
void drawCircleHelper(int16_t x0, int16_t y0, int16_t r, uint8_t cornername,
        uint16_t color);
void fillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);
void fillCircleHelper(int16_t x0, int16_t y0, int16_t r, uint8_t cornername,
        int16_t delta, uint16_t color);
void drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2,
        int16_t y2, uint16_t color);
void fillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2,
        int16_t y2, uint16_t color);
void drawRoundRect(int16_t x0, int16_t y0, int16_t w, int16_t h,
        int16_t radius, uint16_t color);
void fillRoundRect(int16_t x0, int16_t y0, int16_t w, int16_t h,
        int16_t radius, uint16_t color);

void OLED_testfillrect(uint8_t thickness );
void OLED_fastfillrect(uint8_t thickness );
void testfilltriangle(void);
void testdrawcircle(void);
//void OLED_draw_startup_title(void);
//        static inline void OLED_CS_Low(void);
//        static inline void OLED_CS_High(void);
//        static inline void OLED_DC_Low(void);
//        static inline void OLED_DC_High(void);
//	private:
//uint8_t frameBuffer[8192]; // Should mirror the display's own frameBuffer.
//uint8_t frameBuffer[1024];  // test only
//uint8_t changedPixels[1024]; // Each bit of this array represets whether a given byte of frameBuffer (e.g. a pair of pixels) is not up to date.
//		int _cs;
//		int _dc;
//		int _rst;
//};

#endif

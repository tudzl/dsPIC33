/**
 * PINS Generated Driver Source File 
 * 
 * @file      pins.c
 *            
 * @ingroup   pinsdriver
 *            
 * @brief     This is the generated driver source file for PINS driver.
 *
 * @skipline @version   PLIB Version 1.0.1-rc.1
 *
 * @skipline  Device : dsPIC33AK128MC106
*/

/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

// Section: Includes
#include <xc.h>
#include <stddef.h>
#include "../pins.h"

// Section: File specific functions
static void (*S3_RA6_InterruptHandler)(void) = NULL;
static void (*S2_RB4_InterruptHandler)(void) = NULL;
static void (*S1_RB5_InterruptHandler)(void) = NULL;

/**
 * @ingroup  pinsdriver
 * @brief    Locks all the Peripheral Remapping registers and cannot be written.
 * @return   none  
 */
#define PINS_PPSLock()           (RPCONbits.IOLOCK = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Unlocks all the Peripheral Remapping registers and can be written.
 * @return   none  
 */
#define PINS_PPSUnlock()         (RPCONbits.IOLOCK = 0)

// Section: Driver Interface Function Definitions
void PINS_Initialize(void)
{
    /****************************************************************************
     * Setting the Output Latch SFR(s)
     ***************************************************************************/
    LATA = 0x0000UL;
    LATB = 0x0000UL;
    LATC = 0x0000UL;
    LATD = 0x0002UL;

    /****************************************************************************
     * Setting the GPIO Direction SFR(s)
     ***************************************************************************/
    TRISA = 0x0FFFUL;
    TRISB = 0x0B3FUL;
    TRISC = 0x0003UL;
    TRISD = 0x1FE8UL;


    /****************************************************************************
     * Setting the Weak Pull Up and Weak Pull Down SFR(s)
     ***************************************************************************/
    CNPUA = 0x0000UL;
    CNPUB = 0x0000UL;
    CNPUC = 0x0000UL;
    CNPUD = 0x0000UL;
    CNPDA = 0x0000UL;
    CNPDB = 0x0000UL;
    CNPDC = 0x0000UL;
    CNPDD = 0x0000UL;


    /****************************************************************************
     * Setting the Open Drain SFR(s)
     ***************************************************************************/
    ODCA = 0x0000UL;
    ODCB = 0x0000UL;
    ODCC = 0x0000UL;
    ODCD = 0x0000UL;


    /****************************************************************************
     * Setting the Analog/Digital Configuration SFR(s)
     ***************************************************************************/
    ANSELA = 0x0FBFUL;
    ANSELB = 0x030FUL;

    /****************************************************************************
     * Set the PPS
     ***************************************************************************/
      PINS_PPSUnlock(); // unlock PPS

        RPINR0bits.INT1R = 0x0016UL; //RB5->EXT_INT:INT1;
        RPINR0bits.INT2R = 0x0015UL; //RB4->EXT_INT:INT2;
        RPINR0bits.INT3R = 0x0007UL; //RA6->EXT_INT:INT3;
        RPINR10bits.SDI1R = 0x003CUL; //RD11->SPI1:SDI1;
        RPINR9bits.U1RXR = 0x0034UL; //RD3->UART1:U1RX;
        RPOR12bits.RP51R = 0x0001UL;  //RD2->PWM:PWM1H;
        RPOR13bits.RP53R = 0x0002UL;  //RD4->PWM:PWM1L;
        RPOR12bits.RP49R = 0x0003UL;  //RD0->PWM:PWM2H;
        RPOR8bits.RP36R = 0x0004UL;  //RC3->PWM:PWM2L;
        RPOR10bits.RP44R = 0x000DUL;  //RC11->SPI1:SDO1;
        RPOR12bits.RP50R = 0x0009UL;  //RD1->UART1:U1TX;
        RPINR10bits.SCK1R = 0x0021UL;  //RC0->SPI1:SCK1IN; 
        RPOR8bits.RP33R = 0x000EUL;  //RC0->SPI1:SCK1OUT; //added by zell , fixed no SCK output issue

      PINS_PPSLock(); // lock PPS

    /*******************************************************************************
    * Interrupt On Change: negative
    *******************************************************************************/
    CNEN1Abits.CNEN1A6 = 1; //Pin : RA6; 
    /*******************************************************************************
    * Interrupt On Change: negative
    *******************************************************************************/
    CNEN1Bbits.CNEN1B4 = 1; //Pin : RB4; 
    /*******************************************************************************
    * Interrupt On Change: negative
    *******************************************************************************/
    CNEN1Bbits.CNEN1B5 = 1; //Pin : RB5; 

    /****************************************************************************
     * Interrupt On Change: flag
     ***************************************************************************/
    CNFBbits.CNFB5 = 0;    //Pin : S1_RB5
    CNFBbits.CNFB4 = 0;    //Pin : S2_RB4
    CNFAbits.CNFA6 = 0;    //Pin : S3_RA6

    /****************************************************************************
     * Interrupt On Change: config
     ***************************************************************************/
    CNCONAbits.CNSTYLE = 1; //Config for PORTA
    CNCONAbits.ON = 1; //Config for PORTA
    CNCONBbits.CNSTYLE = 1; //Config for PORTB
    CNCONBbits.ON = 1; //Config for PORTB

    /* Initialize IOC Interrupt Handler*/
    S3_RA6_SetInterruptHandler(&S3_RA6_CallBack);
    S2_RB4_SetInterruptHandler(&S2_RB4_CallBack);
    S1_RB5_SetInterruptHandler(&S1_RB5_CallBack);

    /****************************************************************************
     * Interrupt On Change: Interrupt Enable
     ***************************************************************************/
    IFS3bits.CNAIF = 0; //Clear CNAI interrupt flag
    IEC3bits.CNAIE = 1; //Enable CNAI interrupt
    IFS3bits.CNBIF = 0; //Clear CNBI interrupt flag
    IEC3bits.CNBIE = 1; //Enable CNBI interrupt
}

void __attribute__ ((weak)) S1_RB5_CallBack(void)
{

}

void __attribute__ ((weak)) S2_RB4_CallBack(void)
{

}

void __attribute__ ((weak)) S3_RA6_CallBack(void)
{

}

void S3_RA6_SetInterruptHandler(void (* InterruptHandler)(void))
{ 
    IEC3bits.CNAIE = 0; //Disable CNAI interrupt
    S3_RA6_InterruptHandler = InterruptHandler; 
    IEC3bits.CNAIE = 1; //Enable CNAI interrupt
}

void S2_RB4_SetInterruptHandler(void (* InterruptHandler)(void))
{ 
    IEC3bits.CNBIE = 0; //Disable CNBI interrupt
    S2_RB4_InterruptHandler = InterruptHandler; 
    IEC3bits.CNBIE = 1; //Enable CNBI interrupt
}

void S1_RB5_SetInterruptHandler(void (* InterruptHandler)(void))
{ 
    IEC3bits.CNBIE = 0; //Disable CNBI interrupt
    S1_RB5_InterruptHandler = InterruptHandler; 
    IEC3bits.CNBIE = 1; //Enable CNBI interrupt
}

/* Interrupt service function for the CNAI interrupt. */
void __attribute__ (( interrupt, no_auto_psv )) _CNAInterrupt (void)
{
    if(CNFAbits.CNFA6 == 1)
    {
        if(S3_RA6_InterruptHandler != NULL) 
        { 
            S3_RA6_InterruptHandler(); 
        }
        
        CNFAbits.CNFA6 = 0;  //Clear flag for Pin - S3_RA6
    }
    
    // Clear the flag
    IFS3bits.CNAIF = 0;
}

/* Interrupt service function for the CNBI interrupt. */
void __attribute__ (( interrupt, no_auto_psv )) _CNBInterrupt (void)
{
    if(CNFBbits.CNFB4 == 1)
    {
        if(S2_RB4_InterruptHandler != NULL) 
        { 
            S2_RB4_InterruptHandler(); 
        }
        
        CNFBbits.CNFB4 = 0;  //Clear flag for Pin - S2_RB4
    }
    
    if(CNFBbits.CNFB5 == 1)
    {
        if(S1_RB5_InterruptHandler != NULL) 
        { 
            S1_RB5_InterruptHandler(); 
        }
        
        CNFBbits.CNFB5 = 0;  //Clear flag for Pin - S1_RB5
    }
    
    // Clear the flag
    IFS3bits.CNBIF = 0;
}


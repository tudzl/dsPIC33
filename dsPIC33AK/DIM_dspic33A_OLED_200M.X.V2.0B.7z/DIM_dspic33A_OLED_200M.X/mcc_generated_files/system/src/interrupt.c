/**
 * INTERRUPT Generated Driver Source File 
 * 
 * @file      interrupt.c
 *            
 * @ingroup   interruptdriver
 *            
 * @brief     This is the generated driver source file for INTERRUPT driver          
 *
 * @skipline @version   PLIB Version 1.0.1-rc.1
 *            
 * @skipline  Device : dsPIC33AK128MC106
*/

/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

// Section: Includes
#include "../interrupt.h"

// Section: Driver Interface Function Definitions

void INTERRUPT_Initialize(void)
{
    // INT1: External Interrupt 1.
    // Priority: 1
    IPC4bits.INT1IP = 1;
    
    // INT3: External Interrupt 3.
    // Priority: 1
    IPC4bits.INT3IP = 1;
    
    // INT2: External Interrupt 2.
    // Priority: 1
    IPC4bits.INT2IP = 1;
    
    // I2C2: I2C 2 General Interrupt.
    // Priority: 1
    IPC10bits.I2C2IP = 1;
    
    // CNA: Change notice A.
    // Priority: 1
    IPC14bits.CNAIP = 1;
    
    // CNB: Change notice B.
    // Priority: 1
    IPC14bits.CNBIP = 1;
    
    // T1: Timer 1 Interrupt.
    // Priority: 1
    IPC6bits.T1IP = 1;
    
    // CCT2: CCP 2 timer.
    // Priority: 1
    IPC6bits.CCT2IP = 1;
    
    // CCT1: CCP 1 timer.
    // Priority: 1
    IPC6bits.CCT1IP = 1;
    
}

void INTERRUPT_Deinitialize(void)
{
    //POR default value of priority
    IPC4bits.INT1IP = 4;
    IPC4bits.INT3IP = 4;
    IPC4bits.INT2IP = 4;
    IPC10bits.I2C2IP = 4;
    IPC14bits.CNAIP = 4;
    IPC14bits.CNBIP = 4;
    IPC6bits.T1IP = 4;
    IPC6bits.CCT2IP = 4;
    IPC6bits.CCT1IP = 4;
}

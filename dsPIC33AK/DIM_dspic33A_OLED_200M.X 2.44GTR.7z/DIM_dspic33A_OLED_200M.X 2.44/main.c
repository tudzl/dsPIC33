/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */
//Fit to drive OLED!!
//ENV MCHP DELL PC MPLAB 6.20, official MCC, works
/*  P11 RB9 input, short to GND(using JMP) to enable SSD1357 RGB OLED, otherwise will use SSD1327 grayscale OLED(No JMP).
 *  PWM LED:  PWM1H- Blue  : RD2   P72_LED_B
              PWM2H- Green: RD0  P28?  P70_LED_G
             PWM4H- Red:     RC2   P68_LED_R
 *  PWM4L  RC5  DIM P32
LED0 : RC3  DIM P28
LED1:  RC4   DIM P30
LED2:  RC5   DIM P32  P12
LED3:  RC6   P34 P14
LED4:  RC7   P36 P7
LED 5,6,7 :  RC8,9,10
 * RGB LED: p68,70,72
 * SPI_SCK:P83 RC0,  SDO: P87 RC11 OK!  SDI RD1;  CS:  RB7
POTI? ADC AN6  RA7 ADC1_Channel6, trigger:  SCPP1 trigger Event works! Set SCCP1 Plib: Special Event Trig ouput!
 * 
 * OLED  DC: Mikrobus TX RB10
 * Timer_SCCP  100us as systick
 * Timer SCCP2 1s --> Task_1s
 * Timer1  100ms  TMR_INT_CNT , main loop task control
 * //RD3->UART1:U1RX;
   //RD1->UART1:U1TX;
 * PWM clock source: 8Mhz FRC, HS mode /16, PER LSB = 7.8125ns
 * PWM1 freq range: 50K to 500K, 100K def
 * PWM2 freq range: 10K  fixed
 * PWM4 freq range: 2K   fixed, can be changed with UAR cmd
 */

//GTR V2.44 optimized UART set PWM4 freq duty function, test OK!
// V2,43 fixed DC setting bugs when in very low freq for PWM4! confirmed in GTR XCDSC 3.20 will fail running!!
// V2.42B changed s3 function to control PWM4_EN by default (#define S3_reset_control_EN 0),test OK
//MAC V2.42 added UART send PWM4 Freq CMD function,"F1K", "F12K" to change to 1Khz or 12 Khz, fixed some PWM4 mode change bugs
//MAC V2.41  new DFP 1.4.xxx +XC_DSP 3.30, running OK!!!
//GTR V2.41, missing mPRINT_CAPTURE, added! need old DFP, new 1.3.60 DFP running error! found issue auto SWR!!! unknown reason! loop cnt =100
//V2.40 optimized clock, improved to true  200M CPU and  using Standard Speed Peripheral Clock (System clock/2)
//      OLED_draw Time: 27 ms reduced from old 84ms!!! sin cos calc is correct now!
//V2.31 added a standalone debug pin
//V2.30 added UART CMD control interface,"CMD_PWM4_button_trig_mode"
//V2.27 added uint32_t sin_cos_accuracy_test(float step_size); // added for benchtest
//V2.26 improved reset source function, added sin cos accuracy check function! inspired from AM radio Prj.
//V2.25 improved math test added sqrt
//V2.24 combined from MAC version 2.23, added ADC CMP ISR->LED function! added reset source show!
//V2.23 added soft reset S3 test function! 
//V2.22 solved OPT level 1 loop abnormal issue, CNT flag ->volatile var!
//V2.21 improved math test printf, need test with OPT levels
//V2.2 added using RB9(Xplained Pro Extension Interface pin4-JUM-Pin2(GND) ) to switch between SSD1357 and SSD1327 OLEDs, tested OK!
//SSD1357 RGB OLED active when JMP is present.
//V2.12 added RB9 input GPIO, tested RB9 and RC4 P30 input is OK
//V2.11 added LED3,LED4, LED7 for debug purpose!
//V2.1B improved SSD1357 text display and dabug info UART
//2.0B need to add DIM P28 P30 to switch different OLED during power up phase
//V2.0 added 0.6 zoll SSD1357 OLED driver, draw picture working!
//V1.9B added graw title function for SSD1327 GUI
//V1.9 added Btn S1,S2,S3 GUI rendering on SSD1309 OLED																			 
//V1.8 added ssd1309 OLED driver, working ! check pin connection!!!
//V1.7B improved pixel shift function to prevent OLED from burning!
//V1.7 re-MCC, added IIC2, LEDs, Key INT and CPU 200Mhz works!
//V1.6B added PWM OLED GUI display and 
//V1.6 SPI OLED driver optimized, solved low efficiency issue!
//V1.5 SPI OLED writecmd issue with DC signal early high causing data write corruption ,solved by insert SPI1_IsTxReady flag check, but lowwed SPI efficiency!
//V1.4 SPI OLED basic function works!, still some issues!
//V1.3 added PWM-->RGB LED dimming
//V1.2 ADC measure die temp and bandgap is OK~!
//V1.1 ADC UART works, SPI issues!
//V1.0 basic demo with MCC melody works

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "mcc_generated_files/adc/adc1.h"
#include "mcc_generated_files/pwm_hs/pwm.h"
#include "mcc_generated_files/spi_host/spi1.h"
#include "mcc_generated_files/timer/sccp2.h"
#include "mcc_generated_files/timer/sccp1.h"
//bsp
#include "bsp/led_red.h"
#include "bsp/led_blue.h"
#include "bsp/led_green.h"
#include "bsp/led_color.h"
#include "bsp/led_rgb.h"
#include "bsp/s1.h"
#include "bsp/s2.h"
#include "bsp/s3.h"
//OLED

#include "SSD1327/SSD1327.h"
#include "SSD1309/bmp.h"

#include "SSD1309/AK_dsPIC_1.h"
//#include "SSD1309/BG_girl_4bit.h"
#include "SSD1309/ssd1309.h"

#include "SSD1357/SSD1357.h"
#include "SSD1357/SSD1357_pic.h"

#define  __XCDSC_BUILTIN_LIB__


#include <xc.h>
#include <dsp.h>
#include <stdio.h>
#include <string.h>
#include "stdbool.h"
#include <math.h>
#include <libq.h> //Q31 math
//#include <libq_32.h>
#include "Mathtest_zell.h"
//#include "SSD1327/SSD1327.h"

#ifndef FCY
//#define FCY 8000000UL
#define FCY 200000000UL
#endif
//#define FCY 8000000UL
//#define FCY 200000000UL

//#define FCY 100000000UL
#include <libpic30.h>
//int main() {
///* at 1MHz, these are equivalent */
//__delay_us(1000);
//__delay32(1000);
//}


/*
    Main application
 */
//global vars
#define SSD1327_OLED_EN 0
uint8_t SSD1327_OLED_active = SSD1327_OLED_EN;
#define SSD1309_OLED_EN 0
uint8_t SSD1309_OLED_active = SSD1309_OLED_EN;
#define SSD1357_OLED_EN 1
uint8_t SSD1357_OLED_active = SSD1357_OLED_EN;

#define debug_info_EN 1
#define printf_cnt_interval 20
#define OLED_display_interval 7
#define OLED_saver_interval 15 //20s
#define Sin_Cos_test_EN 1

#define SPI_bus_1M 0
#define SPI_bus_125K 1
#define SPI_bus_4M 2
#define SPI_bus_2M 3

//PWM4 def mode self trigger continous waveform output if below 2 modes both is 0
#define PWM4_single_TRG_Mode_EN 0
#define PWM4_Auto_periodic_TRG_Mode_EN 0 

#define PWM4_def_mode 0
#define PWM4_button_trig_mode 1  //Btn S3
#define PWM4_auto_single_trig_mode 2

static uint8_t PWM4_single_TRG_cnt = 8;
uint8_t PWM4_trig_mode = PWM4_def_mode;

#define Version_Nrd '2'
#define Version_Nrf1 '4' //2._x
#define Version_Nrf2 '4' //2.x_

char version_buf[4];

#define FtoQ31(X) \
   ((X < 0.0) ? (int)(0x80000000*(X) - 0.5) : (int)(0x7FFFFFFF*(X) + 0.5)) 

//PMU 
#define WAIT          {asm volatile("REPEAT #20 \n NOP");}                   // Wait
#define ENABLE_PMU         {HPSEL0bits.SELECT0 = 1;HPSEL0bits.SELECT1 = 2;HPCCONbits.CLR = 1;WAIT;HPCCONbits.ON = 1;;}
#define DISABLE_PMU         {HPCCONbits.ON = 0;}
#define PRINT_PMU_COUNT     {uint32_t cyc = HPCCNTL0; printf("\r\n>! Cycles captured = %ld  :: Execution time = %dns\r\n",  cyc, cyc * CYCLE_TIME_NS);}

#define mSTART_CAPTURE          ENABLE_PMU
#define mPRINT_CAPTURE      {DISABLE_PMU;PRINT_PMU_COUNT;}  

float Die_temp = 0;
float VCC_voltage = 3.3;
uint16_t ADC_res_temp = 0;
float ADC_res_float = 0;
uint16_t ADC_poti = 0;
uint8_t ADC_CH6_CMP_flg = 0;

float Poti_voltage = 0;

float bench_res = 0;

uint32_t ADC_INT_flag = 0;
//Btn INT
uint8_t Btn_S1_pressed = 0; //PWM1_Freq_mode or DC mode
uint8_t Btn_S2_pressed = 0; //
uint8_t Btn_S3_pressed = 0;

uint16_t Btn_S1_press_cnt = 0;
uint16_t Btn_S2_press_cnt = 0;
uint16_t Btn_S3_press_cnt = 0;

#define S3_reset_control_EN 0

//PWM
uint32_t PWM1_Per_def = 1264; // 100Khz? default value
uint8_t PWM1_Freq_mode = 0;

uint8_t PWM4_freq = 2;
uint8_t PWM4_EN_flag = 1; 
const float PWM_clock_time_LSB = 7.8125;


//system tick changed to sccp1  100ns  100us PE
uint32_t sys_tck2_10ns = 0; //125ns per cnt
uint32_t sys_tck2_lsb_scale = 100; // 8M 
float sys_tck2_lsb_us = 0.01; // 8M 
uint32_t sys_tck2_lsb_ns = 10; // 8M 
uint32_t sys_sccp1_per_ns = 1000000; //1ms in ns scale
int32_t tck2_diff = 0;
uint32_t TMR_1ms_cnt = 0;

//SCCP2 timer based sys tck
uint32_t sys_tck = 0; //125ns per cnt
uint32_t sys_tck_lsb_scale = 8; // 8M 
float sys_tck_lsb_us = 0.125; // 8M 
uint32_t sys_tck_lsb_ns = 125; // 8M 
uint32_t sys_tmr_per = 1000000; //1s in us scale

int32_t tick_diff = 0;
uint32_t sys_tck_post = 0;
uint32_t time_interval_us = 0;
uint32_t time_interval_ns = 0;


uint32_t TMR_1s_cnt = 0;
uint32_t TMR_1s_cnt_tmp = 0;
volatile uint32_t TMR_INT_CNT = 0;
volatile uint8_t TMR_INT_Flag = 0; //100ms INT, if no volatile, OPT1 will causing loop errors!!!
//extern uint8_t CMD_TX_buf[];
char tmp_string[48];
uint8_t scroll_dir = 0;
uint8_t scroll_part = 0; //top half or bot half
uint8_t scroll_enable = 1;
uint16_t shift_cnt = 0;
uint8_t Pixel_shift_cnt = 0; //to save oled burning by shifting display pixels!
uint8_t Pixel_shift_dir = 0;
uint8_t shifting_active_flg = 0;
#define shift_cnt_threshold 8
#define RGB_OLED_BG_Pic_CHG_Time 10
uint8_t BG_PIC_index = 0;

uint8_t OLED_display_page = 0;

//UART CMD Interface
uint8_t UART_CMD_data;
#define CMD_PWM4_button_trig_mode 'B'
#define CMD_PWM4_auto_single_trig_mode 'S'
#define CMD_PWM4_def_mode 'd'
#define CMD_PWM4_Freq_change 'F'
#define CMD_PWM4_Duty_change 'D'
#define PWM4_Freq_upper_limit 240 //249K max
#define PWM4_DUTY_upper_limit 99 //1% to 99% max
uint8_t PWM4_set_by_Poti_EN = 1;
#define RX_BUFFER_SIZE 6


//prototypes
static void PWM1_freq_ADC_set(uint32_t request);
static void setRGBIntensity(uint32_t potentiometerReading);
static void OLED_show_Btn_status(void);
float ADCConvert_Die_Temp(void);
uint16_t ADCConvert_Die_Temp_int(void);
float ADCConvert_AN14_internal(void);
long ADCConvert0p8V(void);
//moved to Tmr1.c
//void TMR1_TimeoutCallback(void) {
//    TMR_INT_CNT++;
//    TMR_INT_Flag = 1;
//}
extern void OLED_Reset(void);
void OLED_draw_startup_screen(void);
void OLED_draw_GUI_BG_frame(void);
void OLED_draw_GUI_title(uint8_t update_EN);
void OLED_draw_PWM_info(void);
void OLED_pixel_shift_L(void);
void OLED_pixel_shift_R(void);

void UART_CMD_parse(void);
void PWM4_trig_mode_set(uint8_t mode);
void Task_1s(void);
void print_reset_reason(void);
void sin_cos_accuracy_test(void);
uint32_t sin_cos_accuracy_benchtest(float step_size); // added for benchtest, time ? 
uint32_t sin_cos_accuracy_benchtest_dummy(float step_size);

int main(void) {
    uint32_t u32RCONSave = RCON;
    RC34_PINS_Initialize();
    IO_RB9_P11_SetDigitalInput();
    ANSELBbits.ANSELB9 = 0;
    //CNPUBBITS.CNPUB9 = 1; //pull up
    CNPUBbits.CNPUB9 = 1; //pull up
    __delay_ms(1);
    uint8_t P11_Status = IO_RB9_P11_GetValue(); //RB9
    uint8_t P28_status = IO_RC3_Base28_GetValue();
    uint8_t P30_status = IO_RC4_Base30_GetValue();
    __delay_ms(1);
    SYSTEM_Initialize(); //8M default
    SCCP2_Timer_Stop();
    printf("\r\n< dsPIC33AK Curiosity DIM MPLAB 6.25 melody test demo>\r\n");
    printf("Reset source(RCON) = 0x%08lX  ", u32RCONSave);
    print_reset_reason();
    version_buf[0] = Version_Nrd;
    version_buf[1] = '.';
    version_buf[2] = Version_Nrf1;
    version_buf[3] = Version_Nrf2;

    printf("< SSD1327 SSD1357 SSD1306 OLED driver for dsPIC33A >\r\n");
    printf("-Version %sB, 23.Dez.2025 by Zell-\r\n", version_buf);
    //printf("-Version 2.0B, 10.Nov.2024 by Zell-\r\n");
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("--FW code compiled with XC16 Version: %d, OPT level: %d\n", __XC16_VERSION__, __OPTIMIZATION_LEVEL__);
    printf("--Platform has DSP engine: %d\n", __HAS_DSP__);
    //printf("--Platform has EEDATA: %d�n", __HAS_EEDATA__);
    printf("--Platform has DMA: %d\n", __HAS_DMA__); //https://onlinedocs.microchip.com/oxy/GUID-C4E60FF5-3DAB-44F1-BA61-4BD962D8F469-en-US-2/GUID-D36F9153-C4C7-4E89-B119-7E0891583DEF.html
    printf("--CPU sys tick time LSB = %d ns!", 1000 / sys_tck_lsb_scale);
    printf("--Reading OLED configuration:P11(RB9) P28(RC3) P30(RC4) status during startup: %d-%d-%d\n", P11_Status, P28_status, P30_status);
    if (1 == P11_Status) {
        printf("--SSD1327 16bit grayscale OLED active!\n");
        SSD1327_OLED_active = 1;
        SSD1357_OLED_active = 0;
    } else if (0 == P11_Status) {
        printf("--SSD1357 RGB OLED active!\n");
        SSD1357_OLED_active = 1;
        SSD1327_OLED_active = 0;
    }
    printf("--UART input CMD: %c,%c,%c and F5K/F100K to change PWM4 setting!\r\n",CMD_PWM4_button_trig_mode,CMD_PWM4_auto_single_trig_mode,CMD_PWM4_def_mode);
    // uint8_t reg_bits_tmp = RCONbits.SWR;
    //    if (1 == reg_bits_tmp) {
    //        printf("##>: Platform just performed software reset (S3)!\n");
    //        RCONbits.SWR = 0;
    //    }

    //P11(RB9) P28(RC3) P30(RC4) status during startup: 0-1-0 (or  0-0-0)

    uint32_t SCCP_PER_def = SCCP2_Timer_PeriodGet();
    //SCCP1_Timer_PeriodGet();
    ADC_res_float = ADCConvert_AN14_internal();
    printf("#>:ADC Internal CH14 voltage is %3.3f V!\r\n", ADC_res_float);
    ADC_res_float = 15.0 * ADC_res_float / 14.0;
    printf("#>:Calculated VCC input voltage is %3.3f V! Update VCC para to current value!\r\n", ADC_res_float);
    VCC_voltage = ADC_res_float;
    Die_temp = ADCConvert_Die_Temp();
    printf("#>: Approx. dsPIC Die Temperature is %3.1f degree!\r\n", Die_temp);

    ADC_res_temp = ADCConvert_Die_Temp_int();
    printf("#>: Raw dsPIC Die Temperature is %u !\r\n", ADC_res_temp);
    ADC_res_temp = ADCConvert0p8V();
    ADC_res_float = ADC_res_temp * VCC_voltage / 4096.0;
    printf("#>:ADC bandgap voltage raw is %u !\r\n", ADC_res_temp);
    printf("#>:ADC bandgap voltage is %3.3f V!\r\n", ADC_res_float);
    SCCP2_Timer_Start();
    if (Sin_Cos_test_EN) {
        printf("##>:----------sin_cos_accuracy_test now--------------\r\n");
        sin_cos_accuracy_test();
        uint32_t calc_steps = 0;
        //        TMR_1s_cnt = 0;
        //        sys_tck = SCCP2_Timer_CounterGet(); //moved to inside sin_cos_accuracy_benchtest()
        // LED7_RC10_SetHigh();
        mSTART_CAPTURE;
        // LED7_RC10_SetHigh();
        //LATCbits.LATC10 =1 ;
        sin(0.5); //600ns!? should be 45ns! 9 cycles
        //LATCbits.LATC10 =0 ;
        //LED7_RC10_SetLow();
        mPRINT_CAPTURE;

        mSTART_CAPTURE;
        LED7_RC10_SetHigh();
        sys_tck = SCCP1_Timer_CounterGet();
        while (100 > (SCCP1_Timer_CounterGet() - sys_tck)) {
            Nop();
        }
        LED7_RC10_SetLow();
        mPRINT_CAPTURE; //495ns



        LED6_RC9_SetHigh();
        mSTART_CAPTURE;
        calc_steps = sin_cos_accuracy_benchtest(0.2f);
        mPRINT_CAPTURE;
        // LED7_RC10_SetLow();
        LED6_RC9_SetLow();
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff *sys_tck_lsb_us;
        //        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        //        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        printf("##>:sin_cos math total %lu steps time cost: %lu us! Res=%f\r\n", calc_steps, time_interval_us, bench_res);
        printf("##>:sin_cos math single step time cost: %lu ns!\r\n", 1000 * time_interval_us / calc_steps); // ##>:sin_cos math single step time cost: 968 ns!

        //LED7_RC10_SetHigh();
        calc_steps = sin_cos_accuracy_benchtest_dummy(0.2f);
        //LED7_RC10_SetLow();
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff *sys_tck_lsb_us;
        printf("##>:sin_cos Dummy total %lu steps time cost: %lu us! Res=%f\r\n", calc_steps, time_interval_us, bench_res);
        printf("##>:sin_cos Dummy single step time cost: %lu ns!\r\n", 1000 * time_interval_us / calc_steps);

    }
    //test for deye math calc:
    //unsigned long __builtin_muluu(const unsigned int p0, const unsigned int p1)
    printf("##>:----------Deye math test now--------------\r\n");

    uint32_t var_32 = 0;
    _Q31 var_Q31 = 0;

    uint32_t power = 100;
    uint32_t f = 10;
    uint32_t Lp2 = 10;
    double x1 = 0;
    // LED7_RC10_SetHigh();
    // sys_tck = SCCP2_Timer_CounterGet();
    TMR_1s_cnt = 0;
    TMR_1ms_cnt = 0;
    mSTART_CAPTURE;
    sys_tck = SCCP2_Timer_CounterGet();
    sys_tck2_10ns = SCCP1_Timer_CounterGet();
    x1 = __builtin_muluu((sqrtl(__builtin_muluu(power >> 2, f) << 3)), Lp2) >> 1;
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    tck2_diff = SCCP1_Timer_CounterGet() - sys_tck2_10ns;
    TMR_1ms_cnt = 0;
    mPRINT_CAPTURE;
    //LED7_RC10_SetLow();
    time_interval_ns = sys_tmr_per * TMR_1ms_cnt + tck2_diff*sys_tck2_lsb_ns;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:AK math sqrtl(double) time cost: %lu us! %lu ns\r\n", time_interval_us, time_interval_ns);
    printf("##>:res X1= %lf \r\n", x1);
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    x1 = __builtin_muluu((sqrtf(__builtin_muluu(power >> 2, f) << 3)), Lp2) >> 1;
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;

    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:AK math sqrtf(float) time cost: %lu us!\r\n", time_interval_us);
    printf("##>:res X1= %lf \r\n", x1);
    //    TMR_1s_cnt = 0;
    //    sys_tck = SCCP2_Timer_CounterGet();
    //    x1 = __builtin_muluu((_Q31sqrt(__builtin_muluu(power >> 2, f) << 3)), Lp2) >> 1;
    //    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    //    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    //    printf("##>:Deye AK math _Q31sqrt(uint32_t) time cost: %lu us!\r\n", time_interval_us);

    // printf("##>:Deye AK math res X1= %lf \r\n", x1);
    //x1=__builtin_muluu((sqr32(__builtin_muluu(power>>2,f)<<3)),Lp2)>>1;
    //printf("##>:Deye FJ math res X1= %u\r\n",x1);


    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    x1 = __builtin_muluu((sqrt_u32(__builtin_muluu(power >> 2, f) << 3)), Lp2) >> 1;
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:AK math sqrt_u32(uint32_t) time cost: %lu us!\r\n", time_interval_us);
    printf("##>:res X1= %lf \r\n -----\r\n", x1);

    printf("##>:----------Deye math test End--------------\r\n");

    printf("##>:----------dsPIC AK math sqrt_u32 test start-------------\r\n");
    var_32 = 4293787662;
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    x1 = sqrt_u32(var_32);
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:math sqrt_u32(4293787662) time cost: %lu us!\r\n", time_interval_us);
    printf("##>:math calc res= %lf \r\n", x1);
    var_32 = 15;
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    x1 = sqrt_u32(var_32);
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:AK sqrt_u32(15) time cost: %lu us!\r\n", time_interval_us);
    printf("##>:math calc res= %lf \r\n ", x1);



    x1 = var_Q31;
    //x1 =  (var_Q31)/0x80000000;
    //    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    //    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    //    printf("##>:dsPIC math _Q31sqrt time cost: %lu us!\r\n", time_interval_us);
    //    printf("##>:math _Q31sqrt( 4293787662) res X1= %lf \r\n", x1);
    //    var_32 = 15;
    //    var_Q31 = FtoQ31(var_32); // overrun
    //    printf("##>:math var_Q31( 15) = %d (lu)\r\n", var_Q31); //2147483647
    //    var_Q31 = (_Q31)(var_32); //15
    //     printf("##>:math _Q31( 15) = %d (lu)\r\n", var_Q31); //15
    //
    //    uint8_t char_buf[24];
    //    _itoaQ31(var_Q31,char_buf);
    //    printf("##>:math _Q31sqrt( var_Q31) res X1= %lf \r\n", x1);
    //    printf("##>:math _Q31sqrt( 15) res X1= %lf \r\n", x1);
    //     printf("##>:math _Q31sqrt( 15) res var_Q31= %d \r\n", var_Q31);
    //    printf("##>:math _Q31 char_buf= %s \r\n", char_buf); // +179478 
    printf(" \r\n -------dsPIC AK math sqrt Q31 test start------------------------\r\n");

    x1 = 15 / 100.0;
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    //printf("##>:math  X1= %lf \r\n", x1);
    var_Q31 = _Q31ftoi(x1);
    //var_Q31 = (_Q31) (0.5); 
    //printf("##>:math var_Q31(15)= %d \r\n", var_Q31);

    var_Q31 = _Q31sqrt(var_Q31); //8us
    x1 = 10.0 * _itofQ31(var_Q31);
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:AK  _Q31sqrt(15) time cost: %lu us!\r\n", time_interval_us); //25 us total
    printf("##>:math _Q31sqrt (15)= %d \r\n", var_Q31); // _Q31power  2147483520 
    // printf("##>:math _Q31power (16)= %d \r\n", var_Q31); // _Q31power  2147483520 
    printf("##>:math _Q31sqrt (15/100->res*10) res X1= %lf \r\n", x1);
    // printf("##>:math _Q31sqrt (1024/1000) res X1= %lf \r\n", x1);
    printf(" \r\n ------dsPIC AK math FPU sqrt test start-----------\r\n");
    x1 = 16.2;
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    x1 = sqrtf(x1); //52us
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    time_interval_ns = tick_diff* sys_tck_lsb_ns;
    printf("##>:AK sqrtf(16.2) time cost: %lu ns!(raw: %u)\r\n", time_interval_ns, tick_diff);
    printf("##>:math res X1= %lf \r\n ", x1);

    x1 = 16.2;
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    x1 = sqrt(x1); // 0.5us@OPT=1
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    time_interval_ns = tick_diff* sys_tck_lsb_ns;
    //printf("##>:AK sqrt(16.2) time cost: %lu us!(raw: %u)\r\n", time_interval_us,tick_diff);
    printf("##>:AK sqrt(16.2) time cost: %lu ns!(raw: %u)\r\n", time_interval_ns, tick_diff);
    printf("##>:math res X1= %lf \r\n ", x1);

    x1 = 4293787662;
    //TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    x1 = sqrtf(x1); //500ns!
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    //time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    time_interval_ns = tick_diff* sys_tck_lsb_ns;
    printf("##>:AK sqrtf(4293787662) time cost: %lu ns!(raw: %u)\r\n", time_interval_ns, tick_diff);
    printf("##>:math res X1= %lf \r\n ", x1);

    x1 = 4293787662;
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    for (uint8_t loop_cnt = 0; loop_cnt < 10; loop_cnt++) {

        x1 = sqrtf(x1);

    }
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:AK sqrtf(4293787662) 10 loop time cost: %lu us!(raw: %u)\r\n", time_interval_us, tick_diff);
    printf("##>:math res X1= %lf \r\n ", x1);

    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    for (uint8_t loop_cnt = 0; loop_cnt < 10; loop_cnt++) {
        Nop();
    }
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
    printf("##>:AK empty 10 loop time cost: %lu us!(raw: %u)\r\n", time_interval_us, tick_diff);




    printf(" \r\n>>>>>>>>>>>>>>>MATH test Ende<<<<<<<<<<<<<<<\r\n", x1);

    printf(" \r\n ", x1);
    printf("#>:SPI bus init...\r\n");
    uint8_t open_res = SPI1_Open(SPI_bus_2M); //1M
    uint8_t reg_val1 = SPI1CON1bits.CKE;
    uint8_t reg_val2 = SPI1CON1bits.CKP;
    uint8_t SPI_mode32 = SPI1CON1bits.MODE32;
    uint8_t SPI_mode16 = SPI1CON1bits.MODE16;
    if (open_res) {
        printf("#>:SPI bus init with CKE:%d; CKP:%d ; Mode32:%d ;Mode16:%d\r\n", reg_val1, reg_val2, SPI_mode32, SPI_mode16);
        printf("#>:SPI SPI1CON1:%lu\r\n", SPI1CON1);

    }
    uint8_t text_size = 16;
    if (SSD1357_OLED_active) {
        LED5_RC8_Toggle();
        printf("#>:SSD1357 OLED init...\r\n");
        SSD1357_OLED_Init();
        LCD_Fill(0, 0, SSD1357_W, SSD1357_H, GRAYBLUE);
        OLED_RGB_ShowString(0, 0, "R", RED, GRAYBLUE, text_size, 0);
        OLED_RGB_ShowString(8, 0, "G", GREEN, GRAYBLUE, text_size, 0);
        OLED_RGB_ShowString(16, 0, "B", BLUE, GRAYBLUE, text_size, 0);
        OLED_RGB_ShowString(32, 0, "OLED", MAGENTA, GRAYBLUE, text_size, 0);
        text_size = 12;
        OLED_RGB_ShowString(4, 20, "64x64", CYAN, GRAYBLUE, text_size, 0);
        OLED_RGB_ShowString(0, 36, "dsPIC AK", YELLOW, GRAYBLUE, text_size, 0);
        OLED_RGB_ShowString(0, 52, version_buf, YELLOW, GRAYBLUE, text_size, 0);
        //LCD_ShowIntNum(10,20,SSD1357_W,3,CYAN,GRAYBLUE,text_size);
        __delay_ms(500);
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        LCD_ShowPicture(0, 0, SSD1357_W, SSD1357_H, gImage_1); //mixed color bands
        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        printf(">>:SSD1357 OLED draw single pic cost: %lu ms!\r\n", time_interval_us / 1000);
        __delay_ms(500);
        //LCD_ShowPicture(0, 0, SSD1357_W, SSD1357_H, gImage_2); //sun flower
        //LCD_ShowPicture(0, 0, SSD1357_W, SSD1357_H, gImage_1); //mixed color bands
        LCD_ShowPicture(0, 0, SSD1357_W, SSD1357_H, gImage_2);

    }

    if (SSD1309_OLED_EN) {
        LED5_RC8_Toggle();
        printf("#>:SSD1309 OLED init...\r\n");
        SSD1309_OLED_Init();
        SSD1309_OLED_ColorTurn(0); //0???? 1????
        SSD1309_OLED_DisplayTurn(0); //0???? 1??180???
        __delay_ms(200);
        //SSD1309_OLED_DisPlay_On();
        //printf("#>:SSD1309 OLED show ASCII now...\r\n");
        //OLED_CS_High();
        //OLED_ShowString(0,48,"ASCII:",16,1); 
        SSD1309_OLED_Refresh();
        __delay_ms(100);
        printf("#>:SSD1309 OLED draw Picture 1 now...\r\n");
        OLED_ShowPicture(0, 0, 128, 64, BMP1, 1);
        SSD1309_OLED_Refresh(); //push to GRAM
        __delay_ms(1000);

        LED5_RC8_Toggle();
        OLED_CS_Set();
        printf("#>:SSD1309 OLED draw Chinese char...\r\n");
        //OLED_ShowChinese(0, 0, 0, 16,1); //?
        //OLED_ShowChinese(18, 0, 1, 16,1); //?
        //OLED_ShowChinese(36, 0, 2, 16,1); //?
        OLED_ShowString(0, 0, "dsPIC A", 16, 1);
        OLED_ShowChinese(54, 0, 3, 16, 1); //?
        OLED_ShowChinese(72, 0, 4, 16, 1); //?
        OLED_ShowChinese(90, 0, 5, 16, 1); //?
        OLED_ShowChinese(108, 0, 6, 16, 1); //?
        SSD1309_OLED_Refresh();
        __delay_ms(500);

        SSD1309_OLED_Clear();
        SSD1309_OLED_ShowPicture(0, 0, 128, 56, gImage_AK_dsPIC_3n, 1);
        SSD1309_OLED_Refresh();
        printf("#>:SSD1309 OLED draw Picture 2 now...\r\n");

        __delay_ms(1000);
        //SSD1309_OLED_Clear();

        //SSD1309_OLED_Refresh();


    }


    if (SSD1327_OLED_active) {
        printf("#>:SSD1327 OLED init...\r\n");
        SSD1327_OLED_Reset();
        __delay_us(100);
        SPI_DC_RB10_SetHigh();
        printf("#>:SSD1327 OLED Reset finished!\r\n");
        SPI_DC_RB10_SetLow();
        SPI_CS_RB7_SetLow();
        SSD1327_OLED_Init(); //has issues, no sck output!
        //SPI1_ByteExchange(0xaa);//has issues
        printf("#>:SSD1327 OLED Reg init finished!\r\n");
        clearBuffer();
        //__delay_us(100);

        SSD1327_FillBuffer(); ////fill all pixels to 1, appears in grey color
        //SSD1327_Buffer_White();
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        writeFullBuffer(); //clear display
        sys_tck_post = SCCP2_Timer_CounterGet();
        tick_diff = sys_tck_post - sys_tck;
        //tick_diff = sys_tmr_per*TMR_1s_cnt+SCCP2_Timer_CounterGet()-sys_tck; 
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        TMR_1s_cnt = 0;
        printf(">>:writeFullBuffer Time cost: %lu us\r\n", time_interval_us);
        __delay_ms(100);
        //printf(">#OLED frame buffer cleared!\r\n");
        //SPI_CS_RB7_SetHigh();
        //__delay_ms(200);
        clearBuffer();
        SSD1327_FillBuffer_black(); //test works!
        writeFullBuffer();
        SPI_CS_RB7_SetHigh();
        clearBuffer();
        SPI_CS_RB7_SetLow();
        LED5_RC8_Toggle();
        //    drawPixel(2,2,4,true);
        //    __delay_us(2);
        //    drawPixel(65,1,5,true);
        //    __delay_us(2);

        clearBuffer();
        printf(">>:OLED Drawing bench test now:\r\n");
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        OLED_testfillrect(6);
        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        printf(">>:OLED_testfillrect cost: %lu ms, 1s_cnt: %lu, raw:%lu\r\n", time_interval_us / 1000, TMR_1s_cnt, time_interval_us);

        //testdrawcircle();
        LED5_RC8_Toggle();
        //__delay_ms(200);
        //OLED_testfillrect(3);
        setupScrolling(0, OLED_Width / 2 - 1, 0, OLED_Height / 2 - 1, SSD1327_SCROLL_6, 1); //test ok
        startScrolling();
        __delay_ms(300);
        stopScrolling();
        setupScrolling(0, OLED_Width / 2 - 1, 0, OLED_Height / 2 - 1, SSD1327_SCROLL_4, 0);
        startScrolling();

        __delay_ms(200);
        stopScrolling();
        //printf(">#OLED Draw startup screen now:\r\n");
        //SPI_CS_RB7_SetLow();
        clearBuffer();
        //SSD1327_FillBuffer_black();
        //writeFullBuffer();
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        __delay_us(100);

        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        printf(">>:delay 100us Time cost: %lu us\r\n", time_interval_us);
        // OLED_fastfillrect(2);
        //__delay_ms(200);
        //    testfilltriangle();
        //    //    __delay_ms(300);
        clearBuffer();
        ClrWdt();
        Nop();

        SSD1327_FillBuffer_black();
        TMR_1s_cnt = 0;
        sys_tck = SCCP2_Timer_CounterGet();
        writeFullBuffer_fast();
        sys_tck_post = SCCP2_Timer_CounterGet();
        //tick_diff = sys_tck_post-sys_tck; 
        tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
        time_interval_us = sys_tmr_per * TMR_1s_cnt + tick_diff / sys_tck_lsb_scale;
        TMR_1s_cnt = 0;
        printf("#>:Fast writeFullBuffer Time cost: %lu us\r\n", time_interval_us);


        //    //ClrWdt();
        testdrawcircle();
        clearBuffer();

        //----------
        //memset(tmp_string,0,sizeof(tmp_string));
        //uint8_t TXT_brightness = 4;
        //uint8_t txt_size = 8;
        //sprintf(tmp_string, "Demo by Zell 2023"); //OLED  slide_pos 0-255
        //drawCharArray(8, 8, tmp_string, TXT_brightness, txt_size);
        //writeUpdates();

        clearBuffer();
        OLED_draw_startup_screen(); //issues!
        //__delay_ms(100);
    }
    ADC1_IndividualChannelInterruptEnable(ADC1_Channel6); //poti
    ADC1_IndividualChannelInterruptEnable(ADC1_Channel10); //poti
    TMR1_Start();
    TMR_INT_Flag = 0;

    //PG1DC= (uint16_t)(PG1PER*0.25);
    //PG1DC= PG1PER>>3;
    PWM1_2_Enable();
    printf(">>#: PG1 PG2 Enabled!\r\n");
    uint32_t DC_temp = 0; // *100 scale
    float DC_float_tmp = 0;
    Nop();
    ClrWdt();
    if (PWM4_single_TRG_Mode_EN) {
        PWM4_trig_mode = PWM4_button_trig_mode;
        PWM4_single_trigger_mode(PWM4_single_TRG_cnt);
        printf(">>#: PG4(RC2) set to single trigger mode!\r\n");
        PWM4_Enable();
    } else if (PWM4_Auto_periodic_TRG_Mode_EN) {
        PWM4_trig_mode = PWM4_auto_single_trig_mode;
        PWM4_single_trigger_mode(PWM4_single_TRG_cnt);
        printf(">>#: PG4(RC2) set to auto periodic single trigger mode!\r\n");
        PWM4_Enable();

    } else {
        printf(">>#: PG4(RC2) set to def auto continous waveform mode! Press S3 to EN/DIS output!\r\n");
        PWM4_Enable();

    }

    PWM1_Per_def =PG1PER;
    printf(">>#: main loop running now!\r\n");
    printf("--Press S1 to switch between DC and freq adjust mode!\r\n");
    //OLED_draw_GUI_BG_frame();
    TMR_1s_cnt = 0;
    SCCP2_Timer_Start();
    uint16_t freq1 = 0;
    uint16_t freq2 = 0;
    uint16_t freq4 = 0;
    //uint32_t TMR_1s_cnt_tmp = 0;
    LED7_RC10_SetDigitalOutput();
    LED1_RC4_SetDigitalOutput();
    LED3_RC6_SetDigitalOutput();
    LED4_RC7_SetDigitalOutput();
    _AD1CMP6IE = 1;

    while (1) {
        if (0 < TMR_INT_Flag) {

            if (100 == TMR_INT_CNT) {
                if (SSD1309_OLED_EN) {
                    SSD1309_OLED_Clear();

                } else if (SSD1327_OLED_active) {
                    stopScrolling();
                    clearBuffer();
                    SSD1327_FillBuffer_black(); //test works!
                    writeFullBuffer_fast();
                    scroll_enable = 0;
                    drawRect_transitionBand(0, 0, 127, 7, 15, 1);
                    drawRect(0, 8, OLED_Width - 1, OLED_Height - 1, 0, 1); //clear rest part of the screen
                    OLED_draw_GUI_BG_frame();
                    __delay_us(50);
                    OLED_draw_GUI_title(1);
                }
            }

            if ((0 == TMR_INT_CNT % OLED_display_interval)&&(100 < TMR_INT_CNT)) {
                stopScrolling();
                //clearBuffer();

                //                SSD1327_FillBuffer_black(); //test works!
                //                writeFullBuffer();
                TMR_1s_cnt_tmp = TMR_1s_cnt;
                sys_tck = SCCP2_Timer_CounterGet();
                clearBuffer();
                OLED_draw_GUI_title(0);
                //clearFrameBuffer(0,8,OLED_Width,OLED_Height-8); //30ms
                //---update displays
                OLED_draw_PWM_info();
                //---
                tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
                time_interval_us = sys_tmr_per * (TMR_1s_cnt - TMR_1s_cnt_tmp) + tick_diff / sys_tck_lsb_scale;

                //if(shifting_active_flg)
                //   startScrolling();


            }



            if (0 == TMR_INT_CNT % printf_cnt_interval) {
                LED3_RC6_SetHigh();
                stopScrolling();
                printf("--AK test loop cnt:%lu--\r\n", TMR_INT_CNT);
                printf(">>:OLED_draw Time: %lu ms\r\n", time_interval_us / 1000);
                // printf("buf: %#X,%#X \r\n", CMD_TX_buf[0],CMD_TX_buf[1] );
                Die_temp = ADCConvert_Die_Temp();
                printf("#>: Approx. Die Temp. is %3.1f degree\r\n", Die_temp);
                //printf("#>: Raw Poti voltage: %u, INT_flag cnt=%lu \r\n", ADC_poti, ADC_INT_flag); //issues



                Poti_voltage = VCC_voltage * ADC_poti / 4096;
                printf("#>: Poti voltage: %3.3f V,INT_flag cnt=%lu \r\n", Poti_voltage, ADC_INT_flag);






                DC_temp = 100 * PG1DC / PG1PER;
                DC_float_tmp = 100.0 * PG1DC / PG1PER;
                printf("#>: PWM1 DC= %lu %%,%2.1f%% ", DC_temp, DC_float_tmp);
                DC_temp = 100 * PG2DC / PG2PER;
                printf("#PWM2 DC= %lu %% ", DC_temp);
                DC_temp = 100 * PG4DC / PG4PER;
                printf("#PWM4 DC= %lu %%\r\n", DC_temp);

                freq1 = 127968 / PG1PER;
                freq2 = 127968 / PG2PER;
                freq4 = 127968 / PG4PER;
                printf("#>: PWM1 Freq= %u Khz; PWM2 Freq= %u Khz; PWM4 Freq= %u Khz \r\n", freq1, freq2, freq4);

                if (PWM1_Freq_mode) {
                    printf("#>: PWM1 Freq is based on ADC value:%d\r\n", ADC_poti);
                    PWM1_freq_ADC_set(ADC_poti);
                    printf("#>: PWM1 Period new value:%lu \r\n", PG1PER);
                }


                //if (scroll_dir){
                //setupScrolling(uint8_t startRow, uint8_t endRow, uint8_t startCol, uint8_t endCol, uint8_t scrollSpeed, bool right)
                //stopScrolling();
                if ((scroll_enable) &&(SSD1327_OLED_active)) {
                    scroll_part++;
                    scroll_dir = 1 - scroll_dir;

                    stopScrolling();
                    if ((3 == scroll_part) || (4 == scroll_part)) {
                        setupScrolling((OLED_Height / 2 - 7), OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_4, scroll_dir);
                        scroll_part = 0;
                    } else {
                        setupScrolling(0, (OLED_Height / 2 - 8), 0, OLED_Width / 2 - 1, SSD1327_SCROLL_6, scroll_dir); //test ok
                    }

                    //setupScrolling(0, (OLED_Width / 2 - 1),  OLED_Height / 2 - 7, OLED_Height-1, SSD1327_SCROLL_6, 1-scroll_dir); //test ok
                    startScrolling();
                }
                // }
                //  else {
                // setupScrolling(0, (OLED_Width / 2 - 1), 0, OLED_Height / 2 - 1, SSD1327_SCROLL_4, 0);
                // startScrolling();
                //  }



                ADC_INT_flag = 0;
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_1);
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_2);
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_4);
                //__delay_us(100);

                //PWM_DutyCycleSet(PWM_GENERATOR_4, ADC_poti);
                LED3_RC6_SetLow();

            }

            if (PWM1_Freq_mode) {
                //                printf("#>: PWM1 Freq is based on ADC value:%d\r\n", ADC_poti);
                //                PWM1_freq_ADC_set(ADC_poti);
                //                printf("#>: PWM1 Period new value:%lu \r\n", PG1PER);
            } else {
                setRGBIntensity(ADC_poti); //issue solved, update manually
            }
            TMR_INT_Flag = 0;
            LED5_RC8_Toggle();
        }
        //_delay_ms(500);
    }
}

void Task_1s(void) {

    uint8_t tmp_bit = 0;
    LED4_RC7_SetHigh();
    OLED_show_Btn_status();

    UART_CMD_parse();
    printf("<1S>#:Btn S1 press cnt:%u, S2:%u,S3:%u\r\n", Btn_S1_press_cnt, Btn_S2_press_cnt, Btn_S3_press_cnt);

    //PWM4_single_TRG_Mode_EN
    //printf(">>:PWM4 trig mode: %u", PWM4_trig_mode);

    if (PWM4_button_trig_mode == PWM4_trig_mode) {
        if (Btn_S3_pressed) {
            // PWM4_Enable();
            //printf("\r\n >>#:PWM4 TRIG bit:%u \r\n", PG4STATbits.TRIG);

            PG4STATbits.TRSET = 1;
            //tmp_bit = PG4STATbits.TRIG;
            //printf("\r\n >>#:PWM4 S.Triggered! TRG bit:%u \r\n", tmp_bit);
            printf(">>#:PWM4 Btn.Triggered!\r\n");
            Btn_S3_pressed = 0;
        }



    } else if (PWM4_auto_single_trig_mode == PWM4_trig_mode) {

        PG4STATbits.TRSET = 1;
        //tmp_bit = PG4STATbits.TRIG;
        //printf("\r\n >>#:PWM4 Auto Triggered! TRG bit:%u \r\n", tmp_bit);
        printf(">>#:PWM4 Auto Triggered!\r\n");
    } else {
        //def mode
        if (Btn_S3_pressed) {

            if (S3_reset_control_EN) {
                printf("\r\n<1S>>:Btn S3 press, software reset now!\r\n");
                __delay_ms(100);
                //INTERRUPT_GlobalDisable();
                __builtin_disable_interrupts();
                asm("reset"); //nopt issue here!
            }
            PWM4_EN_flag = 1 - PWM4_EN_flag;
            if (PWM4_EN_flag){
                 PWM4_Enable();
            }
            else PWM4_Disable();
            
           Btn_S3_pressed = 0;

        }
    }

    if (Btn_S2_pressed) {
        OLED_display_page++;
        if (OLED_display_page > 2) {
            OLED_display_page = 0;
        }
        Btn_S2_pressed = 0;
    }



    if (PWM1_Freq_mode) {

        OLED_display_page = 0;
    }
    //if (4 < (TMR_1s_cnt - TMR_1s_cnt_tmp)) {
    if (0 == (TMR_1s_cnt % 3)) {
        TMR_1s_cnt_tmp = TMR_1s_cnt;

        if (Pixel_shift_dir)
            Pixel_shift_cnt++;
        else
            Pixel_shift_cnt--;

        //Pixel_shift_dir=1-Pixel_shift_dir;
        if (254 < Pixel_shift_cnt) {
            Pixel_shift_cnt = 0;
            Pixel_shift_dir = 1;
        } else if (Pixel_shift_cnt > shift_cnt_threshold) {
            Pixel_shift_cnt = shift_cnt_threshold;
            //shifting_active_flg = 1;
            Pixel_shift_dir = 0;
        }

    }
    if (SSD1327_OLED_active) {
        if ((0 == TMR_1s_cnt % OLED_saver_interval)&&(141 < TMR_INT_CNT)) {
            LED6_RC9_Toggle();
            shift_cnt = 0;
            shifting_active_flg = 1;
            //stopScrolling();
            if (scroll_dir) {

                OLED_pixel_shift_R();
                OLED_pixel_shift_L();
            } else {
                OLED_pixel_shift_L();
                OLED_pixel_shift_R();
            }
            //clearBuffer();
            //SSD1327_FillBuffer_black(); //test works!
            //writeFullBuffer_fast();
            scroll_dir = 1 - scroll_dir;
            shifting_active_flg = 0;
            //scroll_dir = 1 - scroll_dir;
            //LED6_RC9_Toggle();
        }
    }
    if (SSD1357_OLED_active) {
        if ((0 == TMR_1s_cnt % RGB_OLED_BG_Pic_CHG_Time)&&(TMR_1s_cnt > 1)) {
            printf(">>:change BG pic now...\r\n");
            if (0 == BG_PIC_index % 2)
                LCD_ShowPicture(0, 0, SSD1357_W, SSD1357_H, gImage_2);
            else
                LCD_ShowPicture(0, 0, SSD1357_W, SSD1357_H, gImage_1);
            BG_PIC_index++;
        }




    }


    LED4_RC7_SetLow();
}

void UART_CMD_parse(void) {

    if (UART1_IsRxReady()) {
        uint16_t i = 0;
        char ReceivedChar[RX_BUFFER_SIZE]; // Define your buffer size
        memset(ReceivedChar, 0, RX_BUFFER_SIZE);
        while (U1STATbits.RXBE == 0) // Check if RX buffer has data to read     {
        {
            ReceivedChar[i++] = U1RXB; // Read a character from RX buffer     }
            //UART_CMD_data = U1RXB; //UART1_Read();
            // Reset index if buffer is full
            if (i >= RX_BUFFER_SIZE) {
                i = 0;
            }
        }
        UART_CMD_data = ReceivedChar[0];
        //         while (U1STATbits.RXBE == 0) // Check if RX buffer has data to read     {
        //        {
        //
        //            UART_CMD_data = U1RXB; //UART1_Read();
        //
        //        }
        //


        if (CMD_PWM4_button_trig_mode == UART_CMD_data) {

            PWM4_trig_mode = PWM4_button_trig_mode;
            printf("\r\n>>#:UART CMD %c received,change to PWM4 s3 button trig mode!\r\n", UART_CMD_data);
        } else if (CMD_PWM4_auto_single_trig_mode == UART_CMD_data) {
            PWM4_trig_mode = PWM4_auto_single_trig_mode;
            printf("\r\n>>#:UART CMD %c received,change to PWM4 auto single trig mode!\r\n", UART_CMD_data);
        } else if (CMD_PWM4_def_mode == UART_CMD_data) {
            PWM4_trig_mode = PWM4_def_mode;
            printf("\r\n>>#:UART CMD %c received,change to PWM4 def retriggerable mode!\r\n", UART_CMD_data);
        } else if (CMD_PWM4_Freq_change == UART_CMD_data) {
            printf("\r\n>>#:UART CMD %c received,change PWM4_Freq now!\r\n", UART_CMD_data);
            if (i < 3) {
                printf("\r\n>!#:UART CMD error: invalid length (need FxK format)\r\n");
                return;
            }
            if (ReceivedChar[i - 1] != 'K') {
                printf("\r\n>!#:UART CMD error: not end with K\r\n");
                return;
            }
            char num_buf[5] = {0};
            uint8_t num_len = i - 2; // ??????
            if (num_len > 4) { // ???????????
                printf("\r\n>!#:UART CMD error: frequency value too big\r\n");
                return;
            }
            memcpy(num_buf, &ReceivedChar[1], num_len);
            uint32_t new_freq = atoi(num_buf);
            if (new_freq < 1 || new_freq > PWM4_Freq_upper_limit) {
                printf("\r\n>!#:UART CMD error: frequency out of range (1-%uKhz)\r\n",PWM4_Freq_upper_limit);
                return;
            }
            PWM4_freq = new_freq;
            printf("\r\n>>:UART CMD %c received, PWM4 frequency changed to %d Khz!\r\n",
                    CMD_PWM4_Freq_change, PWM4_freq);
            uint32_t Per4_tmp = PG4PER;
            Per4_tmp = 1000000/PWM4_freq/PWM_clock_time_LSB;
            uint32_t DC4_tmp = 1000*PG4DC/PG4PER;
           
            PWM_PeriodSet(PWM_GENERATOR_4, Per4_tmp);
             
              DC4_tmp = DC4_tmp*Per4_tmp/1000;
            PWM_DutyCycleSet(PWM_GENERATOR_4, DC4_tmp);
            printf(">#:PWM4 Per:%lu, DC:%lu\r\n",PG4PER,PG4DC);
            //23:52:53.281 -> >>:UART CMD F received, PWM4 frequency changed to 1 Khz!  DC bug here
//23:52:53.298 -> >#:PWM4 Per:128000, DC:74496





        }
        else if (CMD_PWM4_Duty_change == UART_CMD_data) {  // ??CMD_PWM4_Duty_change???'D'
            printf("\r\n>>#:UART CMD %c received,change PWM4_Duty now!\r\n", UART_CMD_data);
            if (i < 3) {
                printf("\r\n>!#:UART CMD error: invalid length (need DxxP format)\r\n");
                return;
            }
            if (ReceivedChar[i - 1] != 'P') {
                printf("\r\n>!#:UART CMD error: not end with P\r\n");
                return;
            }
            char num_buf[5] = {0};
            uint8_t num_len = i - 2; // ?????D?????P
            if (num_len > 3) { // ?????100???3???
                printf("\r\n>!#:UART CMD error: duty value too big\r\n");
                return;
            }
            memcpy(num_buf, &ReceivedChar[1], num_len);
            uint32_t new_duty = atoi(num_buf);
            if (new_duty < 0 || new_duty > PWM4_DUTY_upper_limit) {
                printf("\r\n>!#:UART CMD error: duty out of range (0-%u%%)\r\n", PWM4_DUTY_upper_limit); 
                return;
            }
            
            // ???????
            uint32_t DC4_tmp;
            if (new_duty == 0) {
                DC4_tmp = 0; // 0%???
            } else if (new_duty == 100) {
                DC4_tmp = PG4PER-1; // 100%???
            } else {
                DC4_tmp = (new_duty * PG4PER) / 100; // ?????????
            }
            
            PWM_DutyCycleSet(PWM_GENERATOR_4, DC4_tmp);
            printf("\r\n>>:UART CMD %c received, PWM4 duty changed to %u %%!\r\n",
                    CMD_PWM4_Duty_change, new_duty);
            printf(">#:PWM4 Per:%lu, DC:%lu\r\n", PG4PER, PG4DC);
            PWM4_set_by_Poti_EN = 0;
        }
        else {
            // undefined CMD
            printf("\r\n>!#:UART CMD error: unknown command %c(%c)\r\n", ReceivedChar[0], UART_CMD_data);
        }

        PWM4_trig_mode_set(PWM4_trig_mode);
    }
}

long ADCConvert0p8V(void) {
    // 0.8V is connected to Ch15
    //AD1SWTRGbits.CH2TRG = 1; // trigger channel 2
    //while(AD1STATbits.CH2RDY == 0); // wait for 64 results accumulated
    uint16_t res = 0;
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel15);
    while (ADC1_IsConversionComplete(ADC1_Channel15) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel15);
    return res;
    //    if ((res >> 3) == 0) {
    //        while (1);
    //    }
    //    return (res >> 3);
}

//long ADCConvertPot()
//{
//    // pot is connected to RA7/AN0
//    AD5SWTRGbits.CH0TRG = 1; // trigger channel 0
//    while(AD5STATbits.CH0RDY == 0); // wait for result
//    return AD5CH0DATA;
//}

float ADCConvert_Die_Temp(void) {
    float temp_die = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel13);
    while (ADC1_IsConversionComplete(ADC1_Channel13) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel13);
    temp_die = ((float) res / 4096.0) * VCC_voltage;
    temp_die = (temp_die * (-585.0))+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //1.5mv/degree??
    // celsius = (diode_voltage *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //further characterization required to optimize accuracy.
    //fahrenheit = 9.0 * celsius / 5.0 + 32;
    //return ADC1_ConversionResultGet(ADC1_Channel13);
    return temp_die;
    //return res;
}

uint16_t ADCConvert_Die_Temp_int(void) {
    //float temp_die = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel13);
    while (ADC1_IsConversionComplete(ADC1_Channel13) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel13);
    //temp_die = (res *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    // celsius = (diode_voltage *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //further characterization required to optimize accuracy.
    //fahrenheit = 9.0 * celsius / 5.0 + 32;
    //return ADC1_ConversionResultGet(ADC1_Channel13);
    //return temp_die;
    return res;
}

//compensate for VCC_voltage

float ADCConvert_AN14_internal(void) {
    float temp = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel14);
    while (ADC1_IsConversionComplete(ADC1_Channel14) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel14);
    temp = ((float) res / 4096.0) * VCC_voltage;

    return temp;
    //return res;
}

static void setRGBIntensity(uint32_t potentiometerReading) {
    if(PWM4_set_by_Poti_EN){
        ledRed.setIntensity(potentiometerReading);  // PWM_DutyCycleSet(PWM_GENERATOR_4, request);
    }
    ledGreen.setIntensity(potentiometerReading); //PG2
    ledBlue.setIntensity(potentiometerReading); //PG1
}

static void OLED_show_Btn_status(void) {
    uint8_t x_pos = 8;
    uint8_t y_pos = 8;
    uint8_t txt_size = 8;
    if (SSD1309_OLED_EN) {

        x_pos = 0;
        y_pos = 36;
        //y_spacing = 2;

        memset(&tmp_string, 0, sizeof (tmp_string));
        // y_pos = y_pos + txt_size;
        //txt_size = 12;
        sprintf(tmp_string, "Btn1:%u Btn2:%u Btn3:%u ", Btn_S1_pressed, Btn_S2_pressed, Btn_S3_pressed); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        Btn_S1_pressed = 0;
        Btn_S2_pressed = 0;
        Btn_S3_pressed = 0;
        memset(&tmp_string, 0, sizeof (tmp_string));

    }

}

void OLED_draw_startup_screen(void) {
    //uint8_t width = 128;
    //uint8_t height = 64;
    uint8_t x_pos = 8;
    uint8_t y_pos = 8;

    uint8_t TXT_brightness = 3;
    uint8_t txt_size = 8; //8,16,32
    //clearFrameBuffer(0,0, width, height); //x,y
    //memset(&tmp_string, NULL, sizeof (tmp_string));
    memset(&tmp_string, 0, sizeof (tmp_string));
    sprintf(tmp_string, "SSD1327 OLED"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    memset(&tmp_string, 0, sizeof (tmp_string));
    TXT_brightness = 5;
    sprintf(tmp_string, "Demo Zell 2024"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos + txt_size, tmp_string, TXT_brightness, txt_size);
    TXT_brightness = 7;
    txt_size = 16;
    x_pos = 4;
    y_pos = y_pos + txt_size * 2;
    sprintf(tmp_string, "dsPIC33A 32bit"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    TXT_brightness = 6;
    y_pos = y_pos + txt_size;
    txt_size = 32;
    x_pos = 8;
    sprintf(tmp_string, "4Bit"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    TXT_brightness = 7;
    y_pos = y_pos + txt_size;
    x_pos = 4;
    txt_size = 16;
    sprintf(tmp_string, "16 Greyscale"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);

    //writeUpdates();
    writeFullBuffer_fast();
}

void OLED_draw_GUI_BG_frame(void) {

    uint8_t pixel_brightness = 2;
    drawRect(0, OLED_Width - 1, 0, OLED_Height - 1, pixel_brightness, true);
    pixel_brightness = 0;
    drawRect(2, OLED_Width - 3, 0, OLED_Height - 3, pixel_brightness, true);
    //writeUpdates();
}

void OLED_draw_GUI_title(uint8_t update_EN) {

    uint8_t x_pos = 4;
    uint8_t y_pos = 4;
    uint8_t TXT_brightness = 2;
    uint8_t txt_size = 8; //8,16,32
    //uint8_t y_spacing = 0;

    sprintf(tmp_string, "dsPIC33A 32bit"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    if (update_EN) {
        writeUpdates(); //oled update GRAM
    }
}

void OLED_draw_PWM_info(void) {
    //    uint8_t width = 128;
    //    uint8_t height = 64;
    uint8_t x_pos = Pixel_shift_cnt;
    uint8_t y_pos = 15;
    uint8_t y_spacing = 0;

    uint8_t TXT_brightness = 3;
    uint8_t txt_size = 16; //8,16,32

    uint16_t freq = 0;
    uint16_t DC_temp = 0;


    if (SSD1327_OLED_active) {

        //clearFrameBuffer(0,0, width, height); //x,y
        //memset(&tmp_string, NULL, sizeof (tmp_string));
        if (PWM1_Freq_mode) {
            drawCircle(OLED_Width - 10, y_pos + txt_size / 2, 3, TXT_brightness);
            drawCircle(OLED_Width - 10, y_pos + txt_size + txt_size / 2, 3, 0);
        } else {
            drawCircle(OLED_Width - 10, y_pos + txt_size / 2, 3, 0);
            drawCircle(OLED_Width - 10, y_pos + txt_size + txt_size / 2, 3, TXT_brightness);
        }

        memset(&tmp_string, 0, sizeof (tmp_string));
        //freq = 127968 / PG1PER; //PER 1264
        freq = 128000 / PG1PER; //7.8125ns per LSB, 128000
        DC_temp = 100 * PG1DC / PG1PER;
        sprintf(tmp_string, "PWM1:%u Khz", freq); //OLED  slide_pos 0-255
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        TXT_brightness = 4;
        y_pos += txt_size;

        sprintf(tmp_string, "DC:%u%%", DC_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        TXT_brightness = 3;
        //    txt_size =16;
        //   x_pos = 4;
        y_pos = y_pos + txt_size;
        freq = 128000 / PG2PER;
        DC_temp = 100 * PG2DC / PG2PER;

        sprintf(tmp_string, "PWM2:%u Khz", freq); //OLED  slide_pos 0-255
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos += txt_size;
        TXT_brightness = 4;
        sprintf(tmp_string, "DC:%u%%", DC_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);

        TXT_brightness = 2;
        y_pos = y_pos + txt_size;
        freq = 128000 / PG4PER;
        DC_temp = 100 * PG4DC / PG4PER;
        sprintf(tmp_string, "PWM4:%u Khz", freq); //OLED  slide_pos 0-255
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos += txt_size;
        TXT_brightness = 4;
        sprintf(tmp_string, "DC:%u%%", DC_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);

        TXT_brightness = 1;
        y_pos = OLED_Height - txt_size - 1;
        memset(&tmp_string, 0, sizeof (tmp_string));
        sprintf(tmp_string, "T_die:%3.1fC", Die_temp); //OLED  slide_pos 0-25
        drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        memset(&tmp_string, 0, sizeof (tmp_string));

        writeUpdates(); //oled update GRAM
        //writeFullBuffer();
    } else if (SSD1309_OLED_EN) {
        txt_size = 8;
        x_pos = 0;
        y_pos = 0;
        y_spacing = 4;
        //SSD1309_OLED_Clear();

        memset(&tmp_string, 0, sizeof (tmp_string));
        freq = 127968 / (PG1PER);
        DC_temp = 100 * PG1DC / PG1PER;
        sprintf(tmp_string, "PWM1:%u Khz", freq); //OLED  slide_pos 0-255
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);

        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos = y_pos + txt_size;
        txt_size = 12;
        sprintf(tmp_string, "DC1:%u%% ", DC_temp); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);

        txt_size = 8;
        freq = 128000 / PG2PER;
        DC_temp = 100 * PG2DC / PG2PER;
        y_pos = y_pos + txt_size + y_spacing;
        memset(&tmp_string, 0, sizeof (tmp_string));
        sprintf(tmp_string, "PWM2:%u Khz", freq); //OLED  slide_pos 0-255
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos = y_pos + txt_size;
        //txt_size = 12;
        sprintf(tmp_string, "DC2:%u%% ", DC_temp); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);


        memset(&tmp_string, 0, sizeof (tmp_string));
        y_pos = OLED_1309_Height - txt_size;
        txt_size = 16;
        sprintf(tmp_string, "T_die:%3.1fC", Die_temp); //OLED  slide_pos 0-25
        OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);
        SSD1309_OLED_Refresh();

    } else if (SSD1357_OLED_active) {
        uint16_t Forecolor = GRED;
        uint16_t Backgroundcolor = GRAYBLUE; //BLACK
        uint8_t rendering_mode = 0; //test with Background color, 1 fusion with existing ground
        txt_size = 16;
        x_pos = 0;
        y_pos = 32;
        y_spacing = 4;
        memset(&tmp_string, 0, sizeof (tmp_string));
        if (0 == OLED_display_page) {
            freq = 127968 / (PG1PER);
            DC_temp = 100 * PG1DC / PG1PER;
            sprintf(tmp_string, "PWM1:%u%% ", DC_temp); //OLED  slide_pos 0-255
        } else if (1 == OLED_display_page) {

            freq = 128000 / (PG2PER);
            DC_temp = 100 * PG2DC / PG2PER;
            sprintf(tmp_string, "PWM2:%u%% ", DC_temp); //OLED  slide_pos 0-255
        } else {

            freq = 128000 / (PG4PER);
            DC_temp = 100 * PG4DC / PG4PER;
            sprintf(tmp_string, "PWM4:%u%% ", DC_temp); //OLED  slide_pos 0-255
        }
        OLED_RGB_ShowString(x_pos, y_pos, tmp_string, Forecolor, Backgroundcolor, txt_size, rendering_mode);
        memset(&tmp_string, 0, sizeof (tmp_string));
        if (freq < 100)
            sprintf(tmp_string, " %u Khz ", freq); //OLED  slide_pos 0-255
        else
            sprintf(tmp_string, "%u Khz ", freq); //OLED  slide_pos 0-255
        y_pos = y_pos + txt_size;
        Forecolor = BLACK;
        OLED_RGB_ShowString(x_pos, y_pos, tmp_string, Forecolor, Backgroundcolor, txt_size, 0);
        //OLED_ShowString(x_pos, y_pos, tmp_string, txt_size, 1);


        if (PWM1_Freq_mode) {
            RGB_Draw_Circle(SSD1357_W - 5, y_pos + txt_size / 2, 3, RED);
            RGB_Draw_Circle(SSD1357_W - 5, y_pos + txt_size + txt_size / 2, 3, Backgroundcolor);
        } else {
            RGB_Draw_Circle(SSD1357_W - 5, y_pos + txt_size / 2, 3, Backgroundcolor);
            RGB_Draw_Circle(SSD1357_W - 5, y_pos + txt_size + txt_size / 2, 3, RED);
        }


    }
}

static void PWM1_freq_ADC_set(uint32_t request) {
    //SCCP1_PWM_DutyCycleSet(request);
    //MAX PWM1_Per_def/5  500Khz   1264
    //Min PWM1_Per_def*2  50Khz
    uint32_t PER_max = PWM1_Per_def * 2;
    uint32_t PER_min = PWM1_Per_def / 5;
    uint32_t Per_tmp = PER_min + (PER_max - PER_min)*(4096 - request) / 4096;
    //Per_tmp =(PER_max)*(4096 - request) / 4096;
    //uint32_t DC_tmp = 1000 * PG2DC / PG2PER;
    uint32_t DC_tmp = 1000 * PG1DC / PG1PER;
    DC_tmp = DC_tmp * Per_tmp / 1000;
    //request = request*PG1PER/4096;
    PWM_PeriodSet(PWM_GENERATOR_1, Per_tmp);
    PWM_DutyCycleSet(PWM_GENERATOR_1, DC_tmp);
    //PWM_DutyCycleSet(PWM_GENERATOR_1, request);
    PWM_SoftwareUpdateRequest(PWM_GENERATOR_1);
}

void PWM4_trig_mode_set(uint8_t mode) {

    if (PWM4_button_trig_mode == mode) {
        PWM4_single_trigger_mode(PWM4_single_TRG_cnt);
        printf(">>#:PG4 set to single Btn trigger mode!\r\n");
        PWM4_Enable();
    }
    if (PWM4_auto_single_trig_mode == mode) {
        PWM4_trig_mode = PWM4_auto_single_trig_mode; //no effect?
        printf(">>#:PG4 set to auto single trigger mode!\r\n");
        PWM4_Enable();
    }
    if (PWM4_def_mode == mode) {
        //PWM4_Retriggerable_mode(); //no effect?
        PWM4_Def_self_trigger_mode();
        printf(">>#:PG4 set to def re-trigger mode!\r\n");
        PWM4_Enable();
    }
}

//protect OLED from permant showing fixed patterns

void OLED_pixel_moving(void) {
    uint8_t scroll_dir = 1;
    stopScrolling();
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    startScrolling();
    __delay_ms(100);
    stopScrolling();
    scroll_dir = 0;
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    //setupScrolling(0, (OLED_Width / 2 - 1),  OLED_Height / 2 - 7, OLED_Height-1, SSD1327_SCROLL_6, 1-scroll_dir); //test ok
    startScrolling();
    __delay_ms(100);
    stopScrolling();

}

void OLED_pixel_shift_L(void) {
    uint8_t scroll_dir = 0;
    stopScrolling();
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    startScrolling();
    __delay_ms(60);
    stopScrolling();


}

void OLED_pixel_shift_R(void) {
    uint8_t scroll_dir = 1;
    stopScrolling();
    setupScrolling(0, OLED_Height - 1, 0, OLED_Width / 2 - 1, SSD1327_SCROLL_2, scroll_dir);
    startScrolling();
    __delay_ms(60);
    stopScrolling();


}

void sin_cos_accuracy_test(void) {

    float f = 0.0F;
    uint32_t calc_cnt = 0;
    printf("Single precision sin cos test:\r\n");
    for (f; f < M_PI * 2.0f; f += 0.2f) {
        printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
        calc_cnt++;
    }
    f = M_PI * 2.0f;
    calc_cnt++;
    printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
    printf("\r\n-sin cos test end, total calculations: %lu-\r\n", calc_cnt * 2);

    //return calc_cnt;
}

uint32_t sin_cos_accuracy_benchtest(float step_size) {

    float f = 0.0F;
    float res = 0;
    //uint32_t var_addr= 0;
    uint32_t calc_cnt = 0;
    if (step_size < 0)
        step_size = 0.2f;
    if (step_size > 1)
        step_size = 0.2f;

    TMR_1s_cnt = 0;
    tick_diff = 0;
    time_interval_us = 0;

    sys_tck = SCCP2_Timer_CounterGet();
    // LED7_RC10_SetHigh();
    //    bench_res =  sin(0.5);
    //    //bench_res =  sin(0.6); //610ns
    //    //bench_res +=  sin(f+0.2);    
    //    LED7_RC10_SetLow();
    //printf("Single precision sin cos test:\r\n");
    for (f; f < M_PI * 2.0f; f += step_size) {
        //printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
        //bench_res += sin(f);
        bench_res += sin(f); //:sin_cos math total 32 steps time cost: 42 us!
        //sin(f);
        //       asm("mov %0, W0" :: "r"(&f));
        //        asm("MOV.l W0,F0 "); //
        //        asm("sin.s F0,F1");
        calc_cnt++;
    }
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;
    //   LED7_RC10_SetLow();

    // f = M_PI * 2.0f;
    // calc_cnt++;
    // printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
    //printf("\r\n---Single precision sin cos test end, total calculations: %lu---\r\n", calc_cnt * 2);
    if (0 == calc_cnt)
        calc_cnt++;
    return calc_cnt;
}

uint32_t cos_accuracy_benchtest(float step_size) {

    float f = 0.0F;
    float res = 0;
    uint32_t calc_cnt = 0;
    if (step_size < 0)
        step_size = 0.2f;
    if (step_size > 1)
        step_size = 0.2f;

    //printf("Single precision sin cos test:\r\n");
    for (f; f < M_PI * 2.0f; f += step_size) {
        //printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
        bench_res += cos(f);
        calc_cnt++;
    }
    // f = M_PI * 2.0f;
    // calc_cnt++;
    // printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
    //printf("\r\n---Single precision sin cos test end, total calculations: %lu---\r\n", calc_cnt * 2);

    return calc_cnt;
}

uint32_t sin_cos_accuracy_benchtest_dummy(float step_size) {

    float f = 0.0F;
    float res = 0;
    uint32_t calc_cnt = 0;
    if (step_size < 0)
        step_size = 0.2f;
    if (step_size > 1)
        step_size = 0.2f;
    TMR_1s_cnt = 0;
    sys_tck = SCCP2_Timer_CounterGet();
    //printf("Single precision sin cos test:\r\n");
    for (f; f < M_PI * 2.0f; f += step_size) {
        //printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
        bench_res += f;
        calc_cnt++;
    }
    tick_diff = SCCP2_Timer_CounterGet() - sys_tck;

    // f = M_PI * 2.0f;
    // calc_cnt++;
    // printf("\r\nPhi=%f, sin(Phi)=%+12.8f, cos(Phi)=%+12.8f", f, (float) sin(f), (float) cos(f));
    //printf("\r\n---Single precision sin cos test end, total calculations: %lu---\r\n", calc_cnt * 2);

    return calc_cnt;
}


//  

void print_reset_reason(void) {
    //RCON_REG rcon;
    uint8_t SWR_flg = 0;
    //  RCON
    //rcon.value = RCON;  //u32 RCONSave

    //printf("RCON = 0x%08lX\n", RCON);
    printf("Reset source: ");

    // parse
    if (RCONbits.POR) {
        printf("POR ");
    }
    if (RCONbits.BOR) {
        printf("BOR ");
    }
    if (RCONbits.EXTR) {
        printf("MCLR ");
    }
    if (RCONbits.WDTO) {
        printf("WDTO ");
    }
    if (RCONbits.SWR) {
        printf("SWR ");
        SWR_flg = 1;
    }
    if (RCONbits.CM) {
        printf("Configuration Mismatch ");
    }
    if (RCONbits.IDLE) {
        printf("From IDLE ");
    }
    if (RCONbits.SLEEP) {
        printf("From Sleep ");
    }

    // VREG
    printf("\nVREG status: ");
    if (RCONbits.VREG1R) {
        printf("VREG1?? ");
    }
    if (RCONbits.VREG2R) {
        printf("VREG2?? ");
    }
    if (RCONbits.VREG3R) {
        printf("VREG3?? ");
    }

    printf("\n");
    if (SWR_flg) {
        printf("##>: Platform just performed software reset (S3)!\n");
        RCONbits.SWR = 0;
    }

    // Unknown reason
    if (!(RCONbits.POR || RCONbits.BOR || RCONbits.EXTR ||
            RCONbits.WDTO || RCONbits.SWR || RCONbits.CM)) {
        printf("Unknown\n");
    }

    RCON = 0;
}
//end of main
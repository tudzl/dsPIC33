/* 
 * File:   Mathtest_zell.h
 * Author: Administrator
 *
 * Created on April 1, 2025, 8:51 PM
 */

#ifndef MATHTEST_ZELL_H
#define	MATHTEST_ZELL_H

#ifdef	__cplusplus
extern "C" {
#endif

#define FtoQ31(X) \
   ((X < 0.0) ? (int)(0x80000000*(X) - 0.5) : (int)(0x7FFFFFFF*(X) + 0.5)) 

    unsigned long sqrt_u32(unsigned long num) {

        unsigned long res = 0;

        unsigned long _bit = 1l << 30; // The second-to-top bit is set: 1 << 30 for 32 bits



        // "bit" starts at the highest power of four <= the argument.

        while (_bit > num) {

            _bit >>= 2;

        }



        while (_bit != 0) {

            if (num >= (res + _bit)) {

                num -= (res + _bit);

                res = (res >> 1) + _bit;

            } else {

                res >>= 1;

            }

            _bit >>= 2;

        }

        return res;

    }



#ifdef	__cplusplus
}
#endif

#endif	/* MATHTEST_ZELL_H */

/*
 For example:

in Q15 format, divide the number by 2^15 - 1 (0x7FFF) . This would convert the number in the range [-1,1).

n = number/(0x7FFF)

Now convert n1 to Q15 format
int16 n_q15 = (n * 0x8000) + 0.5

Then find the sqrt using XMC_MATH_CORDIC_Q15_Sqrt function. 
r_q15 = XMC_MATH_CORDIC_Q15_Sqrt(n_q15)

Now convert the result back to float
r = r_q15 / 0x8000

Now multiply the result with sqrt(0x7FFF) 
result = r * sqrt(0x7FFF)
This is done because sqrt(number/max) = sqrt(num)/sqrt(max)
                                       =>sqrt(num) = sqrt(number/max) * sqrt(max)*/
//version 1.1  2024.11.10
//SSD1306 driver head file modified by zell
//work with dsPIC33A platform, Mplab X IDE 6.20 tested OK


#ifndef __OLED_SSD1309_H
#define __OLED_SSD1309_H

//#include "sys.h"
#include "../mcc_generated_files/system/pins.h"
#include "stdlib.h"	

//-----------------OLED pin mapping---------------- 

//#define OLED_SCL_Clr() GPIO_ResetBits(GPIOG,GPIO_Pin_12)//SCL
//#define OLED_SCL_Set() GPIO_SetBits(GPIOG,GPIO_Pin_12)

//need implemente
//#define OLED_SCL_Clr() OLED_CS_Low()//SCK
//#define OLED_SCL_Set() OLED_CS_Low()
//
//#define OLED_SDA_Clr() OLED_CS_Low()//SDO
//#define OLED_SDA_Set() OLED_CS_Low()

//#define OLED_SDA_Clr() GPIO_ResetBits(GPIOD,GPIO_Pin_5)//SDA
//#define OLED_SDA_Set() GPIO_SetBits(GPIOD,GPIO_Pin_5)
//SPI_DC_RB10_SetHigh()
#define OLED_RES_Clr()  SPI_RST_RB6_SetLow()//RES
#define OLED_RES_Set()  SPI_RST_RB6_SetHigh()

#define OLED_DC_Clr()  SPI_DC_RB10_SetLow()//DC
#define OLED_DC_Set()  SPI_DC_RB10_SetHigh()
 		     
#define OLED_CS_Clr()  SPI_CS_RB7_SetLow()//CS
#define OLED_CS_Set()  SPI_CS_RB7_SetHigh()

#define OLED_1309_Height 56
#define OLED_1309_Width 128

#define OLED_CMD  0	//
#define OLED_DATA 1	//

void OLED_ClearPoint(uint8_t x,uint8_t y);
void SSD1309_OLED_ColorTurn(uint8_t i);
void SSD1309_OLED_DisplayTurn(uint8_t i);
void OLED_WR_Byte(uint8_t dat,uint8_t mode);
void SSD1309_OLED_DisPlay_On(void);
void SSD1309_OLED_DisPlay_Off(void);
void SSD1309_OLED_Refresh(void);
void SSD1309_OLED_Clear(void);
void OLED_DrawPoint(uint8_t x,uint8_t y,uint8_t mode);
void OLED_DrawLine(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2,uint8_t mode);
void OLED_DrawCircle(uint8_t x,uint8_t y,uint8_t r);
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t size1,uint8_t mode);
void OLED_ShowChar6x8(uint8_t x,uint8_t y,uint8_t chr,uint8_t mode);
void OLED_ShowString(uint8_t x,uint8_t y,char *chr,uint8_t size1,uint8_t mode);
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t size1,uint8_t mode);
void OLED_ShowChinese(uint8_t x,uint8_t y,uint8_t num,uint8_t size1,uint8_t mode);
void OLED_ScrollDisplay(uint8_t num,uint8_t space,uint8_t mode);
void OLED_ShowPicture(uint8_t x,uint8_t y,uint8_t sizex,uint8_t sizey,uint8_t BMP[],uint8_t mode);
void SSD1309_OLED_ShowPicture(uint8_t x,uint8_t y,uint8_t sizex,uint8_t sizey,uint8_t BMP[],uint8_t mode); //added by Zell
void SSD1309_OLED_Init(void);

#endif


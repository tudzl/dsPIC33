// MIT License
//
// Copyright(c) 2021 Giovanni Bertazzoni <nottheworstdev@gmail.com>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files(the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions :
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.


#ifndef JDI_MIP_Display_h
#define JDI_MIP_Display_h
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>


#define JDI_DISPLAY_Width 72
#define JDI_DISPLAY_Height 144

#define HALF_WIDTH (JDI_DISPLAY_Width / 2)

#define COLOR_BLACK 0x00
#define COLOR_BLUE 0x02
#define COLOR_GREEN 0x04
#define COLOR_CYAN 0x06
#define COLOR_RED 0x08
#define COLOR_MAGENTA 0x0a
#define COLOR_YELLOW 0x0c
#define COLOR_WHITE 0x0e

#define CMD_NO_UPDATE 0x00
#define CMD_BLINKING_BLACK 0x10
#define CMD_BLINKING_INVERSION 0x14
#define CMD_BLINKING_WHITE 0x18
#define CMD_ALL_CLEAR 0x20
#define CMD_VCOM 0x40
#define CMD_UPDATE 0x90

uint16_t ttt =0;
uint16_t _background;


char _backBuffer[(JDI_DISPLAY_Width / 2) * JDI_DISPLAY_Height];
void JDI_Display_refresh();
void JDI_Display_refresh2();
void JDI_Display_displayOn();
void JDI_Display_displayOff();
void JDI_Display_clearScreen();
void JDI_Display_frontlightOn();
void JDI_Display_frontlightOff();
void JDI_Display_setBackgroundColor(uint16_t color);
void JDI_Display_drawBufferedPixel(int16_t x, int16_t y, uint16_t color);
void JDI_Display_sendLineCommand(char *line_cmd, int line);
void JDI_Display_drawPixel(int16_t x, int16_t y, uint16_t color);
void JDI_Display_drawBufferedPixel(int16_t x, int16_t y, uint16_t color);
bool JDI_Display_compareBuffersLine(int lineIndex);

#ifdef DIFF_LINE_UPDATE
char _dispBuffer[(JDI_DISPLAY_Width / 2) * JDI_DISPLAY_Height];
#endif


#endif
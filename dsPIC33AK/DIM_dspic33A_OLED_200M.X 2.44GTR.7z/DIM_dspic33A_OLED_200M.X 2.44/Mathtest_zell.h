/* 
 * File:   Mathtest_zell.h
 * Author: Administrator
 *
 * Created on April 1, 2025, 8:51 PM
 */

#ifndef MATHTEST_ZELL_H
#define	MATHTEST_ZELL_H

#ifdef	__cplusplus
extern "C" {
#endif

    unsigned long sqrt_u32(unsigned long num) {

        unsigned long res = 0;

        unsigned long _bit = 1l << 30; // The second-to-top bit is set: 1 << 30 for 32 bits



        // "bit" starts at the highest power of four <= the argument.

        while (_bit > num)
 {

            _bit >>= 2;

        }



        while (_bit != 0) {

            if (num >= (res + _bit))
 {

                num -= (res + _bit);

                res = (res >> 1) + _bit;

            }
            else
 {

                res >>= 1;

            }

            _bit >>= 2;

        }

        return res;

    }



#ifdef	__cplusplus
}
#endif

#endif	/* MATHTEST_ZELL_H */


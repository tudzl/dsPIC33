/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */

#include <stdio.h>
#include <string.h>
#include "stdbool.h"
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/touch/example/touch_example.h"
#include "mcc_generated_files/system/pins.h"

/*
    Main application
 */

#define Version_Nrd '1'
#define Version_Nrf1 '0' //2.1
#define Version_Nrf2 '0' //2.11
char version_buf[4];
uint32_t NUM_LEDS = 6;
uint32_t TMR1_100ms_INT_flg = 0;

uint32_t slider_pos_tmp = 0;

int main(void) {
    SYSTEM_Initialize();

    version_buf[0] = Version_Nrd;
    version_buf[1] = '.';
    version_buf[2] = Version_Nrf1;
    version_buf[3] = Version_Nrf2;

    printf("< dsPIC33AK512MPS512 DIM QT7 touch MPLAB 6.25 test demo!>\r\n");
    printf("-Version %s, Oct.2025 by Zell-\r\n", version_buf);
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("--FW code compiled with XC16 Version: %d\n", __XC16_VERSION__);


    IO_RB15_LED0_SetHigh();
    IO_RC6_LED1_SetHigh();
    IO_RB1_LED2_SetHigh();
    IO_RB13_LED3_SetHigh();
    IO_RB0_LED4_SetHigh();
    IO_RF10_LED5_SetHigh();


    while (1) {

        /* call touch process function */
        touch_process();

        if (measurement_done_touch == 1) {
            measurement_done_touch = 0;
            // process touch data
            touch_status_display();
        }
        if(TMR1_100ms_INT_flg){
            printf(">>:Slider pos: %u\r\n",slider_pos_tmp);
            TMR1_100ms_INT_flg=0;
        }


    }
}

void touch_status_display(void) {
    uint8_t key_status = 0u;
    uint8_t scroller_status = 0u;
    uint32_t scroller_position = 0u;
    uint32_t slider_LED_position = 0;
    key_status = get_sensor_state(0) & KEY_TOUCHED_MASK;
    if (0u != key_status) {
        //Touch detect
        IO_RC7_KLED1_SetLow();
    } else {
        //Touch No detect
        IO_RC7_KLED1_SetHigh();
    }

    key_status = get_sensor_state(1) & KEY_TOUCHED_MASK;
    if (0u != key_status) {
        //Touch detect
        IO_RB3_KLED2_SetLow();
    } else {
        //Touch No detect
        IO_RB3_KLED2_SetHigh();
    }

    key_status = get_sensor_state(2) & KEY_TOUCHED_MASK;
    if (0u != key_status) {
        //Touch detect
    } else {
        //Touch No detect
    }


    scroller_status = get_scroller_state(0);
    scroller_position = get_scroller_position(0);
    slider_pos_tmp = scroller_position;
    //Example: 8 bit scroller resolution. Modify as per requirement.
    //scroller_position = scroller_position  >> 5;
    //slider_LED_position = 255-scroller_position;
    scroller_position = (scroller_position * NUM_LEDS) / 255;
   // slider_LED_position = (scroller_position * NUM_LEDS) / 256;
    //LED_OFF
    if (0u != scroller_status) {
        switch (scroller_position) {
            case 0:
                //LED0_ON
                IO_RB15_LED0_SetLow();
                //IO_RB15_LED0_SetHigh();
                IO_RC6_LED1_SetHigh();
                IO_RB1_LED2_SetHigh();
                IO_RB13_LED3_SetHigh();
                IO_RB0_LED4_SetHigh();
                IO_RF10_LED5_SetHigh();
                break;
            case 1:
                //LED1_ON
                IO_RB15_LED0_SetLow();
                IO_RC6_LED1_SetLow();
                IO_RB1_LED2_SetHigh();
                IO_RB13_LED3_SetHigh();
                IO_RB0_LED4_SetHigh();
                IO_RF10_LED5_SetHigh();
                break;
            case 2:
                //LED2_ON
                IO_RB15_LED0_SetLow();
                IO_RC6_LED1_SetLow();
                IO_RB1_LED2_SetHigh();
                IO_RB13_LED3_SetHigh();
                IO_RB0_LED4_SetHigh();
                IO_RF10_LED5_SetHigh();
                break;
            case 3:
                //LED3_ON
                IO_RB15_LED0_SetLow();
                IO_RC6_LED1_SetLow();
                IO_RB1_LED2_SetLow();
                IO_RB13_LED3_SetHigh();
                IO_RB0_LED4_SetHigh();
                IO_RF10_LED5_SetHigh();
                break;
            case 4:
                //LED4_ON
                IO_RB15_LED0_SetLow();
                IO_RC6_LED1_SetLow();
                IO_RB1_LED2_SetLow();
                IO_RB13_LED3_SetLow();
                IO_RB0_LED4_SetLow();
                IO_RF10_LED5_SetHigh();
                break;
            case 5:
                //LED5_ON
                IO_RB15_LED0_SetLow();
                IO_RC6_LED1_SetLow();
                IO_RB1_LED2_SetLow();
                IO_RB13_LED3_SetLow();
                IO_RB0_LED4_SetLow();
                IO_RF10_LED5_SetLow();
                break;
            case 6:
                //LED6_ON
                printf(">>Case6\r\n");
                break;
            case 7:
                //LED7_ON
                break;
            default:
                //LED_OFF
                IO_RB15_LED0_SetHigh();
                IO_RC6_LED1_SetHigh();
                IO_RB1_LED2_SetHigh();
                IO_RB13_LED3_SetHigh();
                IO_RB0_LED4_SetHigh();
                IO_RF10_LED5_SetHigh();
                break;
        }
    }
    else{
                        IO_RB15_LED0_SetHigh();
                IO_RC6_LED1_SetHigh();
                IO_RB1_LED2_SetHigh();
                IO_RB13_LED3_SetHigh();
                IO_RB0_LED4_SetHigh();
                IO_RF10_LED5_SetHigh();
        
    }


}

//touch slider position value from 0 to 255, we have 6 led to display status, LED0 to LED5, generate a code to check the slider position and ON/OFF with LEDs
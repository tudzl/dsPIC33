/**
 * PINS Generated Driver Header File 
 * 
 * @file      pins.h
 *            
 * @defgroup  pinsdriver Pins Driver
 *            
 * @brief     The Pin Driver directs the operation and function of 
 *            the selected device pins using dsPIC MCUs.
 *
 * @skipline @version   PLIB Version 1.0.3
 *
 * @skipline  Device : dsPIC33AK512MPS512
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H
// Section: Includes
#include <xc.h>

// Section: Device Pin Macros

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB0 GPIO Pin which has a custom name of IO_RB0_LED4 to High
 * @pre      The RB0 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RB0_LED4_SetHigh()          (_LATB0 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB0 GPIO Pin which has a custom name of IO_RB0_LED4 to Low
 * @pre      The RB0 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB0_LED4_SetLow()           (_LATB0 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB0 GPIO Pin which has a custom name of IO_RB0_LED4
 * @pre      The RB0 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB0_LED4_Toggle()           (_LATB0 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB0 GPIO Pin which has a custom name of IO_RB0_LED4
 * @param    none
 * @return   none  
 */
#define IO_RB0_LED4_GetValue()         _RB0

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB0 GPIO Pin which has a custom name of IO_RB0_LED4 as Input
 * @param    none
 * @return   none  
 */
#define IO_RB0_LED4_SetDigitalInput()  (_TRISB0 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB0 GPIO Pin which has a custom name of IO_RB0_LED4 as Output
 * @param    none
 * @return   none  
 */
#define IO_RB0_LED4_SetDigitalOutput() (_TRISB0 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB1 GPIO Pin which has a custom name of IO_RB1_LED2 to High
 * @pre      The RB1 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RB1_LED2_SetHigh()          (_LATB1 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB1 GPIO Pin which has a custom name of IO_RB1_LED2 to Low
 * @pre      The RB1 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB1_LED2_SetLow()           (_LATB1 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB1 GPIO Pin which has a custom name of IO_RB1_LED2
 * @pre      The RB1 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB1_LED2_Toggle()           (_LATB1 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB1 GPIO Pin which has a custom name of IO_RB1_LED2
 * @param    none
 * @return   none  
 */
#define IO_RB1_LED2_GetValue()         _RB1

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB1 GPIO Pin which has a custom name of IO_RB1_LED2 as Input
 * @param    none
 * @return   none  
 */
#define IO_RB1_LED2_SetDigitalInput()  (_TRISB1 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB1 GPIO Pin which has a custom name of IO_RB1_LED2 as Output
 * @param    none
 * @return   none  
 */
#define IO_RB1_LED2_SetDigitalOutput() (_TRISB1 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB3 GPIO Pin which has a custom name of IO_RB3_KLED2 to High
 * @pre      The RB3 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RB3_KLED2_SetHigh()          (_LATB3 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB3 GPIO Pin which has a custom name of IO_RB3_KLED2 to Low
 * @pre      The RB3 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB3_KLED2_SetLow()           (_LATB3 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB3 GPIO Pin which has a custom name of IO_RB3_KLED2
 * @pre      The RB3 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB3_KLED2_Toggle()           (_LATB3 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB3 GPIO Pin which has a custom name of IO_RB3_KLED2
 * @param    none
 * @return   none  
 */
#define IO_RB3_KLED2_GetValue()         _RB3

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB3 GPIO Pin which has a custom name of IO_RB3_KLED2 as Input
 * @param    none
 * @return   none  
 */
#define IO_RB3_KLED2_SetDigitalInput()  (_TRISB3 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB3 GPIO Pin which has a custom name of IO_RB3_KLED2 as Output
 * @param    none
 * @return   none  
 */
#define IO_RB3_KLED2_SetDigitalOutput() (_TRISB3 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB13 GPIO Pin which has a custom name of IO_RB13_LED3 to High
 * @pre      The RB13 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RB13_LED3_SetHigh()          (_LATB13 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB13 GPIO Pin which has a custom name of IO_RB13_LED3 to Low
 * @pre      The RB13 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB13_LED3_SetLow()           (_LATB13 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB13 GPIO Pin which has a custom name of IO_RB13_LED3
 * @pre      The RB13 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB13_LED3_Toggle()           (_LATB13 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB13 GPIO Pin which has a custom name of IO_RB13_LED3
 * @param    none
 * @return   none  
 */
#define IO_RB13_LED3_GetValue()         _RB13

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB13 GPIO Pin which has a custom name of IO_RB13_LED3 as Input
 * @param    none
 * @return   none  
 */
#define IO_RB13_LED3_SetDigitalInput()  (_TRISB13 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB13 GPIO Pin which has a custom name of IO_RB13_LED3 as Output
 * @param    none
 * @return   none  
 */
#define IO_RB13_LED3_SetDigitalOutput() (_TRISB13 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB15 GPIO Pin which has a custom name of IO_RB15_LED0 to High
 * @pre      The RB15 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RB15_LED0_SetHigh()          (_LATB15 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RB15 GPIO Pin which has a custom name of IO_RB15_LED0 to Low
 * @pre      The RB15 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB15_LED0_SetLow()           (_LATB15 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RB15 GPIO Pin which has a custom name of IO_RB15_LED0
 * @pre      The RB15 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RB15_LED0_Toggle()           (_LATB15 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RB15 GPIO Pin which has a custom name of IO_RB15_LED0
 * @param    none
 * @return   none  
 */
#define IO_RB15_LED0_GetValue()         _RB15

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB15 GPIO Pin which has a custom name of IO_RB15_LED0 as Input
 * @param    none
 * @return   none  
 */
#define IO_RB15_LED0_SetDigitalInput()  (_TRISB15 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RB15 GPIO Pin which has a custom name of IO_RB15_LED0 as Output
 * @param    none
 * @return   none  
 */
#define IO_RB15_LED0_SetDigitalOutput() (_TRISB15 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC6 GPIO Pin which has a custom name of IO_RC6_LED1 to High
 * @pre      The RC6 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RC6_LED1_SetHigh()          (_LATC6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC6 GPIO Pin which has a custom name of IO_RC6_LED1 to Low
 * @pre      The RC6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RC6_LED1_SetLow()           (_LATC6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC6 GPIO Pin which has a custom name of IO_RC6_LED1
 * @pre      The RC6 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RC6_LED1_Toggle()           (_LATC6 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC6 GPIO Pin which has a custom name of IO_RC6_LED1
 * @param    none
 * @return   none  
 */
#define IO_RC6_LED1_GetValue()         _RC6

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC6 GPIO Pin which has a custom name of IO_RC6_LED1 as Input
 * @param    none
 * @return   none  
 */
#define IO_RC6_LED1_SetDigitalInput()  (_TRISC6 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC6 GPIO Pin which has a custom name of IO_RC6_LED1 as Output
 * @param    none
 * @return   none  
 */
#define IO_RC6_LED1_SetDigitalOutput() (_TRISC6 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC7 GPIO Pin which has a custom name of IO_RC7_KLED1 to High
 * @pre      The RC7 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RC7_KLED1_SetHigh()          (_LATC7 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RC7 GPIO Pin which has a custom name of IO_RC7_KLED1 to Low
 * @pre      The RC7 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RC7_KLED1_SetLow()           (_LATC7 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RC7 GPIO Pin which has a custom name of IO_RC7_KLED1
 * @pre      The RC7 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RC7_KLED1_Toggle()           (_LATC7 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RC7 GPIO Pin which has a custom name of IO_RC7_KLED1
 * @param    none
 * @return   none  
 */
#define IO_RC7_KLED1_GetValue()         _RC7

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC7 GPIO Pin which has a custom name of IO_RC7_KLED1 as Input
 * @param    none
 * @return   none  
 */
#define IO_RC7_KLED1_SetDigitalInput()  (_TRISC7 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RC7 GPIO Pin which has a custom name of IO_RC7_KLED1 as Output
 * @param    none
 * @return   none  
 */
#define IO_RC7_KLED1_SetDigitalOutput() (_TRISC7 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RF10 GPIO Pin which has a custom name of IO_RF10_LED5 to High
 * @pre      The RF10 must be set as Output Pin             
 * @param    none
 * @return   none  
 */
#define IO_RF10_LED5_SetHigh()          (_LATF10 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Sets the RF10 GPIO Pin which has a custom name of IO_RF10_LED5 to Low
 * @pre      The RF10 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RF10_LED5_SetLow()           (_LATF10 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Toggles the RF10 GPIO Pin which has a custom name of IO_RF10_LED5
 * @pre      The RF10 must be set as Output Pin
 * @param    none
 * @return   none  
 */
#define IO_RF10_LED5_Toggle()           (_LATF10 ^= 1)

/**
 * @ingroup  pinsdriver
 * @brief    Reads the value of the RF10 GPIO Pin which has a custom name of IO_RF10_LED5
 * @param    none
 * @return   none  
 */
#define IO_RF10_LED5_GetValue()         _RF10

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RF10 GPIO Pin which has a custom name of IO_RF10_LED5 as Input
 * @param    none
 * @return   none  
 */
#define IO_RF10_LED5_SetDigitalInput()  (_TRISF10 = 1)

/**
 * @ingroup  pinsdriver
 * @brief    Configures the RF10 GPIO Pin which has a custom name of IO_RF10_LED5 as Output
 * @param    none
 * @return   none  
 */
#define IO_RF10_LED5_SetDigitalOutput() (_TRISF10 = 0)

/**
 * @ingroup  pinsdriver
 * @brief    Initializes the PINS module
 * @param    none
 * @return   none  
 */
void PINS_Initialize(void);



#endif

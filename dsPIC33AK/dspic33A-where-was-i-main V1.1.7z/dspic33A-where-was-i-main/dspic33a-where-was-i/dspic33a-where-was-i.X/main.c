/* 
 * File: main.c
 * Author: mchp
 * Comments: Main function and ISR Routine definitions
 * Revision history: v1.0.0 
 */

#include <stdio.h>
#include <stdlib.h>
/*
;*****************************************************************************
;                                                                   		 *
;                       Software License Agreement                  		 *
;*****************************************************************************
;? [2024] Microchip Technology Inc. and its subsidiaries.					 *
;																			 *
;   Subject to your compliance with these terms, you may use Microchip 		 *
;   software and any derivatives exclusively with Microchip products. 		 *
;    You are responsible for complying with 3rd party license terms  		 *
;    applicable to your use of 3rd party software (including open source  	 *
;    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.?   *
;    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 	 *
;    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  		 *
;    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 		 *
;    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 			 *
;    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 		 *
;    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 		 *
;    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 		 *
;    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 		 *
;    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 		 *
;    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 		 *
;   THIS SOFTWARE.															 *
;*****************************************************************************/

//V1.01  added UART printf, 115200, added rd11 LED
#include "main.h"
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"

#define Version_Nrd '1'
#define Version_Nrf1 '1' //2._x
#define Version_Nrf2 '1' //2.x_

#define FCY 200000000UL

//#define FCY 100000000UL
#include <libpic30.h>


char version_buf[4];

uint8_t trap_idx = 0;

int main(int argc, char** argv) {
   // uartInit();//original
    SYSTEM_Initialize();

    version_buf[0] = Version_Nrd;
    version_buf[1] = '.';
    version_buf[2] = Version_Nrf1;
    version_buf[3] = Version_Nrf2;
    
    printf(RESET "\r\n\r\n\r\n\r\n ______________________________________________________________________________________________________________________________________________ \r\n");
    printf("< Where was I demo(trap) for dsPIC33A >\r\n");
    printf("-Version %s, 26.Mar.2025 by Zell-\r\n", version_buf);
    //printf("-Version 2.0B, 10.Nov.2024 by Zell-\r\n");
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("--FW code compiled with XC16 Version: %d\n", __XC16_VERSION__);
    printf("\r\n STARTING PCTRAP PROGRAM.....");

    for (int i = eBUS_ERROR_TRAP; i <= eMATH_ERROR_TRAP; i++) {
        triggerTraps(i);
         IO_RD11_LED_Toggle();
    }
    printf("\r\n\r\n END OF PROGRAM ");
    printf("\r\n  ______________________________________________________________________________________________________________________________________________ \r\n");
     __delay_ms(5000);
     printf(">>: Trap loops starts...\r\n");
    while (1){
         __delay_ms(500);
         trap_idx++;
         IO_RD11_LED_Toggle();
         if (trap_idx > eMATH_ERROR_TRAP){
             trap_idx = 0;
         }
         triggerTraps(trap_idx);
        
    };
    return (0);
}


/**
 * @brief triggerTraps : Function to trigger Traps.
 * @param trap - Trap type to trigger - 
 *               Available options - 
 *                  * eBUS_ERROR_TRAP
 *                  * eADDRESS_ERROR_TRAP
 *                  * eILLEGAL_OPCODE_ERROR_TRAP
 *                  * eSTACK_ERROR_TRAP
 *                  * eMATH_ERROR_TRAP
 */
void triggerTraps(TRAPS trap) {
    switch (trap) {
        case eBUS_ERROR_TRAP:
            triggerBusErrorTrap();
            break;

        case eADDRESS_ERROR_TRAP:
            triggerAddressErrorTrap();
            break;

        case eILLEGAL_OPCODE_ERROR_TRAP:
            triggerIllegalOpcodeError();
            break;

        case eSTACK_ERROR_TRAP:
            triggerStackErrorTrap();
            break;

        case eMATH_ERROR_TRAP:
            triggerMathErrorTrap();
            break;

        default:
            break;
    }
}




/****************************************************************************************************************/
/****************************************************** ISR ROUTINE *********************************************/
/****************************************************************************************************************/

void __attribute__((interrupt)) _AddressErrorTrap() {
    printf(RED"\r\n IN ADDRESS ERROR TRAP");
    printf(" :: PCTRAP = 0x%08lX"NORMAL, PCTRAP);
    INTCON1bits.ADDRERR = 0;
    PCTRAP = 0;
}

void __attribute__((interrupt)) _BusErrorTrap() {
    printf(RED"\r\n IN BUS ERROR TRAP");
    printf(" :: PCTRAP = 0x%08lX"NORMAL, PCTRAP);
    INTCON3 = 0;
    PCTRAP = 0;
}

void __attribute__((interrupt)) _IllegalInstructionTrap() {
    printf(RED"\r\n IN IOP ERROR TRAP");
    printf(" :: PCTRAP = 0x%08lX"NORMAL, PCTRAP);
    INTCON1bits.BADOPERR = 0;
    PCTRAP = 0;
}

void __attribute__((interrupt)) _StackErrorTrap() {
    printf(RED"\r\n IN STACK ERROR TRAP");
    printf(" :: PCTRAP = 0x%08lX"NORMAL, PCTRAP);
    INTCON1bits.STKERR = 0;
    PCTRAP = 0;
}

void __attribute__((interrupt)) _MathErrorTrap() {
    printf(RED"\r\n IN MATH ERROR TRAP");
    printf(" :: PCTRAP = 0x%08lX"NORMAL, PCTRAP);
    INTCON4 = 0;
    PCTRAP = 0;
}

void __attribute__((interrupt)) _DefaultInterrupt() {
    printf(RED"\r\n IN DEFAULT INTERRUPT");
    printf(" :: INTTREG = 0x%08lX", INTTREG);
    printf(" :: PCTRAP  = 0x%08lX"NORMAL, PCTRAP);
    while (1);
}

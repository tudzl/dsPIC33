/*
;*****************************************************************************
;                                                                   		 *
;                       Software License Agreement                  		 *
;*****************************************************************************
;� [2024] Microchip Technology Inc. and its subsidiaries.					 *
;																			 *
;   Subject to your compliance with these terms, you may use Microchip 		 *
;   software and any derivatives exclusively with Microchip products. 		 *
;    You are responsible for complying with 3rd party license terms  		 *
;    applicable to your use of 3rd party software (including open source  	 *
;    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.?   *
;    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 	 *
;    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  		 *
;    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 		 *
;    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 			 *
;    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 		 *
;    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 		 *
;    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 		 *
;    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 		 *
;    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 		 *
;    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 		 *
;   THIS SOFTWARE.															 *
;*****************************************************************************/


/*
 * @File:   traps.c
 * @Author: mchp
 * @comments: File with functions to trigger -
 *                              * Bus Error, 
 *                              * Address Error, 
 *                              * Stack Error,
 *                              * Math Error,
 *                              * Illegal opcode error traps.
 */


#include "main.h"


/**
 * @brief triggerAddressErrorTrap - Function to Trigger Address Error Trap
 * @param None
 * @return None
 */
void __attribute__((address(0x805100))) triggerAddressErrorTrap() {
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
    printf("\r\n TRIGGERING ADDRESS ERROR FROM A FUNCTION WITH FUNCTION START ADDRESS @ 0x%X..... ", (unsigned int) triggerAddressErrorTrap);
    printf("\r\n ERROR TYPE :: MISALIGNED LONG WORD READ");

    asm volatile("PUSH.l W5");
    asm volatile("PUSH.l W4");
    asm volatile("MOV.l #0x300A, W5"); // Misaligned long word read
    asm volatile("MOV.l [W5], W4");
    asm volatile("POP.l W5");
    asm volatile("POP.l W4");
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
}


/**
 * @brief triggerStackErrorTrap - Function to Trigger Stack Error Trap
 * @param None
 * @return None
 */
void __attribute__((address(0x805200))) triggerStackErrorTrap() {
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
    printf("\r\n TRIGGERING STACK ERROR TRAP FROM A FUNCTION WITH FUNCTION START ADDRESS @ 0x%X..... ", (unsigned int) triggerStackErrorTrap);
    printf("\r\n ERROR TYPE :: MISALIGNED PUSH");
    
    uint32_t l_W15 = mGET_W15_VAL();
    mSET_W15_VAL(l_W15 | 1);
    
    asm volatile("PUSH.l w0");      // Misaligned PUSH
    mWAIT_50_NOP;
    asm volatile ("POP.l W0");
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
}

/**
 * @brief triggerBusErrorTrap - Function to Trigger Bus Error Trap
 * @param None
 * @return None
 */
void __attribute__((address(0x805300))) triggerBusErrorTrap() {
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
    printf("\r\n TRIGGERING BUS ERROR FROM A FUNCTION WITH FUNCTION START ADDRESS @ 0x%X..... ", (unsigned int) triggerBusErrorTrap);
    printf("\r\n ERROR TYPE :: RESERVED MEMORY ACCESS");
    
    uint32_t* ptr = (uint32_t*) 0x7F8000;
    *ptr = 1000;
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
}

/**
 * @brief triggerMathErrorTrap - Function to Trigger Math Error Trap
 * @param None
 * @return None
 */
void __attribute__((address(0x805400))) triggerMathErrorTrap() {
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
    printf("\r\n TRIGGERING MATH ERROR FROM A FUNCTION WITH FUNCTION START ADDRESS @ 0x%X..... ", (unsigned int) triggerMathErrorTrap);
    printf("\r\n ERROR TYPE :: DIVIDE_BY_ZERO");
    
    uint32_t op_1 = 5, op_2 = 0;
    op_1 = op_1 / op_2;
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
}



/*Illegal instruction with a return*/
uint32_t __attribute__((space(prog), address(0x80A000))) IOP[] = {0x88C20002, 0x7201};
/**
 * @brief triggerIllegalOpcodeError - Function to Trigger Illegal Opcode Error Trap
 * @param None
 * @return None
 */
void __attribute__((address(0x805500))) triggerIllegalOpcodeError() {
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
    
    printf("\r\n TRIGGERING IOP ERROR FROM A FUNCTION WITH FUNCTION START ADDRESS @ 0x%X..... ", (unsigned int) IOP);
    printf("\r\n ERROR TYPE :: ILLEGAL OPCODE EXECUTION");
    
    asm volatile("CALL 0x80A000");
    printf(CYAN"\r\n\r\n ************************************************* \r\n"NORMAL);
}



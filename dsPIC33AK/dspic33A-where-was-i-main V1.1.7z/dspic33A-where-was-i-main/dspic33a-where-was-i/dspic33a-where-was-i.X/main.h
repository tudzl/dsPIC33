/*
;*****************************************************************************
;                                                                   		 *
;                       Software License Agreement                  		 *
;*****************************************************************************
;� [2024] Microchip Technology Inc. and its subsidiaries.					 *
;																			 *
;   Subject to your compliance with these terms, you may use Microchip 		 *
;   software and any derivatives exclusively with Microchip products. 		 *
;    You are responsible for complying with 3rd party license terms  		 *
;    applicable to your use of 3rd party software (including open source  	 *
;    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.?   *
;    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 	 *
;    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  		 *
;    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 		 *
;    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 			 *
;    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 		 *
;    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 		 *
;    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 		 *
;    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 		 *
;    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 		 *
;    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 		 *
;   THIS SOFTWARE.															 *
;*****************************************************************************/



/* 
 * File: main.h
 * Author: mchp
 * Comments: Header file with function definitions and mac
 * Revision history: v1.0.0 
 */


#ifndef MAIN_H
#define	MAIN_H

#include <xc.h>
#include <stdio.h>


#define mUART_BAUD             ((unsigned long)115200UL) // UART baud rate
#define mFCY                   ((unsigned long)8000000) // FCY frequency in Hz

#define mWAIT_50_NOP    {asm volatile("REPEAT #50");asm volatile("NOP");}

#define RESET   "\x0F\x1B[2J\x1B[1;1f\x1B[0m\033[0m"    // Clears the screen, moves the cursor to the top left, and clears any active formatting modes
#define NORMAL  "\x0F\x1B[0m\033[0m"                    // Cancels any active formatting modes and returns to a default font face
#define RED     "\033[0;31m"                            // Selects red font face
#define GREEN   "\033[1;32m"                            // Selects green font face
#define CYAN    "\033[1;36m"                            // Selects cyan font face
#define PURPLE  "\033[1;35m"                            // Selects purple font face


#define mGET_W15_VAL() ({uint32_t ret; asm volatile("MOV.l W15, %0":"=x"(ret):/*NO INPUTS*/:/*NO CLOBBING*/);ret;})
#define mSET_W15_VAL(value) ({asm ("MOV.l %0, W15" :/*No Outputs*/ :  "x" (value) : /* nothing clobbered */);})


typedef enum TRAPS_T {
    eBUS_ERROR_TRAP,
    eADDRESS_ERROR_TRAP,
    eILLEGAL_OPCODE_ERROR_TRAP,
    eSTACK_ERROR_TRAP,
    eMATH_ERROR_TRAP,
} TRAPS;



/*****************************************************************************/
/********************** Function Declarations ********************************/
/*****************************************************************************/
void triggerMathErrorTrap();
void triggerAddressErrorTrap();
void triggerStackErrorTrap();
void triggerBusErrorTrap();
void triggerIllegalOpcodeError();
void triggerTraps(TRAPS trap);
void uartInit();

#endif	/* XC_HEADER_TEMPLATE_H */


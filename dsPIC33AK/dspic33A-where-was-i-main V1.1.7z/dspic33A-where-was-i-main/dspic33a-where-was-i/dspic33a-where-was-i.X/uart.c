/*
;*****************************************************************************
;                                                                   		 *
;                       Software License Agreement                  		 *
;*****************************************************************************
;� [2024] Microchip Technology Inc. and its subsidiaries.					 *
;																			 *
;   Subject to your compliance with these terms, you may use Microchip 		 *
;   software and any derivatives exclusively with Microchip products. 		 *
;    You are responsible for complying with 3rd party license terms  		 *
;    applicable to your use of 3rd party software (including open source  	 *
;    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.?   *
;    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 	 *
;    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  		 *
;    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 		 *
;    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 			 *
;    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 		 *
;    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 		 *
;    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 		 *
;    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 		 *
;    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 		 *
;    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 		 *
;   THIS SOFTWARE.															 *
;*****************************************************************************/


/* 
 * @File: uart.c
 * @Author: mchp
 * @Comments: File with UART initialization functions for printf.
 * 		      UART initialized on RA1
 * @Revision history: v1.0.0 
 */


#include "main.h"



void uartInit()
{
    unsigned long brg;

    ANSELD = 0x0;
    RPINR9bits.U1RXR = 0x0034UL; //RD3->UART1:U1RX;
    RPOR12bits.RP50R = 0x0009UL;  //RD1->UART1:U1TX;

    brg = (((mFCY / 8 + mUART_BAUD / 2) / mUART_BAUD) - 1);
    U1BRG = (unsigned short) brg;

    U1CON = 0;
    U1STAT = 0;
    U1CONbits.BRGS = 1;
    U1CONbits.TXEN = 1;
    U1CONbits.RXEN = 1;
    U1CONbits.ON = 1;  
}

unsigned char UARTIsCharReady()
{
	return (U1STATbits.RXBE == 0);	
}

void UARTWrite(unsigned char txData){
    while(U1STATbits.TXBE == 0);
    U1TXB = (unsigned long)txData;
}

unsigned char UARTRead(){
	while(U1STATbits.RXBE != 0);	
    return U1RXB;
}

int __attribute__((__section__(".libc.write"))) write(int handle, void *buffer, unsigned int len){
    unsigned char *pData = (unsigned char*)buffer;
    unsigned short count;
    for(count=0; count<len; count++)
    {
        UARTWrite(*pData++);
    }
    
    return count;
}



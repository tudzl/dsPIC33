![image](images/microchip.jpg)

## dsPIC33A Where-was-I

## Summary

This code example demonstrates how to identify the source of a trap. There are a couple of approaches to achieve this:

1. Using the PCTRAP register, which provides the address that caused the trap.
2. Analyzing the stack.

If the PCTRAP register is available on the device, it is recommended to use it to find the address of the source code that caused the trap.


## Related Documentation

- dsPIC33AK128MC106 microcontroller (https://www.microchip.com/dsPIC33AK128MC106)

## Software Used

- MPLAB® X IDE v6.20 or newer (https://www.microchip.com/mplabx)
- MPLAB® XC-DSC 3.20 or newer (https://www.microchip.com/xcdsc)
- Any of the serial terminal application. Example: Tera Term (https://ttssh2.osdn.jp/index.html.en)


## Hardware Used

- dsPIC33AK Curiosity Development Board (https://www.microchip.com/ev74h48a)
- Micro USB Cable

## Operation

Open any serial terminal application and set the configuration as shown in the figure

![image](images/serialTerminalSetup.png)

Program the device and you will see the output as follows
![image](images/nonMCCTrap.png)



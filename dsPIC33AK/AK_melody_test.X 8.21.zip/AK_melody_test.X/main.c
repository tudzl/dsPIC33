/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/timer/delay.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "stdio.h"
#include <math.h>
#include "Motorlib/motor_control.h"

#include <stdint.h>
/*
    Main application
 */

//global var
uint32_t tmr_period = 0xC34FUL;

uint16_t tmr1_INT_cnt = 0;
uint32_t time_elps = 0;
uint32_t tmr_10ns_cnt = 0;
uint8_t Math_bench_mode = 3;

void TMR1_TimeoutCallback(void) {
    tmr1_INT_cnt++;

}
void Math_benchtest(uint8_t condition);

int main(void) {
    SYSTEM_Initialize();
    IO_RB5_LED_RED_Toggle();
    printf("< dsPIC33AK melody test with Math benchtest demo>\r\n");
    printf("Version 1.2, by Zell \r\n");
    printf("FW code compiled: %s %s\n", __DATE__, __TIME__);

    TMR1_PeriodSet(tmr_period);
    printf("#>:set timer 1 period to %u @ %d us!\r\n", tmr_period, tmr_period / 100);
    if (1<Math_bench_mode){
          printf(">:Math bench loop running!\r\n");
    }


    while (1) {
        printf(">:loop running!\r\n");
        //printf("FW code compiled: %s %s\n", __DATE__, __TIME__);
        Math_benchtest(Math_bench_mode);
        //__delay_ms(500);
        DELAY_milliseconds(500);
        IO_RB5_LED_RED_Toggle();
        IO_PIM_LED_Toggle();
    }
}

void Math_benchtest(uint8_t condition) {

    //Math_bench_mode = condition;
    uint32_t tmr_10ns_cnt = TMR1_CounterGet();
    uint32_t tmr_10ns_cnt_post = 0;
    uint32_t tick_diff = 0;
    if (condition) {
        printf("#########Math BenchTest starts!#########\r\n");
        Math_bench_mode = 1;
        //TMR1_Period16BitSet(0xffff);
        //TMR1_Start();
        TMR1_CounterSet(0);
        TMR1_Start();
        tmr1_INT_cnt = 0;

        IO_PIM_LED_Toggle();
        //TMR1_CounterGet();

        IO_PIM_LED_Toggle();
        tmr_10ns_cnt = TMR1_CounterGet();
        DSP_Algorithm_Test0();
        TMR1_Stop();
        tick_diff = TMR1_CounterGet() - tmr_10ns_cnt;
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;
        IO_PIM_LED_Toggle();
        printf("Math Bench Ref Test 0 time elapsed: %lu us, raw:%lu\r\n", tick_diff / 100, tick_diff); //12.4ms
        IO_PIM_LED_Toggle();
        IO_PIM_LED_Toggle();
        TMR1_Start();
        tmr_10ns_cnt = TMR1_CounterGet();

        DSP_Algorithm_Test1Light();
        tick_diff = TMR1_CounterGet() - tmr_10ns_cnt;
        IO_PIM_LED_Toggle();
        IO_PIM_LED_Toggle();
        printf("Math BenchTest 1 Light time elapsed: %lu us, raw:%lu\r\n", tick_diff / 100, tick_diff);
        IO_PIM_LED_Toggle();
        tmr_10ns_cnt = TMR1_CounterGet();

        DSP_Algorithm_Test1();
        tick_diff = TMR1_CounterGet() - tmr_10ns_cnt;
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;
        printf("Math BenchTest 1 time elapsed: %lu us, raw:%lu\r\n", tick_diff / 100, tick_diff);

        tmr_10ns_cnt = TMR1_CounterGet();

        DSP_Algorithm_Test2Light();
        tick_diff = TMR1_CounterGet() - tmr_10ns_cnt;
        printf("Math BenchTest 2 Light time elapsed: %lu us, raw:%lu\r\n", tick_diff / 100, tick_diff);

          TMR1_CounterSet(0);
        tmr1_INT_cnt = 0;

        tmr_10ns_cnt = TMR1_CounterGet();

        DSP_Algorithm_Test2();
        tick_diff = TMR1_CounterGet() - tmr_10ns_cnt;
        printf("Math BenchTest 2 time elapsed: %lu us, raw:%lu\r\n", tick_diff / 100, tick_diff);


    }
    if (condition>=1) { //issues for ">", >= is OK!!!
        //printf("!!Additional Math BenchTest starts!#########\r\n");
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;
        TMR1_CounterSet(0);
        tmr_10ns_cnt = TMR1_CounterGet();
        DSP_Algorithm_Test3Light();
        tmr_10ns_cnt_post = TMR1_CounterGet();
        TMR1_Stop();
        //tick_diff = (uint32_t)tmr1_INT_cnt*0xFFFF+tmr_10ns_cnt_post - tmr_10ns_cnt;

        tick_diff = tmr_10ns_cnt_post - tmr_10ns_cnt;
        time_elps = tick_diff / 100;

        printf("Math BenchTest 3 Light time: %lu us, raw:%lu\r\n", tick_diff / 100, tick_diff);
        //printf("Math BenchTest 3 Light time elapsed: %lu us, diff raw:%lu\r\n", time_elps, tick_diff);
        printf("tmr1_INT_cnt: %u \r\n", tmr1_INT_cnt);
          TMR1_CounterSet(0);
        TMR1_Start();
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;
        tmr_10ns_cnt = TMR1_CounterGet();

        DSP_Algorithm_Test3_sqrt();
        tmr_10ns_cnt_post = TMR1_CounterGet();
        TMR1_Stop();
        tick_diff = tmr_10ns_cnt_post - tmr_10ns_cnt;
        //tick_diff = (uint32_t)tmr1_INT_cnt*0xFFFF+tmr_10ns_cnt_post - tmr_10ns_cnt;
        time_elps = tick_diff / 100; //to us


        printf("Math BenchTest 3 sqrt time elapsed: %lu us, diff raw:%lu\r\n", time_elps, tick_diff);
        printf("tmr1_INT_cnt: %u \r\n", tmr1_INT_cnt);
        TMR1_Start();
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;
        tmr_10ns_cnt = TMR1_CounterGet();


        DSP_Algorithm_Test3();
        tmr_10ns_cnt_post = TMR1_CounterGet();
        TMR1_Stop();
        TMR1_CounterSet(0);
        //tick_diff = (uint32_t)tmr1_INT_cnt*0xFFFF+tmr_10ns_cnt_post - tmr_10ns_cnt;
        tick_diff = tmr1_INT_cnt*tmr_period+ tmr_10ns_cnt_post - tmr_10ns_cnt;
        time_elps = tick_diff / 100;

        printf("Math BenchTest 3 time elapsed: %lu us, diff raw:%lu\r\n", time_elps, tick_diff);
        printf("tmr1_INT_cnt: %u \r\n", tmr1_INT_cnt);
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;

        //DSP_Algorithm_Test3_OPT
        TMR1_Start();
       
        IO_PIM_LED_Toggle();
        tmr_10ns_cnt = TMR1_CounterGet();


        DSP_Algorithm_Test3_OPT();
        tmr_10ns_cnt_post = TMR1_CounterGet();
        TMR1_Stop();
        //tick_diff = (uint32_t)tmr1_INT_cnt*0xFFFF+tmr_10ns_cnt_post - tmr_10ns_cnt;
        tick_diff = TMR1_CounterGet() - tmr_10ns_cnt;
        time_elps = tick_diff / 100;
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;
        IO_PIM_LED_Toggle();
        IO_PIM_LED_Toggle();
        tmr1_INT_cnt = 0;
        IO_PIM_LED_Toggle();

        printf("Math BenchTest 3 Optimized time elapsed: %lu us, diff raw:%lu\r\n", time_elps, tick_diff);
        printf("tmr1_INT_cnt: %u \r\n", tmr1_INT_cnt);

    }

}

uint16_t Uint16_Num = 0;
//#pragma DATA_SECTION(Int32_Num,"CLADataLS1")
int32_t Int32_Num = 0;
//#pragma DATA_SECTION(Uint16_Test,"CLADataLS1")
uint16_t Uint16_Test[4] = {0, 0, 0, 0};
//#pragma DATA_SECTION(Int32_Test,"CLADataLS1")
int32_t Int32_Test[4] = {0, 0, 0, 0};
//#pragma DATA_SECTION(float_Test,"CLADataLS1")
float float_Test[7] = {0, 0, 0, 0, 0, 0, 0};
void DSP_Algorithm_Test0(void);
void DSP_Algorithm_Test1(void);
void DSP_Algorithm_Test1Light(void);
void DSP_Algorithm_Test2(void);
void DSP_Algorithm_Test2Light(void);
void DSP_Algorithm_Test3(void);
void DSP_Algorithm_Test3_OPT(void);
void DSP_Algorithm_Test3_sqrt(void);
void DSP_Algorithm_Test3Light(void);
void DSP_Algorithm_Test4_sincos(void);


//1.CPU bench

void DSP_Algorithm_Test1Light(void) {
    // GpioDataRegs.GPASET.bit.GPIO20 = 1;
    //unsigned 16bit test
    for (Uint16_Num = 0; Uint16_Num < 100; Uint16_Num++) {
        Uint16_Test[0] = Uint16_Num;
        // Uint16_Test[1] = Uint16_Num + 1;
        //Uint16_Test[2] = Uint16_Test[0] * Uint16_Test[1];
        // Uint16_Test[3] = Uint16_Test[0] / Uint16_Test[1];
    }
}

void DSP_Algorithm_Test1(void) {
    // GpioDataRegs.GPASET.bit.GPIO20 = 1;
    //unsigned 16bit test
    for (Uint16_Num = 0; Uint16_Num < 100; Uint16_Num++) {
        Uint16_Test[0] = Uint16_Num;
        Uint16_Test[1] = Uint16_Num + 1;
        Uint16_Test[2] = Uint16_Test[0] * Uint16_Test[1];
        Uint16_Test[3] = Uint16_Test[0] / Uint16_Test[1];
    }
}

void DSP_Algorithm_Test2Light(void) {

    //signed 32bit test
    for (Uint16_Num = 0; Uint16_Num < 50; Uint16_Num++) {
        Int32_Num = (int32_t) Uint16_Num;
    }
}

void DSP_Algorithm_Test2(void) {

    //signed 32bit test
    for (Uint16_Num = 0; Uint16_Num < 50; Uint16_Num++) {
        Int32_Num = (int32_t) Uint16_Num;
        Int32_Test[0] = Int32_Num;
        Int32_Test[1] = -Int32_Num - 1;
        Int32_Test[2] = Int32_Test[0] * Int32_Test[1];
        Int32_Test[3] = Int32_Test[0] / Int32_Test[1];
    }
}

void DSP_Algorithm_Test3Light(void) {
    //float bench basic
    for (Uint16_Num = 0; Uint16_Num < 80; Uint16_Num++) {
        float_Test[0] = (float) Uint16_Num;
        //float_Test[1] = (float_Test[0] - 0.1f) * (float_Test[0] + 0.1f);
        //float_Test[2] = sqrt(float_Test[1]);
        //float_Test[3] = __builtin_divf(Uint16_Test[0], Uint16_Test[1]);
        //float_Test[3] = float_Test[2]/float_Test[0];
        //float_Test[3] = __divf32(float_Test[2], float_Test[0]); //float __divf32( float num , float denom);	DIVF32dst, num, denom	Return num divided by denom using the TMU hardware instruction for floating point division.
        //float_Test[4] = atanf(float_Test[3]);
        //float_Test[4] = __atanpuf32(float_Test[3]);//Return the principal value of the arc tangent of src, which is provided as a per unit value.
        //float_Test[5] = sinf(float_Test[4]);
        //float_Test[5] = __sinpuf32(float_Test[4]);
        //float_Test[6] = cosf(float_Test[4]);
        //float_Test[6] = __cospuf32(float_Test[4]);
    }
}

void DSP_Algorithm_Test3_sqrt(void) {
    //float bench basic+sqrt+divide
    for (Uint16_Num = 0; Uint16_Num < 80; Uint16_Num++) {
        float_Test[0] = (float) Uint16_Num;
        float_Test[1] = (float_Test[0] - 0.1f) * (float_Test[0] + 0.1f);
        float_Test[2] = sqrt(float_Test[1]);
        //float_Test[3] = __builtin_divf(float_Test[2], float_Test[0]);
        float_Test[3] = float_Test[2] / float_Test[0];
        //float_Test[3] = __divf32(float_Test[2], float_Test[0]); //float __divf32( float num , float denom);	DIVF32dst, num, denom	Return num divided by denom using the TMU hardware instruction for floating point division.
        //float_Test[4] = atan(float_Test[3]);
        //float_Test[4] = __atanpuf32(float_Test[3]);//Return the principal value of the arc tangent of src, which is provided as a per unit value.
        //float_Test[5] = sin(float_Test[4]);
        //float_Test[5] = __sinpuf32(float_Test[4]);
        //float_Test[6] = cos(float_Test[4]);
        //float_Test[6] = __cospuf32(float_Test[4]);
    }
}

void DSP_Algorithm_Test3_OPT(void) {

    //float bench full-set with sin cos tan, optimized
    MC_SINCOS_T mcSinCos;
    uint16_t temp;
    int16_t angle;
    for (Uint16_Num = 0; Uint16_Num < 80; Uint16_Num++) {
        float_Test[0] = (float) Uint16_Num;
        float_Test[1] = (float_Test[0] - 0.1f) * (float_Test[0] + 0.1f);
        float_Test[2] = sqrt(float_Test[1]);
        //float_Test[3] = __builtin_divf(float_Test[2], float_Test[0]);
        //float_Test[3] = float_Test[2]/float_Test[0];
        float_Test[3] = __builtin_divf(Uint16_Test[1], Uint16_Test[0]);
        //float_Test[3] = __divf32(float_Test[2], float_Test[0]); //float __divf32( float num , float denom);	DIVF32dst, num, denom	Return num divided by denom using the TMU hardware instruction for floating point division.
        float_Test[4] = atan(float_Test[3]);
        angle = (uint16_t) float_Test[4];
        //temp = MC_CalculateSineCosine_Assembly_Ram(angle, &mcSinCos);  //issues? 
        //float_Test[4] = __atanpuf32(float_Test[3]);//Return the principal value of the arc tangent of src, which is provided as a per unit value.
        //float_Test[5] = sin(float_Test[4]);
        //float_Test[5] = __sinpuf32(float_Test[4]);
        //float_Test[6] = cos(float_Test[4]);
        //float_Test[6] = __cospuf32(float_Test[4]);
    }
}

void DSP_Algorithm_Test3(void) {
    //float bench full-set with sin cos tan
    for (Uint16_Num = 0; Uint16_Num < 80; Uint16_Num++) {
        float_Test[0] = (float) Uint16_Num;
        float_Test[1] = (float_Test[0] - 0.1f) * (float_Test[0] + 0.1f);
        float_Test[2] = sqrt(float_Test[1]);
        //__builtin_divf .  Uint16_Test
        //float_Test[3] = __builtin_divf(Uint16_Test[1], Uint16_Test[0]);
        //float_Test[3] = __builtin_divf((uint16_t) float_Test[1], (uint16_t) float_Test[1]);
        float_Test[3] = float_Test[2] / float_Test[0];
        //float_Test[3] = __divf32(float_Test[2], float_Test[0]); //float __divf32( float num , float denom);	DIVF32dst, num, denom	Return num divided by denom using the TMU hardware instruction for floating point division.
        float_Test[4] = atan(float_Test[3]);
        //float_Test[4] = __atanpuf32(float_Test[3]);//Return the principal value of the arc tangent of src, which is provided as a per unit value.
        float_Test[5] = sin(float_Test[4]);
        //float_Test[5] = __sinpuf32(float_Test[4]);
        float_Test[6] = cos(float_Test[4]);
        //float_Test[6] = __cospuf32(float_Test[4]);
    }
}

void DSP_Algorithm_Test4_sincos(void) {
    //test for leo
    for (uint16_t loop_cnt = 0; loop_cnt < 100; loop_cnt++) {

        float_Test[5] = sin(float_Test[4]);
        float_Test[6] = cos(float_Test[4]);
    }

}

void DSP_Algorithm_Test0(void) {
    // GpioDataRegs.GPASET.bit.GPIO20 = 1;
    //???16bit ???
    for (Uint16_Num = 0; Uint16_Num < 100; Uint16_Num++) {
        Nop();
        //__builtin_nop()
    }
}
/*
void DSP_Algorithm_Test3(void)
{
    //?????????????????
for(Uint16_Num = 0;Uint16_Num < 80;Uint16_Num++)                      {
    float_Test[0] = (float)Uint16_Num;
    float_Test[1] = (float_Test[0] - 0.1f) * (float_Test[0] + 0.1f);
    float_Test[2] = __sqrt(float_Test[1]);
    float_Test[3] = __divf32(float_Test[2], float_Test[0]);
    float_Test[4] = __atanpuf32(float_Test[3]);
    float_Test[5] = __sinpuf32(float_Test[4]);
    float_Test[6] = __cospuf32(float_Test[4]);
}

   

}
 */


/*
 
Math Bench Ref Test 0 time elapsed: 3 us, raw:370
Math BenchTest 1 Light time elapsed: 4 us, raw:469
Math BenchTest 1 time elapsed: 21 us, raw:2119
 
 
 */
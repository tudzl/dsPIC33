# Microchip Motor Control Library v0.20

This version of the Microchip Motor Control Library
supports the following architectures:

- dsPIC33E
- dsPIC33F
- dsPIC33C

NOTE: this is an interim release of the Motor Control Library,
      which contains neither the assembly source code files (.s)
	  nor the documentation. No changes have been made to
	  any assembly source code files that existed in v0.10 ---
	  see the 0.10 release for source and documentation.

## Content

The following functions are included:

- MC_CalculateSineCosine_Assembly_Ram
- MC_CalculateSpaceVector_Assembly
- MC_CalculateSpaceVectorPhaseShifted_Assembly
- MC_ControllerPIUpdate_Assembly
- MC_TransformClarke_Assembly
- MC_TransformClarkeInverse_Assembly
- MC_TransformClarkeInverseNoAccum_Assembly
- MC_TransformClarkeInverseSwappedInput_Assembly
- MC_TransformPark_Assembly
- MC_TransformParkInverse_Assembly

- MC_CalculateSineCosine_InlineC_Ram
- MC_CalculateSpaceVectorPhaseShifted_InlineC
- MC_CalculateZeroSequenceModulation_InlineC
- MC_ControllerPIUpdate_InlineC
- MC_TransformClarke_InlineC
- MC_TransformClarkeABC_InlineC
- MC_TransformPark_InlineC
- MC_TransformParkInverse_InlineC
- MC_TransformClarkeInverseSwappedInput_InlineC
- MC_TransformClarkeInverse_InlineC
- MC_TransformClarkeInverseNoAccum_InlineC

## Testing

Unit tests were performed on all functions,
with the following exceptions:

- MC_ControllerPIUpdate_Assembly
- MC_ControllerPIUpdate_InlineC

These tests were performed on the 33EP256MC506 and 33CK256MP508.
Unit tests have not been performed on the 33F architecture due
to technical limitations. (The source code is identical
with the exception of the declaration of the table for sine/cosine
calculations.)

## Revision History


- **0.2** --- 2019 Oct 15

    - Adds support for 33CK architectures
	- Functions added:
	
	     - MC_CalculateSpaceVector_Assembly ---
           does not have the unconventional phase shift of
           MC_CalculateSpaceVectorPhaseShifted_Assembly 
		 - MC_CalculateZeroSequenceModulation_InlineC --- 
		   zero sequence modulation handles overmodulation 
		   more gracefully than the implementation of SVM
		 - MC_TransformClarkeABC_InlineC --- ABC -> alpha,beta 
		   (other Clarke transforms are AB -> alpha,beta)
		 - MC_TransformClarkeInverse_Assembly ---
		   this and the following functions do not have 
		   swapped inputs of 
		   MC_TransformClarkeInverseSwappedInput_Assembly
		 - MC_TransformClarkeInverse_InlineC
		 - MC_TransformClarkeInverseNoAccum_Assembly --- 
		   avoids use of DSP accumulator
		 - MC_TransformClarkeInverseNoAccum_InlineC

- **0.1** --- 2013 Dec 13: original release


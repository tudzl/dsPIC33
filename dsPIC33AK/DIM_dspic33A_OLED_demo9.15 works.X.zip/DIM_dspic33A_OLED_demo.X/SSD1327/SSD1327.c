//SSD1327  Futaba ELW1501AAR OLED driver V1.3
//working with AVR MCU, Atmel studio GCC,
//SPI mode need to provide SPI_OLED_exchange_byte() API for writedata function.
//2023.02.22 added GFX functions from adafruit libs
//SSD1327  Futaba ELW1501AAR OLED driver V1.2
//date 22.02.2022, Author: Zell
//SSD1327  Futaba ELW1501AAR OLED driver V1.1
//SSD1327 128x128 4-bit greyscale OLED displays
//Modified by Zell for AVR128DA test
//2021.12.24
//Notice, all rights reserved
//To reach Zell: tudzl@hotmail.de
//XC8 not support C++
//#ifndef SSD1327_CPP
//#define SSD1327_CPP

//#include "Arduino.h"
//#include <atmel_start.h>
//#include <avr/pgmspace.h>
#include <stdlib.h>
#include <string.h>
//#include <libq.h> //To use the _Q15 functions, #include <libq.h> and add the libq-dsp-coff.a library file.
//#include <libq_32.h>
#include "../mcc_generated_files/system/pins.h"
#include "stdint.h"
#include "stdlib.h"
//#include "SPI.h"
#include "font8x8_basic.h"
#include "font16x16.h"
#include "font16x32.h"


//#include "../AVR128_CNANO_LED.h"

//#include "../mcc_generated_files/include/pin_manager.h"
//#include "../mcc_generated_files/include/spi0.h"
//#include "spi_basic.h"
//#include "atmel_start_pins.h"
#include "../mcc_generated_files/spi_host/spi1.h"
#define FCY 8000000UL
#include <libpic30.h>

#ifndef SSD1327_H
#include "SSD1327.h"
#endif
#ifndef F_CPU
#define F_CPU 8000000UL
#endif
//#include <util/delay.h>
#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#define bitWrite(value, bit, bitvalue) (bitvalue ? bitSet(value, bit) : bitClear(value, bit))
//linux??????min?
//https://blog.csdn.net/qq_31073871/article/details/90677378
extern char tmp_string[];

static uint8_t frameBuffer[8192]; // Should mirror the display's own frameBuffer.
static uint8_t changedPixels[1024]; // Each bit of this array represets whether a given byte of frameBuffer (e.g. a pair of pixels) is not up to date.


#define min(x,y) ({ \
	typeof(x) _x = (x);    \
	typeof(y) _y = (y);    \
	(void) (&_x == &_y);    \
_x < _y ? _x : _y; })

#define max(x,y) ({ \
	typeof(x) _x = (x);    \
	typeof(y) _y = (y);    \
	(void) (&_x == &_y);    \
_x > _y ? _x : _y; })

#define  NOP()  __builtin_nop()



#ifndef min
#define min(a, b) (((a) < (b)) ? (a) : (b))
#endif

#ifndef _swap_int16_t
#define _swap_int16_t(a, b)                                                    \
{                                                                            \
	int16_t t = a;                                                             \
	a = b;                                                                     \
	b = t;                                                                     \
}
#endif

//
// SSD1327(int cs, int dc, int rst){
//	_cs = cs;
//	_dc = dc;
//	_rst = rst;
//}
//extern STATUS_LED_toggle(void);


static inline void OLED_CS_Low(void){
	//IO_PA2_CS_SetLow();
	//OLED_CS_set_level(false);
    SPI_CS_RB7_SetLow();
	//IO_PD2_CS_SetLow();
	Nop();
	
}
static inline void OLED_CS_High(void){
	//IO_PA2_CS_SetHigh();
	//OLED_CS_set_level(true);
    SPI_CS_RB7_SetHigh();
    
	//IO_PD2_CS_SetHigh();
	Nop();
	
}

static inline void OLED_DC_Low(void){
	//IO_PA3_DC_SetLow();
	//OLED_DC_set_level(false);
    SPI_DC_RB10_SetLow(); //need implement 9.7
    //SPI_DC_dummy_RC9_SetLow(); //test only
	//IO_PD3_DC_SetLow();
	//Nop();
	
}
static inline void OLED_DC_High(void){
	//IO_PA3_DC_SetHigh();
	//OLED_DC_set_level(true);
    //Nop();
     SPI_DC_RB10_SetHigh(); //need implement 9.7
     //SPI_DC_dummy_RC9_SetHigh();
	//IO_PD3_DC_SetHigh();
	
	
}


void OLED_Reset(void){
	
	//PA1
	OLED_CS_Low();
	//OLED_RST_set_level(true);
    SPI_RST_RB6_SetHigh();
	//IO_PA1_RST_SetHigh();
    __delay_us(100);
	//_delay_us(100);
	//OLED_RST_set_level(false);
    SPI_RST_RB6_SetLow();
	//IO_PA1_RST_SetLow();
	//_delay_ms(10);
    __delay_us(200)
	//_delay_us(200);
	//OLED_RST_set_level(true);
    SPI_RST_RB6_SetHigh();
	OLED_CS_High();
	__delay_us(100);
	//IO_PA1_RST_SetHigh();
}

//TODO: Find a way to handle the write commands without toggling CS and DC every time
//works with dsPIC33A!
void  writeCmd(uint8_t reg){//Writes a command byte to the driver
	//digitalWrite(_dc, LOW);
	OLED_CS_Low();
    Nop();
	OLED_DC_Low();
	//SPI0_OLED_WriteByte(reg);
	//SPI_OLED_exchange_byte(reg);
    while (false==SPI1_IsTxReady()){
         Nop();
         //OLED_DC_Low(); //test works
    }
    SPI1_ByteWrite(reg);
//    while (false==SPI1_IsRxReady()){
//        OLED_DC_Low(); //test works
//    }
    reg=SPI1_ByteRead(); 
    Nop();
	//digitalWrite(_cs, HIGH);
	OLED_DC_Low();
}

void  writeCmd_buf(void *bufferData, size_t bufferSize)
{//Writes command bytes to the driver
	//digitalWrite(_dc, LOW);
	OLED_CS_Low();
    Nop();
	OLED_DC_Low();
	//SPI0_OLED_WriteByte(reg);
	//SPI_OLED_exchange_byte(reg);
    while (false==SPI1_IsTxReady()){
         Nop();
         //OLED_DC_Low(); //test works
     }
    SPI1_BufferWrite(bufferData,bufferSize);
//    while (false==SPI1_IsRxReady()){
//        OLED_DC_Low(); //test works
//    }

    Nop();
	//digitalWrite(_cs, HIGH);
	//OLED_DC_Low();
}

void  writeCmd_direct(uint8_t reg){//Writes a command byte to the driver
	//digitalWrite(_dc, LOW);
	OLED_CS_Low();
    Nop();
	OLED_DC_Low();
	//SPI0_OLED_WriteByte(reg);
	//SPI_OLED_exchange_byte(reg);
//    while (false==SPI1_IsTxReady()){
//         Nop();
//         //OLED_DC_Low(); //test works
//    }
    SPI1_ByteWrite(reg);
//    while (false==SPI1_IsRxReady()){
//        OLED_DC_Low(); //test works
//    }
    //reg=SPI1_ByteRead(); 
    Nop();
	//digitalWrite(_cs, HIGH);
	OLED_DC_Low();
}

//TODO: Find a way to handle the write commands without toggling CS and DC every time
/*
void  writeCmd_B(uint8_t reg){//Writes a command byte to the driver
	//digitalWrite(_dc, LOW);
	OLED_CS_Low();
    Nop();
	OLED_DC_Low();
	//SPI0_OLED_WriteByte(reg);
	//SPI_OLED_exchange_byte(reg);
    while (false==SPI1_IsTxReady()){
        OLED_DC_Low(); //test works
    }
    SPI1_BufferWrite(&reg,1);
   // reg=SPI1_ByteRead(); 
   
	//digitalWrite(_cs, HIGH);
	//OLED_DC_Low();
}
*/

//seems has issues with dsPIC33A!
void  writeData_a(uint8_t data){//Writes 1 byte to the display's memory
	//digitalWrite(_dc, HIGH);
    OLED_CS_Low();
    Nop();
    OLED_DC_High();
    Nop();
    while(false==SPI1_IsTxReady()){
       Nop(); //test
    }
    SPI1_ByteWrite(data); 
    data=SPI1_ByteRead(); 
	//SPI0_OLED_WriteByte(data);
    //SPI1_ByteExchange(data);
    //SPI1_ByteWrite(data);
	//digitalWrite(_cs, HIGH);
	//NOP();
	//OLED_CS_High();
	//OLED_DC_Low();
}

//works with dsPIC33A!
void  writeData(uint8_t data){//Writes 1 byte to the display's memory
	//digitalWrite(_dc, HIGH);
    OLED_CS_Low();
    Nop();
    OLED_DC_High();
    Nop();
    while(false==SPI1_IsTxReady()){
       Nop(); //test
    }
    SPI1_ByteWrite(data); 
    data=SPI1_ByteRead(); 
	//SPI0_OLED_WriteByte(data);
    //SPI1_ByteExchange(data);
    //SPI1_ByteWrite(data);
	//digitalWrite(_cs, HIGH);
	//NOP();
    Nop();
	OLED_CS_High();
	//OLED_DC_Low();
}
//old api, works but low efficiency!
void  setWriteZone_bak(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) { //defines a rectangular area of memory which the driver will itterate through. This function takes memory locations, meaning a 64x128 space
	//OLED_CS_Low();
	//OLED_DC_Low();
    writeCmd(0x15); //Set Column Address
	//NOP();
	writeCmd(x1); //Beginning. Note that you must divide the column by 2, since 1 byte in memory is 2 pixels
	//NOP();
	writeCmd(x2); //End  max 0x3f
	//NOP();
	writeCmd(0x75); //Set Row Address
	//NOP();
	writeCmd(y1); //Beginning
	// NOP();
	writeCmd(y2); //End  max 0x7f
    //OLED_DC_Low();
    //__delay_us(3); //critical
    //OLED_DC_Low();
    //OLED_DC_High();
}

//need test
void  setWriteZone(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) { //defines a rectangular area of memory which the driver will itterate through. This function takes memory locations, meaning a 64x128 space
	OLED_CS_Low();
	OLED_DC_Low();

    
    CMD_TX_buf[0]=0x15;
    CMD_TX_buf[1]=x1;
    CMD_TX_buf[2]=x2;
    CMD_TX_buf[3]=0x75;
    CMD_TX_buf[4]=y1;
    CMD_TX_buf[5]=y2;
    
    
    //SPI1_BufferWrite(CMD_TX_buf,6);//works!!!
    
    //writeCmd_buf(&CMD_TX_buf[0],6);
    writeCmd_buf(CMD_TX_buf,6);
    //memset(CMD_TX_buf,NULL,6);
    
//    OLED_CS_Low();
//    //Nop();
//	OLED_DC_Low();
//	//SPI0_OLED_WriteByte(reg);
//	//SPI_OLED_exchange_byte(reg);
//    while (false==SPI1_IsTxReady()){
//        Nop();
//    }
//    SPI1_BufferWrite(&TX_buf,6);
    //OLED_DC_Low();
    //__delay_us(3); //critical
    //OLED_DC_Low();
    //OLED_DC_High();
}

//direct write with issues
void  setWriteZone_issue(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) { //defines a rectangular area of memory which the driver will itterate through. This function takes memory locations, meaning a 64x128 space
	//OLED_CS_Low();
	//OLED_DC_Low();
    writeCmd(0x15); //Set Column Address
	//NOP();
	writeCmd(x1); //Beginning. Note that you must divide the column by 2, since 1 byte in memory is 2 pixels
	//NOP();
	writeCmd(x2); //End  max 0x3f
	//NOP();
	writeCmd(0x75); //Set Row Address
	//NOP();
	writeCmd(y1); //Beginning
	// NOP();
	writeCmd(y2); //End  max 0x7f
    //OLED_DC_Low();
    __delay_us(3); //critical
    OLED_DC_Low();
    //OLED_DC_High();
}

//2D pixel mapping to 1D array
uint16_t  coordsToAddress(uint8_t x, uint8_t y){ //Converts a pixel location to a linear memory address
	return (x/2)+(y*64);
}

void  setPixelChanged(uint8_t x, uint8_t y, bool changed){
	uint16_t targetByte = coordsToAddress(x, y)/8;
	bitWrite(changedPixels[targetByte], coordsToAddress(x, y) % 8, changed);
}

void  drawPixel(uint8_t x, uint8_t y, uint8_t color, bool display){//pixel xy coordinates 0-127, color 0-15, and whether to immediately output it to the display or buffer it
	int address = coordsToAddress(x,y);
	if((x%2) == 0){//If this is an even pixel, and therefore needs shifting to the more significant nibble
		frameBuffer[address] = (frameBuffer[address] & 0x0f) | (color<<4);
		} else {
		frameBuffer[address] = (frameBuffer[address] & 0xf0) | (color);
	}
	
	if(display){
		//uint8_t xx= x/2;
		setWriteZone(x/2,y,x/2,y);  //SPI write 6 bytes write, bytes_per_row = WIDTH / 2
		//NOP();
		//setPixelChanged(x, y, false);
		writeData(frameBuffer[address]); //ok.missing?
		//NOP();
		setPixelChanged(x, y, false); // We've now synced the display with this byte of the buffer, no need to write it again
		// NOP();
		//setPixelChanged(x, y, false);
		//NOP();
		//OLED_CS_High();
		} else {
		setPixelChanged(x, y, true); // This pixel is due for an update next refresh
	}
}

void  drawRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color, bool display){//Draws a rectangle from x1,y1 to x2,y2.
	uint8_t xMin = min(x1, x2); // TODO: double performance by writing whole bytes at a time
	uint8_t xMax = max(x1, x2);
	uint8_t yMin = min(y1, y2);
	uint8_t yMax = max(y1, y2);
	for (uint8_t x = xMin; x <= xMax; x++) {
		for (uint8_t y = yMin; y <= yMax; y++) {
			drawPixel(x, y, color, display);
		}
	}
}

//not working yet!
void  drawRect_transitionBand(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color, bool display){//Draws a rectangle from x1,y1 to x2,y2.
	uint8_t xMin = min(x1, x2); // TODO: double performance by writing whole bytes at a time
	uint8_t xMax = max(x1, x2);
	uint8_t yMin = min(y1, y2);
	uint8_t yMax = max(y1, y2);
	uint8_t step_width;
	uint8_t color_step=1;
	color =1;
	if (xMax-xMin>15) {
		step_width= (xMax-xMin)/15;
		color_step=1;
	}
    else if(xMax-xMin>5){
		step_width= (xMax-xMin)/4;
		color_step=4;
	}
	else{
		step_width=1;
		color_step=7;
	}
		
	for (uint8_t x = xMin; x <= xMax; x++) {
		    color= color_step*((x-xMin)/step_width);
			if (color >15)color =15;
			for (uint8_t y = yMin; y <= yMax; y++) {
			drawPixel(x, y, color, display);
			}
			//color+=color_step;
	}
}

void  drawHLine(int x, int y, int length, uint8_t color, bool display){
	for (uint8_t i = x; i < x+length; i++) {
		drawPixel(i, y, color, display);
	}
}

void  drawVLine(int x, int y, int length, uint8_t color, bool display){
	for (uint8_t i = y; i < y+length; i++) {
		drawPixel(x, i, color, display);
	}
}

void  drawLine(int x0, int y0, int x1, int y1, uint8_t color, bool display){ //Bresenham's line algorithm
	int deltaX = abs(x1-x0);
	int deltaY = abs(y1-y0);
	int signX = x0<x1 ? 1 : -1;
	int signY = y0<y1 ? 1 : -1;
	int error = (deltaX>deltaY ? deltaX : -deltaY)/2, error2;
	
	while (true) {
		drawPixel(x0, y0, color, display);
		if (x0==x1 && y0==y1) break;
		error2 = error;
		if (error2 >-deltaX) { error -= deltaY; x0 += signX; }
		if (error2 < deltaY) { error += deltaX; y0 += signY; }
	}
}

void  drawByteAsRow(uint8_t x, uint8_t y, uint8_t byte, uint8_t color){//Draws a byte as an 8 pixel row
	for (int i = 0; i < 8; i++) {
		if(bitRead(byte, i)){
			drawPixel(x+i, y, color, false);
		}
	}
}

void  drawChar(uint8_t x, uint8_t y, char thisChar, uint8_t color){
	for (size_t i = 0; i < 8; i++) {
		drawByteAsRow(x, y+i, font8x8_basic[(unsigned char)thisChar][i], color);
	}
}

void  drawCharArray(uint8_t x, uint8_t y, char text[], uint8_t color, int size){
	const char* thisChar;
	uint8_t xOffset = 0;
	if(size==16){
		for (thisChar = text; *thisChar != '\0'; thisChar++) {
			drawChar16(x+xOffset, y, *thisChar, color);
			xOffset += 8;
		}
		} else if(size==32){
		for (thisChar = text; *thisChar != '\0'; thisChar++) {
			drawChar32(x+xOffset, y, *thisChar, color);
			//drawChar16(x+xOffset, y, *thisChar, color); //for debug only
			xOffset += 16;
		}
	}
	else {
		for (thisChar = text; *thisChar != '\0'; thisChar++) {
			drawChar(x+xOffset, y, *thisChar, color);
			xOffset += 8;
		}
	}
}

void  drawString(uint8_t x, uint8_t y, char* textString, uint8_t color, int size){
	char text[64];
	//textString.toCharArray(text, 64);
	//need C driver for toCharArray
	drawCharArray(x,y, text, color, size);
}

void  drawChar16(uint8_t x, uint8_t y, char thisChar, uint8_t color){
	for (size_t row = 0; row < 16; row++) {
		//drawByteAsRow(x, y+row, pgm_read_byte_near(&font16x16[(unsigned char)thisChar][row*2]) , color);
		//drawByteAsRow(x+8, y+row, pgm_read_byte_near(&font16x16[(unsigned char)thisChar][(row*2)+1]), color);
        drawByteAsRow(x, y+row, (font16x16[(unsigned char)thisChar][row*2]) , color);
		drawByteAsRow(x+8, y+row, (font16x16[(unsigned char)thisChar][(row*2)+1]), color);
	}
}

void  drawChar16_RAM(uint8_t x, uint8_t y, char thisChar, uint8_t color){
	for (size_t row = 0; row < 16; row++) {
		drawByteAsRow(x, y+row, (font16x16[(unsigned char)thisChar][row*2]) , color);
		drawByteAsRow(x+8, y+row, (font16x16[(unsigned char)thisChar][(row*2)+1]), color);
	}
}

void  drawChar32(uint8_t x, uint8_t y, char thisChar, uint8_t color){
	for (size_t row = 0; row < 32; row++) {
		//drawByteAsRow(x, y+row, pgm_read_byte_near(&font16x32[(unsigned char)thisChar][row*2]), color);
		//drawByteAsRow(x+8, y+row, pgm_read_byte_near(&font16x32[(unsigned char)thisChar][(row*2)+1]), color);
        drawByteAsRow(x, y+row, (uint8_t) (font16x32[(unsigned char)thisChar][row*2]), color);
		drawByteAsRow(x+8, y+row, (uint8_t) (font16x32[(unsigned char)thisChar][(row*2)+1]), color);
	}
}

void  drawChar32_RAM(uint8_t x, uint8_t y, char thisChar, uint8_t color){
	for (size_t row = 0; row < 32; row++) {
		drawByteAsRow(x, y+row, font16x32[(unsigned char)thisChar][row*2], color);
		drawByteAsRow(x+8, y+row, font16x32[(unsigned char)thisChar][(row*2)+1], color);
	}
}

void  fillStripes(uint8_t offset){ //gradient test pattern
	for(int i = 0; i < 8192; i++){
		uint8_t color = ((i+offset) & 0xF) | (((i+offset) & 0xF)<<4);
		frameBuffer[i] = color;
	}
	for (uint16_t i = 0; i < 1024; i++) {
		changedPixels[i] = 0xFF; // Set all pixels to be updated next frame. fillStripes should not be used without a full write anyways, but just in case
	}
}

void  setupScrolling(uint8_t startRow, uint8_t endRow, uint8_t startCol, uint8_t endCol, uint8_t scrollSpeed, bool right){
	uint8_t swap;
	if (startRow > endRow) { // Ensure start row is before end
		swap = startRow;
		startRow = endRow;
		endRow = swap;
	}
	if (startCol > endCol) { // Ditto for columns
		swap = startCol;
		startCol = endCol;
		endCol = swap;
	}
	writeCmd(0x2E);   // Deactivate scrolling before changing anything
	__delay_us(15);
	
	if (right) {
		writeCmd(0x26); // Scroll right
		} else {
		writeCmd(0x27); // Scroll left
	}
	writeCmd(0); // Dummy byte
	writeCmd(startRow);
	writeCmd(scrollSpeed);
	writeCmd(endRow);
	writeCmd(startCol);
	writeCmd(endCol);
	writeCmd(0); // Dummy byte
};
//scrolling seems not working, no effect
void  startScrolling(){
	writeCmd(0x2F);
}

void  stopScrolling(){
	writeCmd(0x2E);
}

void  scrollStep(uint8_t startRow, uint8_t endRow, uint8_t startCol, uint8_t endCol, bool right){
	setupScrolling(startRow, endRow, startCol, endCol, SSD1327_SCROLL_2, right);
	startScrolling();
	//delay(15);
	__delay_us(15);
	stopScrolling();
}

void  clearBuffer(){//
	for(int i = 0; i < 8192; i++){
		if (frameBuffer[i]) { // If there is a non-zero (non-black) byte here, make sure it gets updated
			frameBuffer[i] = 0;
			bitWrite(changedPixels[i/8], i%8, 1); // Mark this pixel as needing an update
		}
	}
}
//partly clear the frame buffer of ROI,  updates to changedPixels of ROI, written by ZELL, tested OK, 19.July.2022
void  clearFrameBuffer(uint8_t x,uint8_t y,uint8_t width, uint8_t height){//
	//128*128/2=8192, 128 x 128 x 4 bit SRAM display buffer
	//uint8_t changedPixels[1024]
	//uint16_t address ;
	uint16_t x_end= x+width;
	//uint16_t y_end= y+height;
	int i_start;
	int i_end;
	
	for(int y_idx = 0; y_idx < height; y_idx++){
		i_start= coordsToAddress(x, y+y_idx);
		i_end= coordsToAddress(x_end, y+y_idx);
		for(int i = i_start; i < i_end; i++){
			if (frameBuffer[i]) { // If there is a non-zero (non-black) byte here, make sure it gets updated
				frameBuffer[i] = 0;
				//address = coordsToAddress(x, y);//(x/2)+(y*64); //y max 127
				bitWrite(changedPixels[i/8], i%8, 1); // Mark this pixel as needing an update
			}
		}
	}
}

//fill all pixels to 1, appears in grey color
void SSD1327_FillBuffer(void){
	for(int i = 0; i < 8192; i++){
		//if (frameBuffer[i]) { // If there is a non-zero (non-black) byte here, make sure it gets updated
		frameBuffer[i] = 1;
		//bitWrite(changedPixels[i/8], i%8, 1); // Mark this pixel as needing an update
		
	}
	
}

void SSD1327_FillBuffer_black(void){
	for(int i = 0; i < 8192; i++){
		//if (frameBuffer[i]) { // If there is a non-zero (non-black) byte here, make sure it gets updated
		frameBuffer[i] = 0;
		//bitWrite(changedPixels[i/8], i%8, 1); // Mark this pixel as needing an update
		
	}
	
}
//fill all pixels to max white status
void SSD1327_Buffer_White(void){
	for(int i = 0; i < 8192; i++){
		
		frameBuffer[i] = 15;
		
		
	}
	
}


void  writeFullBuffer(){ //Outputs the full framebuffer to the display
	//SPI_DC_RB10_SetLow();
   //setWriteZone(0,0,63,127); //Full display  x1,y1,x2,y2
     setWriteZone(0,0,OLED_Width/2-1,OLED_Height-1); //Full display  x1,y1,x2,y2
    //SPI_DC_RB10_SetLow();
	//Nop();
    Nop(); //// DC early go high issue!!
    __delay_us(1);// DC early go high issue!!
    
	for(int i = 0; i < 8192; i++){
		writeData(frameBuffer[i]);
		Nop();
	}
	for (uint16_t i = 0; i < 1024; i++) {
		changedPixels[i] = 0; // Set all pixels as up to date.
	}
}

void  writeUpdates(){ // Writes only the pixels that have changed to the display
	for (size_t y = 0; y < 128; y++) {
		bool continued = false; // If we can continue with the write zone we're using
		for (size_t x = 0; x < 128; x++) {
			uint16_t address = coordsToAddress(x, y);
			if ( bitRead(changedPixels[address/8], address % 8) ) { // If we need an update here
				if (!continued) { // Just write the byte, no new write zone needed
					continued = true;
					setWriteZone(x/2, y, 63, 127); // Set the write zone for this new byte and any subsequent ones
				}
				writeData(frameBuffer[address]);
				bitWrite(changedPixels[address/8], address % 8, 0);
				//OLED_CS_High();
				} else {
				continued = false; // The chain of pixels is broken
			}
		}
	}
}


void  write_Local_Updates(uint8_t x_pos,uint8_t y_pos,uint8_t w,uint8_t h ){ // start @ pixel position x_pos,y_pos with rect width w and height h, window mode Writes only the pixels that have changed to the display
	for (size_t y = y_pos; y < y_pos+h; y++) {
		bool continued = false; // If we can continue with the write zone we're using
		for (size_t x = x_pos; x < x_pos+w; x++) {
			uint16_t address = coordsToAddress(x, y);
			if ( bitRead(changedPixels[address/8], address % 8) ) { // If we need an update here
				if (!continued) { // Just write the byte, no new write zone needed
					continued = true;
					setWriteZone(x/2, y, 63, 127); // Set the write zone for this new byte and any subsequent ones
				}
				writeData(frameBuffer[address]);
				bitWrite(changedPixels[address/8], address % 8, 0);
				//OLED_CS_High();
				} else {
				continued = false; // The chain of pixels is broken
			}
		}
	}
}

void  setContrast(uint8_t contrast){
	writeCmd(0x81);  //set contrast control
	writeCmd(contrast);  //Contrast byte
}

void  initRegs(void){ //Sends all the boilerplate startup and config commands to the driver
	writeCmd(0xAE);//--turn off oled panel

	writeCmd(0x15);  //set column addresses
	writeCmd(0x00);  //start column  0
	writeCmd(0x7f);  //end column  127

	writeCmd(0x75);  //set row addresses
	writeCmd(0x00);  //start row  0
	writeCmd(0x7f);  //end row  127

	writeCmd(0x81);  //set contrast control
	writeCmd(0x80);  //0x80 50% (128/255)

	writeCmd(0xa0);   //gment remap
	writeCmd(0x51);  //51 (To my understanding, this is orientation , rotation

	writeCmd(0xa1);  //start line
	writeCmd(0x00);

	writeCmd(0xa2);  //display offset
	writeCmd(0x00);

	writeCmd(0xa4);  //normal display
	writeCmd(0xa8);  //set multiplex ratio
	writeCmd(0x7f);

	writeCmd(0xb1);  //set phase leghth
	//writeCmd(0xF1); //ori,works,too bright, gray scale poor
	//writeCmd(0x77); //works,too bright?
	writeCmd(0x31); //works ok
	//writeCmd(0xEE); //0xf1

	writeCmd(0xb3);  //set dclk
	writeCmd(0x00);  //80Hz:0xc1 90Hz:0xe1  100Hz:0x00  110Hz:0x30 120Hz:0x50  130Hz:0x70   01

	writeCmd(0xab);  //Enable vReg
	writeCmd(0x01);

	writeCmd(0xb6);  //set phase leghth
	//writeCmd(0x0f); //ori too bright?
	writeCmd(0x06);

	writeCmd(0xbe); //Set vcomh voltage
	writeCmd(0x0f);

	writeCmd(0xbc); //set pre-charge voltage
	writeCmd(0x08);

	writeCmd(0xd5); //second precharge period
	writeCmd(0x62);

	writeCmd(0xfd); //Unlock commands
	writeCmd(0x12);

	writeCmd(0xAF);
	//delay(300);
	__delay_us(50);
}

void  OLED_Init(void){
	//	pinMode(_cs, OUTPUT);
	//	pinMode(_dc, OUTPUT);
	//	pinMode(_rst, OUTPUT);
	//
	//	SPI.setDataMode(SPI_MODE0);
	//	SPI.setBitOrder(MSBFIRST);
	//	SPI.setClockDivider(SPI_CLOCK_DIV2);
	//	SPI.begin();
	//
	//reset
	//	digitalWrite(_rst, HIGH); //Reset display
	//	delay(100);
	//	digitalWrite(_rst, LOW);
	//	delay(100);
	//	digitalWrite(_rst, HIGH);
	//	delay(100);
	//OLED_Reset();
	initRegs();
    Nop();
    OLED_CS_High();
    OLED_DC_High();
}
// Adafruit_GFX  functions

/**************************************************************************/
/*!
   @brief      Draw a PROGMEM-resident 1-bit image at the specified (x,y)
   position, using the specified foreground color (unset bits are transparent).
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with monochrome bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
//void drawBitmap(int16_t x, int16_t y,  const uint8_t bitmap[],
                              //int16_t w, int16_t h, uint16_t color) {
//
  //int16_t byteWidth = (w + 7) / 8; // Bitmap scanline pad = whole byte
  //uint8_t b = 0;
//
  ////startWrite();
  //for (int16_t j = 0; j < h; j++, y++) {
    //for (int16_t i = 0; i < w; i++) {
      //if (i & 7)
        //b <<= 1;
      //else  //pgm_read_byte_near
        //b = pgm_read_byte(&bitmap[j * byteWidth + i / 8]);
      //if (b & 0x80)
        //drawPixel(x + i, y, color,true);
    //}
  //}
  ////endWrite();
//}
/**************************************************************************/
/*!
   @brief      Draw a RAM-resident 1-bit image at the specified (x,y) position,
   using the specified foreground (for set bits) and background (unset bits)
   colors.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with monochrome bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
    @param    color 16-bit 5-6-5 Color to draw pixels with
    @param    bg 16-bit 5-6-5 Color to draw background with
*/
/**************************************************************************/
void drawBitmap(int16_t x, int16_t y, const uint8_t *bitmap, int16_t w,
int16_t h, uint16_t color) {

	int16_t byteWidth = (w + 7) / 8; // Bitmap scanline pad = whole byte
	uint8_t b = 0;

	//startWrite();
	for (int16_t j = 0; j < h; j++, y++) {
		for (int16_t i = 0; i < w; i++) {
			if (i & 7)
				b <<= 1;
			else
				b = bitmap[j * byteWidth + i / 8];
			if (b & 0x80)
				drawPixel(x + i, y, color,true);
		}
	}
	//endWrite();
}
/**************************************************************************/
/*!
   @brief   Draw a PROGMEM-resident 8-bit image (grayscale) at the specified
   (x,y) pos. Specifically for 8-bit display devices such as IS31FL3731; no
   color reduction/expansion is performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with grayscale bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
/**************************************************************************/
void drawGrayscaleBitmap_PROGMEM(int16_t x, int16_t y,
                                       const uint8_t bitmap[], int16_t w,
                                       int16_t h) {
  //startWrite();
  for (int16_t j = 0; j < h; j++, y++) {
    for (int16_t i = 0; i < w; i++) {
      //drawPixel(x + i, y, (uint8_t)pgm_read_byte(&bitmap[j * w + i]),true);
      drawPixel(x + i, y, (uint8_t)(bitmap[j * w + i]),true);
    }
  }
  //endWrite();
}

/**************************************************************************/
/*!
   @brief   Draw a RAM-resident 8-bit image (grayscale) at the specified (x,y)
   pos. Specifically for 8-bit display devices such as IS31FL3731; no color
   reduction/expansion is performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with grayscale bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
/**************************************************************************/
void drawGrayscaleBitmap(int16_t x, int16_t y, uint8_t *bitmap,
                                       int16_t w, int16_t h) {
  //startWrite();
  for (int16_t j = 0; j < h; j++, y++) {
    for (int16_t i = 0; i < w; i++) {
      drawPixel(x + i, y, bitmap[j * w + i],true);
    }
  }
  //endWrite();
}

/**************************************************************************/
/*!
   @brief     Draw a triangle with color-fill
    @param    x0  Vertex #0 x coordinate
    @param    y0  Vertex #0 y coordinate
    @param    x1  Vertex #1 x coordinate
    @param    y1  Vertex #1 y coordinate
    @param    x2  Vertex #2 x coordinate
    @param    y2  Vertex #2 y coordinate
    @param    color 16-bit 5-6-5 Color to fill/draw with
*/
/**************************************************************************/
void fillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                                int16_t x2, int16_t y2, uint16_t color) {

  int16_t a, b, y, last;

  // Sort coordinates by Y order (y2 >= y1 >= y0)
  if (y0 > y1) {
    _swap_int16_t(y0, y1);
    _swap_int16_t(x0, x1);
  }
  if (y1 > y2) {
    _swap_int16_t(y2, y1);
    _swap_int16_t(x2, x1);
  }
  if (y0 > y1) {
    _swap_int16_t(y0, y1);
    _swap_int16_t(x0, x1);
  }

 // startWrite();
  if (y0 == y2) { // Handle awkward all-on-same-line case as its own thing
    a = b = x0;
    if (x1 < a)
      a = x1;
    else if (x1 > b)
      b = x1;
    if (x2 < a)
      a = x2;
    else if (x2 > b)
      b = x2;
    //writeFastHLine(a, y0, b - a + 1, color);
	drawHLine(a, y0, b - a + 1, color,true);
   // endWrite();
    return;
  }

  int16_t dx01 = x1 - x0, dy01 = y1 - y0, dx02 = x2 - x0, dy02 = y2 - y0,
          dx12 = x2 - x1, dy12 = y2 - y1;
  int32_t sa = 0, sb = 0;

  // For upper part of triangle, find scanline crossings for segments
  // 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
  // is included here (and second loop will be skipped, avoiding a /0
  // error there), otherwise scanline y1 is skipped here and handled
  // in the second loop...which also avoids a /0 error here if y0=y1
  // (flat-topped triangle).
  if (y1 == y2)
    last = y1; // Include y1 scanline
  else
    last = y1 - 1; // Skip it

  for (y = y0; y <= last; y++) {
    a = x0 + sa / dy01;
    b = x0 + sb / dy02;
    sa += dx01;
    sb += dx02;
    /* longhand:
    a = x0 + (x1 - x0) * (y - y0) / (y1 - y0);
    b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
    */
    if (a > b)
      _swap_int16_t(a, b);
    //writeFastHLine(a, y, b - a + 1, color);
	drawHLine(a, y, b - a + 1, color,true);
  }

  // For lower part of triangle, find scanline crossings for segments
  // 0-2 and 1-2.  This loop is skipped if y1=y2.
  sa = (int32_t)dx12 * (y - y1);
  sb = (int32_t)dx02 * (y - y0);
  for (; y <= y2; y++) {
    a = x1 + sa / dy12;
    b = x0 + sb / dy02;
    sa += dx12;
    sb += dx02;
    /* longhand:
    a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
    b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
    */
    if (a > b)
      _swap_int16_t(a, b);
    drawHLine(a, y, b - a + 1, color,true);
  }
 // endWrite();
}

/**************************************************************************/
/*!
   @brief    Draw a circle outline
    @param    x0   Center-point x coordinate
    @param    y0   Center-point y coordinate
    @param    r   Radius of circle
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void drawCircle(int16_t x0, int16_t y0, int16_t r,
                              uint16_t color) {
#if defined(ESP8266)
  yield();
#endif
  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;

  //startWrite();
  drawPixel(x0, y0 + r, color,1);
  drawPixel(x0, y0 - r, color,1);
  drawPixel(x0 + r, y0, color,1);
  drawPixel(x0 - r, y0, color,1);

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    drawPixel(x0 + x, y0 + y, color,1);
    drawPixel(x0 - x, y0 + y, color,1);
    drawPixel(x0 + x, y0 - y, color,1);
    drawPixel(x0 - x, y0 - y, color,1);
    drawPixel(x0 + y, y0 + x, color,1);
    drawPixel(x0 - y, y0 + x, color,1);
    drawPixel(x0 + y, y0 - x, color,1);
    drawPixel(x0 - y, y0 - x, color,1);
  }
  //endWrite();
}

/**************************************************************************/
/*!
    @brief    Quarter-circle drawer, used to do circles and roundrects
    @param    x0   Center-point x coordinate
    @param    y0   Center-point y coordinate
    @param    r   Radius of circle
    @param    cornername  Mask bit #1 or bit #2 to indicate which quarters of
   the circle we're doing
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void drawCircleHelper(int16_t x0, int16_t y0, int16_t r,
                                    uint8_t cornername, uint16_t color) {
  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;
    if (cornername & 0x4) {
      drawPixel(x0 + x, y0 + y, color,1);
      drawPixel(x0 + y, y0 + x, color,1);
    }
    if (cornername & 0x2) {
      drawPixel(x0 + x, y0 - y, color,1);
      drawPixel(x0 + y, y0 - x, color,1);
    }
    if (cornername & 0x8) {
      drawPixel(x0 - y, y0 + x, color,1);
      drawPixel(x0 - x, y0 + y, color,1);
    }
    if (cornername & 0x1) {
      drawPixel(x0 - y, y0 - x, color,1);
      drawPixel(x0 - x, y0 - y, color,1);
    }
  }
}




//GFX functions

void OLED_testfillrect(uint8_t thickness ) {
	printf(">>OLED_testfillrect now...");
	if((0<thickness)&&(OLED_Height/16>thickness))
	{
        thickness;
    }
	else thickness = 3;
	ClrWdt();
	uint8_t color = 1;
	for (uint8_t i=0; i<OLED_Height/2; i+=thickness) {
		// alternate colors
		drawRect(i, i, OLED_Width-i, OLED_Height-i,  i % 15 + 1, false);
		//display.display();
		writeUpdates();
		color++;
	}
	ClrWdt();
	writeUpdates();
	printf(">>Drawing end!\r\n");
}


void OLED_fastfillrect(uint8_t thickness ) {
	printf("OLED_testfillrect now...");
	if((0<thickness)&&(OLED_Height/16>thickness))
	thickness;
	else thickness = 3;
	//wdt_reset();
	uint8_t color = 1;
	for (uint8_t i=0; i<OLED_Height/2; i+=thickness) {
		// alternate colors
		drawRect(i, i, OLED_Width-i, OLED_Height-i,  i % 15 + 1, false);
		//display.display();
		
		color++;
	}
	//wdt_reset();
	writeUpdates();
	printf(">>Drawing end!\r\n");
}

void testfilltriangle(void) {
	// uint8_t color = SSD1327_WHITE;
	for (int16_t i=OLED_Height/2; i>0; i-=5) {
		fillTriangle(OLED_Width/2, OLED_Height/2-i,
		OLED_Width/2-i, OLED_Height/2+i,
		OLED_Width/2+i, OLED_Height/2+i,  i % 15 + 1);
		writeUpdates();
	}
}

void testdrawbitmap(const uint8_t *bitmap, uint8_t w, uint8_t h) {
	#define XPOS 0
	#define YPOS 1
	#define DELTAY 2
	const uint8_t NUM_FLAKES=10;
	uint8_t icons[NUM_FLAKES][3];
	//randomSeed(666);     // whatever seed
	//short _Q15randomSeed = 1;
	// initialize
    //_Q15 _Q15randomSeed=_Q15abs(1);
	for (uint8_t f=0; f< NUM_FLAKES; f++) {
        //_Q15randomSeed = _Q15random();
        //icons[f][XPOS] = _Q15random();//issues
        icons[f][XPOS] = 9+f;
		//icons[f][XPOS] = random();
		icons[f][YPOS] = 0;
        icons[f][DELTAY] = f+1;
		//icons[f][DELTAY] = random() + 1;
		
		//Serial.print("x: ");
		//Serial.print(icons[f][XPOS], DEC);
		//Serial.print(" y: ");
		//Serial.print(icons[f][YPOS], DEC);
		//Serial.print(" dy: ");
		//Serial.println(icons[f][DELTAY], DEC);
	}
	uint8_t loop_cnt = 100 ;
	while (loop_cnt) {
		// draw each icon
		for (uint8_t f=0; f< NUM_FLAKES; f++) {
			drawBitmap(icons[f][XPOS], icons[f][YPOS], bitmap, w, h, f+1);
		}
		writeUpdates();
		//delay(200);
		
		// then erase it + move it
		for (uint8_t f=0; f< NUM_FLAKES; f++) {
			drawBitmap(icons[f][XPOS], icons[f][YPOS],  bitmap, w, h, SSD1327_BLACK);
			// move it
			icons[f][YPOS] += icons[f][DELTAY];
			// if its gone, reinit
			if (icons[f][YPOS] > OLED_Height) {
				//icons[f][XPOS] = random();
                //icons[f][XPOS] = _Q15random(); //issue with lib
                icons[f][XPOS] = 2*f;
				icons[f][YPOS] = 0;
				//icons[f][DELTAY] = random() + 1;
                icons[f][DELTAY] = 2*f+1;
                //icons[f][DELTAY] = _Q15random() + 1;
			}
			loop_cnt--;
		}
	}
}

void testdrawcircle(void) {
	for (uint8_t i=0; i<OLED_Width/2; i+=3) {
		drawCircle(OLED_Width/2, OLED_Height/2, i, i % 15 + 1);
		//writeUpdates();
		//wdt_reset();
	}
}



//void OLED_draw_startup_title(void){
//**********show 16bits in diff. grayscale
//oled
//char tmp_string[48];
//	clearBuffer();
//     sprintf(tmp_string, "16"); //OLED
//drawPixel(1, 1, 2, 1); //not working?
//drawCharArray(4+32, 16+4, tmp_string, 12, 8); //bugs?
//sprintf(tmp_string, "Bits");
//drawCharArray(4+32 + 16+4, 16+4, tmp_string, 6, 8);


//**********show OLED in diff. grayscale
//sprintf(tmp_string, "O"); //OLED
//drawCharArray(32, 32, tmp_string, 15, 32);
//sprintf(tmp_string, "L");
//drawCharArray(32 + 16, 32, tmp_string, 10, 32);
//sprintf(tmp_string, "E");
//drawCharArray(32 + 16 + 16, 32, tmp_string, 5, 32);
//sprintf(tmp_string, "D");
//drawCharArray(32 + 16 + 16 + 16, 32, tmp_string, 2, 32);
//sprintf(tmp_string, "Microchip");
//drawCharArray(24, 56, tmp_string, 8, 16);
//sprintf(tmp_string, "Zell 2022");
//drawCharArray(28, 80, tmp_string, 4, 8);
//sprintf(tmp_string, "T10+INA demo"); //OLED
//drawCharArray(4, 92, tmp_string, 3, 8);
//writeUpdates();


//}
//#endif

/*
void Draw_Rect_Grayscale( uint8_t w, uint8_t h){
	//drawPixel(x_pos, y_pos, BG_brightness, 1); //not working?
	// writeUpdates()  --> writeData(frameBuffer[address]);---->SPI write

}

//void  drawRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color, bool display){//Draws a rectangle from x1,y1 to x2,y2.
void testfillrect(void) {
	uint8_t color = 1;
	for (uint8_t i=0; i<display.height()/2; i+=3) {
		// alternate colors
		display.fillRect(i, i, display.width()-i*2, display.height()-i*2,  i % 15 + 1, false);
		display.display();
		color++;
	}
	writeUpdates();
}

void testdrawtriangle(void) {
	for (uint16_t i=0; i<min(display.width(),display.height())/2; i+=5) {
		display.drawTriangle(display.width()/2, display.height()/2-i,
		display.width()/2-i, display.height()/2+i,
		display.width()/2+i, display.height()/2+i,  i % 15 + 1);
		display.display();
	}
}

void testfilltriangle(void) {
	// uint8_t color = SSD1327_WHITE;
	for (int16_t i=min(display.width(),display.height())/2; i>0; i-=5) {
		display.fillTriangle(display.width()/2, display.height()/2-i,
		display.width()/2-i, display.height()/2+i,
		display.width()/2+i, display.height()/2+i,  i % 15 + 1);
		display.display();
	}
}

void testdrawroundrect(void) {
	for (uint8_t i=0; i<display.height()/3-2; i+=2) {
		display.drawRoundRect(i, i, display.width()-2*i, display.height()-2*i, display.height()/4,  i % 15 + 1);
		display.display();
	}
}

void testfillroundrect(void) {
	// uint8_t color = SSD1327_WHITE;
	for (uint8_t i=0; i<display.height()/3-2; i+=2) {
		display.fillRoundRect(i, i, display.width()-2*i, display.height()-2*i, display.height()/4,  i % 15 + 1);
		display.display();
	}
}

void testdrawrect(void) {
	for (uint8_t i=0; i<display.height()/2; i+=2) {
		display.drawRect(i, i, display.width()-2*i, display.height()-2*i, i % 15 + 1);
		display.display();
	}
}




void testdrawbitmap(const uint8_t *bitmap, uint8_t w, uint8_t h) {
	uint8_t icons[NUMFLAKES][3];
	randomSeed(666);     // whatever seed
	
	// initialize
	for (uint8_t f=0; f< NUMFLAKES; f++) {
		icons[f][XPOS] = random(display.width());
		icons[f][YPOS] = 0;
		icons[f][DELTAY] = random(5) + 1;
		
		Serial.print("x: ");
		Serial.print(icons[f][XPOS], DEC);
		Serial.print(" y: ");
		Serial.print(icons[f][YPOS], DEC);
		Serial.print(" dy: ");
		Serial.println(icons[f][DELTAY], DEC);
	}

	while (1) {
		// draw each icon
		for (uint8_t f=0; f< NUMFLAKES; f++) {
			display.drawBitmap(icons[f][XPOS], icons[f][YPOS], bitmap, w, h, f+1);
		}
		display.display();
		delay(200);
		
		// then erase it + move it
		for (uint8_t f=0; f< NUMFLAKES; f++) {
			display.drawBitmap(icons[f][XPOS], icons[f][YPOS],  bitmap, w, h, SSD1327_BLACK);
			// move it
			icons[f][YPOS] += icons[f][DELTAY];
			// if its gone, reinit
			if (icons[f][YPOS] > display.height()) {
				icons[f][XPOS] = random(display.width());
				icons[f][YPOS] = 0;
				icons[f][DELTAY] = random(5) + 1;
			}
		}
	}
}


*/
/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */
//Fit to drive OLED!!
//ENV MCHP DELL PC MPLAB 6.20, official MCC, works
/*
LED0 : RC3
1:  4
2:5
3:6
4:7
LED 5,6,7 :  RC8,9,10
 * RGB LED: p68,70,72
 * SPI_SCK:P83 RC0,  SDO: P87 RC11 OK!  SDI RD1;  CS:  RB7
POTI? ADC AN6  RA7 ADC1_Channel6, trigger:  SCPP1 trigger Event works! Set SCCP1 Plib: Special Event Trig ouput!
 * 
 * OLED  DC: Mikrobus TX RB10
 * Timer_SCCP  100us
 * Timer1  100ms
 */
//V1.6 SPI OLED driver optimized, solved low efficiency issue!
//V1.5 SPI OLED writecmd issue with DC signal early high causing data write corruption ,solved by insert SPI1_IsTxReady flag check, but lowwed SPI efficiency!
//V1.4 SPI OLED basic function works!, still some issues!
//V1.3 added PWM-->RGB LED dimming
//V1.2 ADC measure die temp and bandgap is OK~!
//V1.1 ADC UART works, SPI issues!
//V1.0 basic demo with MCC melody works

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "mcc_generated_files/adc/adc1.h"
#include "mcc_generated_files/pwm_hs/pwm.h"
#include "mcc_generated_files/spi_host/spi1.h"
//bsp
#include "bsp/led_red.h"
#include "bsp/led_blue.h"
#include "bsp/led_green.h"
#include "bsp/led_color.h"
#include "bsp/led_rgb.h"
#include "bsp/s1.h"
#include "bsp/s2.h"
#include "bsp/s3.h"
//OLED
#include "SSD1327/SSD1327.h"

#include <stdio.h>
#include <string.h>
#include "stdbool.h"
//#include "SSD1327/SSD1327.h"
#define FCY 8000000UL
//#define FCY 100000000UL
#include <libpic30.h>
//int main() {
///* at 1MHz, these are equivalent */
//__delay_us(1000);
//__delay32(1000);
//}


/*
    Main application
 */
//global vars
#define debug_info_EN 1
#define printf_cnt_interval 10
#define SPI_bus_1M 0
#define SPI_bus_125K 1
float Die_temp = 0;
float VCC_voltage = 3.3;
uint16_t ADC_res_temp = 0;
float ADC_res_float = 0;
uint16_t ADC_poti = 0;
float Poti_voltage = 0;

uint32_t ADC_INT_flag = 0;

uint32_t TMR_INT_CNT = 0;
uint8_t TMR_INT_Flag = 0;
extern uint8_t CMD_TX_buf[];
char tmp_string[48];
uint8_t scroll_dir = 0;
uint8_t scroll_part = 0; //top half or bot half
//prototypes
static void setRGBIntensity(uint16_t potentiometerReading);
float ADCConvert_Die_Temp(void);
uint16_t ADCConvert_Die_Temp_int(void);
float ADCConvert_AN14_internal(void);
long ADCConvert0p8V(void);

void TMR1_TimeoutCallback(void) {
    TMR_INT_CNT++;
    TMR_INT_Flag = 1;
}
extern void OLED_Reset(void);
void OLED_draw_startup_screen(void);

int main(void) {
    SYSTEM_Initialize(); //8M default
    printf("< dsPIC33AK Curiosity DIM MPLAB 6.20 melody test demo>\r\n");
    printf("< SSD1327 OLED driver for dsPIC33A �>\r\n");
    printf("Version 1.6, 15.Sep.2024 by Zell \r\n");
    printf("FW code compiled: %s %s\n", __DATE__, __TIME__);


    ADC_res_float = ADCConvert_AN14_internal();
    printf("#>:ADC Internal CH14 voltage is %3.3f V!\r\n", ADC_res_float);
    ADC_res_float = 15.0 * ADC_res_float / 14.0;
    printf("#>:Calculated VCC input voltage is %3.3f V! Update VCC para to current value!\r\n", ADC_res_float);
    VCC_voltage = ADC_res_float;
    Die_temp = ADCConvert_Die_Temp();
    printf("#>: Approx. dsPIC Die Temperature is %3.1f degree!\r\n", Die_temp);

    ADC_res_temp = ADCConvert_Die_Temp_int();
    printf("#>: Raw dsPIC Die Temperature is %u !\r\n", ADC_res_temp);
    ADC_res_temp = ADCConvert0p8V();
    ADC_res_float = ADC_res_temp * VCC_voltage / 4096.0;
    printf("#>:ADC bandgap voltage raw is %u !\r\n", ADC_res_temp);
    printf("#>:ADC bandgap voltage is %3.3f V!\r\n", ADC_res_float);

    printf("#>:SSD1327 OLED init...\r\n");
    uint8_t open_res = SPI1_Open(SPI_bus_1M); //1M
    uint8_t reg_val1 = SPI1CON1bits.CKE;
    uint8_t reg_val2 = SPI1CON1bits.CKP;
    uint8_t SPI_mode = SPI1CON1bits.MODE;
    if (open_res) {
        printf("#>:SPI bus init with CKE:%d; CKP:%d ; Mode:%d\r\n", reg_val1, reg_val2, SPI_mode);
        printf("#>:SPI SPI1CON1:%lu\r\n", SPI1CON1);

    }
    OLED_Reset();
    __delay_us(100);
    SPI_DC_RB10_SetHigh();
    printf("#>:SSD1327 OLED Reset finished!\r\n");
    SPI_DC_RB10_SetLow();
    SPI_CS_RB7_SetLow();
    OLED_Init(); //has issues, no sck output!
    //SPI1_ByteExchange(0xaa);//has issues
    printf("#>:SSD1327 OLED Reg init finished!\r\n");
    clearBuffer();
    __delay_us(100);
    SSD1327_FillBuffer(); ////fill all pixels to 1, appears in grey color
    //SSD1327_Buffer_White();
    writeFullBuffer(); //clear display
    __delay_ms(100);
    //printf(">#OLED frame buffer cleared!\r\n");
    //SPI_CS_RB7_SetHigh();
    //__delay_ms(200);
    clearBuffer();
    SSD1327_FillBuffer_black(); //test works!
    writeFullBuffer();
    SPI_CS_RB7_SetHigh();
    clearBuffer();
    SPI_CS_RB7_SetLow();
    LED5_RC8_Toggle();
//    drawPixel(2,2,4,true);
//    __delay_us(2);
//    drawPixel(65,1,5,true);
//    __delay_us(2);
//    drawPixel(64, 64, 12, true);
//    __delay_us(2);
//    drawPixel(16,16,4,true);
//    __delay_ms(50);
    //LED_RC9_Toggle();
    //SPI_CS_RB7_SetLow();
    clearBuffer();
    printf("#>:OLED Drawing bench test now:\r\n");
    OLED_testfillrect(6);
    //testdrawcircle();
    LED5_RC8_Toggle();
    //__delay_ms(200);
    //OLED_testfillrect(3);
    setupScrolling(0, OLED_Width / 2 - 1, 0, OLED_Height / 2 - 1, SSD1327_SCROLL_6, 1); //test ok
    startScrolling();
    __delay_ms(300);
    stopScrolling();
    setupScrolling(0, OLED_Width / 2 - 1, 0, OLED_Height / 2 - 1, SSD1327_SCROLL_4, 0);
    startScrolling();
    __delay_ms(200);
    stopScrolling();
    //printf(">#OLED Draw startup screen now:\r\n");
    //SPI_CS_RB7_SetLow();
    clearBuffer();
    //SSD1327_FillBuffer_black();
    //writeFullBuffer();
    __delay_us(100);
    // OLED_fastfillrect(2);
    //__delay_ms(200);
//    testfilltriangle();
//    //    __delay_ms(300);
    clearBuffer();
    ClrWdt();
    Nop();
    SSD1327_FillBuffer_black();
    writeFullBuffer();
    //    //ClrWdt();
    testdrawcircle();
    clearBuffer();

    //----------
    //memset(tmp_string,0,sizeof(tmp_string));
    //uint8_t TXT_brightness = 4;
    //uint8_t txt_size = 8;
    //sprintf(tmp_string, "Demo by Zell 2023"); //OLED  slide_pos 0-255
    //drawCharArray(8, 8, tmp_string, TXT_brightness, txt_size);
    //writeUpdates();

    clearBuffer();
    OLED_draw_startup_screen(); //issues!
    //__delay_ms(100);

    ADC1_IndividualChannelInterruptEnable(ADC1_Channel6); //poti
    ADC1_IndividualChannelInterruptEnable(ADC1_Channel10); //poti
    TMR1_Start();
    TMR_INT_Flag = 0;

    //PG1DC= (uint16_t)(PG1PER*0.25);
    //PG1DC= PG1PER>>3;
    PWM_Enable();
    uint32_t DC_temp = 0; // *100 scale
    float DC_float_tmp = 0;
    Nop();
    ClrWdt();
    while (1) {
        if (TMR_INT_Flag) {
            
//            if (0==TMR_INT_CNT % 4){
//                OLED_draw_startup_screen(); //test 
//            }
            
            if (0 == TMR_INT_CNT % printf_cnt_interval) {
                stopScrolling();
                printf("---AK_test loop cnt:%lu ---\r\n", TMR_INT_CNT);
                printf("buf: %#X,%#X \r\n", CMD_TX_buf[0],CMD_TX_buf[1] );
                Die_temp = ADCConvert_Die_Temp();
                printf("#>: Approx. Die Temperature is %3.1f degree\r\n", Die_temp);
                //printf("#>: Raw Poti voltage: %u, INT_flag cnt=%lu \r\n", ADC_poti, ADC_INT_flag); //issues



                Poti_voltage = VCC_voltage * ADC_poti / 4096;
                printf("#>: Poti voltage: %3.3f V,INT_flag cnt=%lu \r\n", Poti_voltage, ADC_INT_flag);
                DC_temp = 100 * PG1DC / PG1PER;
                DC_float_tmp = 100.0 * PG1DC / PG1PER;
                printf("#>: PWM1 DC= %lu %%,%2.1f%%", DC_temp, DC_float_tmp);

                printf("#>: PWM2 DC= %lu %%", DC_temp);
                DC_temp = 100 * PG4DC / PG4PER;
                printf("#>: PWM4 DC= %lu %%\r\n", DC_temp);
                
                
                
                scroll_part++;
                scroll_dir = 1-scroll_dir;
                //if (scroll_dir){
                //setupScrolling(uint8_t startRow, uint8_t endRow, uint8_t startCol, uint8_t endCol, uint8_t scrollSpeed, bool right)
                if( (3==scroll_part)||(4==scroll_part)){
                   setupScrolling((OLED_Height / 2 - 7), OLED_Height-1, 0, OLED_Width/2 - 1, SSD1327_SCROLL_2, scroll_dir);
                   scroll_part=0;
                }
                else {                
                    setupScrolling(0, (OLED_Height / 2 - 8), 0, OLED_Width/2 - 1, SSD1327_SCROLL_6, scroll_dir); //test ok
                }
                
                //setupScrolling(0, (OLED_Width / 2 - 1),  OLED_Height / 2 - 7, OLED_Height-1, SSD1327_SCROLL_6, 1-scroll_dir); //test ok
                startScrolling();
                    
               // }
              //  else {
               // setupScrolling(0, (OLED_Width / 2 - 1), 0, OLED_Height / 2 - 1, SSD1327_SCROLL_4, 0);
               // startScrolling();
              //  }
    

                
                //test SPI

                // Nop();
                // SPI_CS_RB7_SetLow();
                // Nop();
                //OLED_CS_Low();
                //open_res = SPI1_Open(SPI_bus_1M);
                //__delay_us(1);
                //SPI1_ByteWrite(0x55);
                //SPI1_ByteExchange(&DC_temp,4);

                // __delay_us(1);
                //SPI1_ByteWrite(0xAB);
                //__delay_us(2);
                //SPI1_Close();
                //SPI1_ByteExchange(&DC_temp,4);
                //OLED_CS_High();
                //Nop();
                // SPI_CS_RB7_SetHigh();
                ADC_INT_flag = 0;
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_1);
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_2);
                //                PWM_SoftwareUpdateRequest (PWM_GENERATOR_4);
                //__delay_us(100);

                //PWM_DutyCycleSet(PWM_GENERATOR_4, ADC_poti);

            }
            LED5_RC8_Toggle(); //LED5
            setRGBIntensity(ADC_poti); //issue solved, update manually
            TMR_INT_Flag = 0;

        }
        //_delay_ms(500);
    }
}

long ADCConvert0p8V(void) {
    // 0.8V is connected to Ch15
    //AD1SWTRGbits.CH2TRG = 1; // trigger channel 2
    //while(AD1STATbits.CH2RDY == 0); // wait for 64 results accumulated
    uint16_t res = 0;
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel15);
    while (ADC1_IsConversionComplete(ADC1_Channel15) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel15);
    return res;
    //    if ((res >> 3) == 0) {
    //        while (1);
    //    }
    //    return (res >> 3);
}

//long ADCConvertPot()
//{
//    // pot is connected to RA7/AN0
//    AD5SWTRGbits.CH0TRG = 1; // trigger channel 0
//    while(AD5STATbits.CH0RDY == 0); // wait for result
//    return AD5CH0DATA;
//}

float ADCConvert_Die_Temp(void) {
    float temp_die = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel13);
    while (ADC1_IsConversionComplete(ADC1_Channel13) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel13);
    temp_die = ((float) res / 4096.0) * VCC_voltage;
    temp_die = (temp_die * (-585.0))+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //1.5mv/degree??
    // celsius = (diode_voltage *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //further characterization required to optimize accuracy.
    //fahrenheit = 9.0 * celsius / 5.0 + 32;
    //return ADC1_ConversionResultGet(ADC1_Channel13);
    return temp_die;
    //return res;
}

uint16_t ADCConvert_Die_Temp_int(void) {
    //float temp_die = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel13);
    while (ADC1_IsConversionComplete(ADC1_Channel13) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel13);
    //temp_die = (res *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    // celsius = (diode_voltage *-585.0)+(485.0); //best fit curve based on measurements at 125C and -40C. 
    //further characterization required to optimize accuracy.
    //fahrenheit = 9.0 * celsius / 5.0 + 32;
    //return ADC1_ConversionResultGet(ADC1_Channel13);
    //return temp_die;
    return res;
}

float ADCConvert_AN14_internal(void) {
    float temp = 0;
    uint16_t res = 0;
    // temp sensor is connected to UREF internally  
    ADC1_ChannelSoftwareTriggerEnable(ADC1_Channel14);
    while (ADC1_IsConversionComplete(ADC1_Channel14) == 0); // wait for result
    res = ADC1_ConversionResultGet(ADC1_Channel14);
    temp = ((float) res / 4096.0) * VCC_voltage;

    return temp;
    //return res;
}

static void setRGBIntensity(uint16_t potentiometerReading) {
    ledRed.setIntensity(potentiometerReading);
    ledGreen.setIntensity(potentiometerReading);
    ledBlue.setIntensity(potentiometerReading);
}

void OLED_draw_startup_screen(void) {
    uint8_t width = 128;
    uint8_t height = 64;
    uint8_t x_pos = 8;
    uint8_t y_pos = 8;

    uint8_t TXT_brightness = 3;
    uint8_t txt_size = 8; //8,16,32
    //clearFrameBuffer(0,0, width, height); //x,y
    //memset(&tmp_string, NULL, sizeof (tmp_string));
    memset(&tmp_string, 0, sizeof (tmp_string));
    sprintf(tmp_string, "SSD1327 OLED"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
    memset(&tmp_string, 0, sizeof (tmp_string));
    TXT_brightness = 5;
    sprintf(tmp_string, "Demo Zell 2024"); //OLED  slide_pos 0-255
    drawCharArray(x_pos, y_pos + txt_size, tmp_string, TXT_brightness, txt_size);
        TXT_brightness = 8;
        txt_size =16;
        x_pos = 4;
        y_pos=y_pos+txt_size*2;
        sprintf(tmp_string, "dsPIC33A 32bit"); //OLED  slide_pos 0-255
    	drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        TXT_brightness = 6;
         y_pos=y_pos+txt_size;
         txt_size =32;
         x_pos = 8;
        sprintf(tmp_string, "4Bit"); //OLED  slide_pos 0-255
    	drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        TXT_brightness = 7;
        y_pos=y_pos+txt_size;
        x_pos = 4;
        txt_size =16;
         sprintf(tmp_string, "16 Greyscale"); //OLED  slide_pos 0-255
    	drawCharArray(x_pos, y_pos, tmp_string, TXT_brightness, txt_size);
        
    writeUpdates();
    writeFullBuffer();
}

//end of main